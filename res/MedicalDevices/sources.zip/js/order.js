// JavaScript Document

$(document).ready(function(){
	
		var dentalUnit = JSON.parse(localStorage.getItem('storage_dentalUnit'));					console.log(JSON.stringify(dentalUnit));
		var handpieceOrder = JSON.parse(localStorage.getItem('storage_handpieceOrder'));			//console.log(handpieceOrder);
		var dentalOrder = JSON.parse(localStorage.getItem('storage_dentalOrder'));					//console.log(dentalOrder);
		
		var inventoryID = [['L515','a0M2000000xVPEz'],['L520-505','a0M2000000xVPF0'],['L540','a0M2000000xVPF1'],['LINEA Patavium FE','a0M2000000xVPF2'],['OMS Tempo PX-New','a0M2000000xVPF3'],
							['TEMPO 9 ELX','a0M2000000xVPF4'],['Premier05','a0M2000000xVPF5'],['Premier08new','a0M2000000xVPF6'],['Premier10','a0M2000000xVPF7'],['Premier11','a0M2000000xVPF8'],
							['Premier15','a0M2000000xVPF9'],['Premier16','a0M2000000xVPFA'],['Premier17','a0M2000000xVPFB'],['Impuls S200','a0M2000000xVPFC'],['Impuls S300','a0M2000000xVPFD'],
							['Impuls S100','a0M2000000xVPFE'],['Impuls S100 NEO','a0M2000000xVPFF'],['Harmony S100','a0M2000000xVPFG'],['Harmony S200','a0M2000000xVPFH'],
							['Harmony S300','a0M2000000xVPFI'],['V100','a0M2000000xVPFJ'],['V200','a0M2000000xVPFK'],['V300','a0M2000000xVPFL'],['SD-80','a0M2000000xVPFM'],
							['SD-300','a0M2000000xVPFN'],['SD-150','a0M2000000xVPFO'],['SD-175','a0M2000000xVPFP'],['SD-350','a0M2000000xVPFQ'],['Adept DA270','a0M2000000xVPFR'],
							['Adept DA280','a0M2000000xVPFS'],['Adept DA370','a0M2000000xVPFT'],['Adept DA380','a0M2000000xVPFU'],['CONSUL DC350','a0M2000000xVPFV'],
							['CONSUL DC310','a0M2000000xVPFW'],['CONSUL DC180','a0M2000000xVPFX'],['CONSUL DC170','a0M2000000xVPFY'],['LUX DL210','a0M2000000xVPFZ'],['LUX DL320','a0M2000000xVPFa'],
							['C1000','a0M2000000xVPFb'],['L1000','a0M2000000xVPFc'],['LW1000','a0M2000000xVPFd'],['S1000','a0M2000000xVPFe'],['SW1000','a0M2000000xVPFf'],
							['Challenge','a0M2000000xVPFg'],['Challenge ever','a0M2000000xVPFh'],['Challenge-2','a0M2000000xVPFh']];
		

		//document.getElementById('input-dentalUnit').value = JSON.stringify(dentalUnit); 					 
		//document.getElementById('input-handpieceOrder').value = JSON.stringify(handpieceOrder); 					 
		//document.getElementById('input-dentalOrder').value = JSON.stringify(dentalOrder); 
		
							 
// ----------------------------------------------------------------------------------------   Setup dentalOrder

		for(var i = 0; i < 3; i++) {
			$('#order_dental div.order_item:nth-child('+(i+1)+') h4').html(dentalOrder[i][0]);	
			$('#order_dental div.order_item:nth-child('+(i+1)+') span').html(dentalOrder[i][1]+'');	
		};
		
		
// ----------------------------------------------------------------------------------------   Setup dentalUnit

		for(var i = 0; i < dentalUnit.length; i++) {
			var newService = $('<div class="order_item"/>').appendTo('#order_services').html( $('.copyServices').html() );
			
			newService.find('h4').html(dentalUnit[i].brand+'<span>'+dentalUnit[i].model+'</span>');	
			
			newService.find('.repair').addClass(dentalUnit[i].serv_repair);													//console.log(dentalUnit[i].serv_repair);
			newService.find('.diagnostic').addClass(dentalUnit[i].serv_diagnos);											//console.log(dentalUnit[i].serv_diagnos);
			newService.find('.maintenance').addClass(dentalUnit[i].serv_svc);												//console.log(dentalUnit[i].serv_svc);
		};


// ----------------------------------------------------------------------------------------   Setup handpieceOrder

		for(var i = 0; i < handpieceOrder.length; i++) {
			
			if( handpieceOrder[i][1]!=0 ) {
				var newService = $('<div class="order_item"/>').appendTo('#order_tips').html( $('.copyTips').html() );	
				
				newService.attr({'data-indextip':i+''});
					
				newService.find('h4').html(handpieceOrder[i][0]);	
				newService.find('span').html(handpieceOrder[i][1]+'');	
			};

		};


// ----------------------------------------------------------------------------------------   Order  Counter

		var draggStart = 0;

		$(".dragger").each(function(k) {

				$(this).draggable({
					axis: "y",
					containment:"parent",
					revert: true,
					revertDuration:30,
					start: function( event, ui ) {
						var currCounter = $(this).parent('.order_item').find('.counter'); 
						
						draggStart = ui.position.top;
						currCounter.removeClass('down').removeClass('up');
					}, 
					drag: function( event, ui ) {
						var currCounter = $(this).parent('.order_item').find('.counter'); 
						var draggingStop = ui.position.top;
						
						if ( draggStart>draggingStop )  currCounter.addClass('up');	
						else  currCounter.addClass('down');
					}, 
					stop: function( event, ui ) {
						var currCounter = $(this).parent('.order_item').find('.counter');
						var counter = parseInt(currCounter.find('span').html());
						var draggStop = ui.position.top;
						
						currCounter.removeClass('down').removeClass('up');	
						 
						if ( draggStart>draggStop )  counter++; 																		//console.log(counter);
						else  counter = ( (counter-1)<0 ) ? 0 : counter-1;																//console.log(counter);
						
						currCounter.find('span').html(counter+'');
					} 
				});

		});


// ----------------------------------------------------------------------------------------   Add to Order  

		var saveOrder = document.getElementById("save_order");		

		saveOrder.addEventListener('touchend', function(event) { 
		
			$("#save_order").addClass('active');
			setTimeout( function() { 
				$("#save_order").removeClass('active');
			}, 1800);
		
		
			for(var i = 0; i < 3; i++) {
				dentalOrder[i][1] = parseInt($('#order_dental div.order_item:nth-child('+(i+1)+') span').html());
			};
		
		
		  	$("#order_tips .order_item").each(function(j) {
				var numTip = parseInt($(this).attr('data-indextip'));
				var countTip = parseInt($(this).find('span').html());
				
				handpieceOrder[numTip][1] = countTip;
			});
		
			localStorage.setItem('storage_dentalUnit', JSON.stringify(dentalUnit)); 
			localStorage.setItem('storage_handpieceOrder', JSON.stringify(handpieceOrder)); 
			localStorage.setItem('storage_dentalOrder', JSON.stringify(dentalOrder)); 

			//document.getElementById('input-dentalUnit').value = JSON.stringify(dentalUnit); 					 
			//document.getElementById('input-handpieceOrder').value = JSON.stringify(handpieceOrder); 					 
			//document.getElementById('input-dentalOrder').value = JSON.stringify(dentalOrder); 
			
			
			var countNew = 0; 													
			var intervalIDNew = setInterval( function() {    //console.log('countNew= '+countNew);
				if( dentalOrder[countNew][1]>0 ) {
					CTAPPnewRecord('CTPHARMA__ActivityData__c','new_models',{CTPHARMA__ProductId__c:dentalOrder[countNew][2],Number_of_new_models__c:dentalOrder[countNew][1]});
				};
				countNew++; 
				if( countNew>(dentalOrder.length-1) ) { clearInterval(intervalIDNew); };
			}, 100);
			
			 
			
			var countSupplies = 0;								
			setTimeout( function() { 
				var intervalIDSupplies = setInterval( function() {				//console.log('countSupplies= '+countSupplies);
					if( handpieceOrder[countSupplies][1]>0 ) {
						CTAPPnewRecord('CTPHARMA__ActivityData__c','order_supplies',{CTPHARMA__ProductId__c:handpieceOrder[countSupplies][2],number_of_terminals__c:handpieceOrder[countSupplies][1]});
					};
					countSupplies++; 
					if( countSupplies>(handpieceOrder.length-1) ) { clearInterval(intervalIDSupplies); };
				}, 100);
			}, 500);

 
			var countInvent = 0;
			setTimeout( function() { 
				var intervalIDInvent = setInterval( function() {					//console.log('countInvent= '+countInvent);
					for(var j = 0; j < inventoryID.length; j++) {				
						if( inventoryID[j][0]==dentalUnit[countInvent].model ) {    
							
							var modelId = inventoryID[j][1];
							var dateReplace = dentalUnit[countInvent].date_month+'/'+dentalUnit[countInvent].date_year;			console.log(dentalUnit[countInvent].date_month+'/'+dentalUnit[countInvent].date_year);
							var flagDiagnostic = ( dentalUnit[countInvent].serv_diagnos!='' ) ? 1 : 0;
							var flagRepair = ( dentalUnit[countInvent].serv_repair!='' ) ? 1 : 0;
							var flagService = ( dentalUnit[countInvent].serv_svc!='' ) ? 1 : 0;
							
CTAPPnewRecord('CTPHARMA__ActivityData__c','inventory',{CTPHARMA__ProductId__c:modelId,Assessment__c:dentalUnit[countInvent].state_mark,Last_replacement__c:dateReplace,Diagnostic__c:flagDiagnostic,Repair__c:flagRepair,After_sales_service__c:flagService,Comment__c:dentalUnit[countInvent].coment});
							
							j=inventoryID.length;
						};
					};
					countInvent++; 
					if( countInvent>(dentalUnit.length-1) ) { clearInterval(intervalIDInvent); };
				}, 100);
			}, 1800);




		});
		
		
		
		


});

