// JavaScript Document

$(document).ready(function(){

		var dentalOrder = JSON.parse(localStorage.getItem('dentalOrder'));
		var handpieceOrder = JSON.parse(localStorage.getItem('handpieceOrder'));			//console.log(handpieceOrder);
		var inventoryID = JSON.parse(localStorage.getItem('InventoryIds'));
		var dentalUnit = JSON.parse(localStorage.getItem('storage_dentalUnit'));             console.log(JSON.stringify(handpieceOrder));


// ----------------------------------------------------------------------------------------   Setup dentalOrder

		for(var i = 0; i < 3; i++) {
			$('#order_dental div.order_item:nth-child('+(i+1)+') h4').html(dentalOrder[i][0]);	
			$('#order_dental div.order_item:nth-child('+(i+1)+') span').html(dentalOrder[i][1]+'');	
		};
		
		
// ----------------------------------------------------------------------------------------   Setup dentalUnit

		for(var k = 0; k < dentalUnit.length; k++) {
			var newService = $('<div class="order_item"/>').appendTo('#order_services').html( $('.copyServices').html() );
			
			newService.find('h4').html(dentalUnit[k].brand+'<span>'+dentalUnit[k].model+'</span>');
			
			newService.find('.repair').addClass(dentalUnit[k].serv_repair);													//console.log(dentalUnit[i].serv_repair);
			newService.find('.diagnostic').addClass(dentalUnit[k].serv_diagnos);											//console.log(dentalUnit[i].serv_diagnos);
			newService.find('.maintenance').addClass(dentalUnit[k].serv_svc);												//console.log(dentalUnit[i].serv_svc);
		};


// ----------------------------------------------------------------------------------------   Setup handpieceOrder

		for(var m = 0; m < handpieceOrder.length; m++) {
			
			if( handpieceOrder[m][1]!==0 ) {
				var newService = $('<div class="order_item"/>').appendTo('#order_tips').html( $('.copyTips').html() );	
				
				newService.attr({'data-indextip':m+''});
					
				newService.find('h4').html(handpieceOrder[m][0]);
				newService.find('span').html(handpieceOrder[m][1]+'');
			};

		};


// ----------------------------------------------------------------------------------------   Order  Counter

		var draggStart = 0;

		$(".dragger").each(function(k) {

				$(this).draggable({
					axis: "y",
					containment:"parent",
					revert: true,
					revertDuration:30,
					start: function( event, ui ) {
						var currCounter = $(this).parent('.order_item').find('.counter'); 
						
						draggStart = ui.position.top;
						currCounter.removeClass('down').removeClass('up');
					}, 
					drag: function( event, ui ) {
						var currCounter = $(this).parent('.order_item').find('.counter'); 
						var draggingStop = ui.position.top;
						
						if ( draggStart>draggingStop )  currCounter.addClass('up');	
						else  currCounter.addClass('down');
					}, 
					stop: function( event, ui ) {
						var currCounter = $(this).parent('.order_item').find('.counter');
						var counter = parseInt(currCounter.find('span').html());
						var draggStop = ui.position.top;
						
						currCounter.removeClass('down').removeClass('up');	
						 
						if ( draggStart>draggStop )  counter++; 																		//console.log(counter);
						else  counter = ( (counter-1)<0 ) ? 0 : counter-1;																//console.log(counter);
						
						currCounter.find('span').html(counter+'');
					} 
				});

		});


// ----------------------------------------------------------------------------------------   Add to Order  

		var saveOrder = document.getElementById("save_order");		

		saveOrder.addEventListener('touchend', function(event) { 
		
			$("#save_order").addClass('active');
			setTimeout( function() { 
				$("#save_order").removeClass('active');
			}, 1800);
		
		
			for(var i = 0; i < 3; i++) {
				dentalOrder[i][1] = parseInt($('#order_dental div.order_item:nth-child('+(i+1)+') span').html());
			};
		
		
		  	$("#order_tips .order_item").each(function(j) {
				var numTip = parseInt($(this).attr('data-indextip'));
				var countTip = parseInt($(this).find('span').html());
				
				handpieceOrder[numTip][1] = countTip;
			});
		
			localStorage.setItem('storage_dentalUnit', JSON.stringify(dentalUnit)); 
			localStorage.setItem('handpieceOrder', JSON.stringify(handpieceOrder));
			localStorage.setItem('dentalOrder', JSON.stringify(dentalOrder));


			var countNew = 0; 													
			var intervalIDNew = setInterval( function() {    //console.log('countNew= '+countNew);
				if( dentalOrder[countNew][1]>0 ) {
					CTAPPnewRecord('CTPHARMA__ActivityData__c','new_models',{CTPHARMA__ProductId__c:dentalOrder[countNew][2],Number_of_new_models__c:dentalOrder[countNew][1]});
				};
				countNew++; 
				if( countNew>(dentalOrder.length-1) ) { clearInterval(intervalIDNew); };
			}, 100);
			
			 
			
			var countSupplies = 0;								
			setTimeout( function() { 
				var intervalIDSupplies = setInterval( function() {				//console.log('countSupplies= '+countSupplies);
					if( handpieceOrder[countSupplies][1]>0 ) {
						CTAPPnewRecord('CTPHARMA__ActivityData__c','order_supplies',{CTPHARMA__ProductId__c:handpieceOrder[countSupplies][2],number_of_terminals__c:handpieceOrder[countSupplies][1]});
					};
					countSupplies++; 
					if( countSupplies>(handpieceOrder.length-1) ) { clearInterval(intervalIDSupplies); };
				}, 100);
			}, 500);

 
			var countInvent = 0;
			setTimeout( function() { 
				var intervalIDInvent = setInterval( function() {					//console.log('countInvent= '+countInvent);
					for(var j = 0; j < inventoryID.length; j++) {				
						if( inventoryID[j][0]==dentalUnit[countInvent].model ) {    
							
							var modelId = inventoryID[j][1];
							var dateReplace = dentalUnit[countInvent].date_month+'/'+dentalUnit[countInvent].date_year;			console.log(dentalUnit[countInvent].date_month+'/'+dentalUnit[countInvent].date_year);
							var flagDiagnostic = ( dentalUnit[countInvent].serv_diagnos!='' ) ? 1 : 0;
							var flagRepair = ( dentalUnit[countInvent].serv_repair!='' ) ? 1 : 0;
							var flagService = ( dentalUnit[countInvent].serv_svc!='' ) ? 1 : 0;
							
CTAPPnewRecord('CTPHARMA__ActivityData__c','inventory',{CTPHARMA__ProductId__c:modelId,Assessment__c:dentalUnit[countInvent].state_mark,Last_replacement__c:dateReplace,Diagnostic__c:flagDiagnostic,Repair__c:flagRepair,After_sales_service__c:flagService,Comment__c:dentalUnit[countInvent].coment});
							
							j=inventoryID.length;
						};
					};
					countInvent++; 
					if( countInvent>(dentalUnit.length-1) ) { clearInterval(intervalIDInvent); };
				}, 100);
			}, 1800);

		});



});

