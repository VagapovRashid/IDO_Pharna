// JavaScript Document

$(document).ready(function(){

// ----------------------------------------------------------------------------------------   Slide 1
		var countMask = 0;
		var draggStart = 0;

		$('#over').draggable({
			axis: "x",
			containment:"parent",
			revert: true,
			revertDuration:10,
			start: function( event, ui ) {
				draggStart = event.pageX;
			}, 
			drag: function( event, ui ) {
				var draggMove = event.pageX;															//console.log(draggMove);
				
				if ( draggStart<draggMove )  {
					countMask = ( countMask==100 ) ? 100 : countMask+5;
				}else  {
					countMask = ( countMask==0 ) ? 0 : countMask-5;
				};
				
				$("#over").css({'-webkit-mask-size':countMask+'% 100%'});
				draggStart = draggMove;
			} 
		});


// ----------------------------------------------------------------------------------------   Slide 2

		$('.motorspin').spritespin({
			source: SpriteSpin.sourceArray('images/features/sovereign/moto_zoom_{frame}.jpg', { frame: [1,3], digits: 2 }),
			width: 385,
			height: 339,
			frames: 3,
			sense: -1,
			animate : false,
			renderer: 'canvas'
		});
		

// ----------------------------------------------------------------------------------------   Slide 3
		var countPosition = 0;
		var draggStart2 = 0;

		$('.position_wrapper').draggable({
			axis: "y",
			containment:"parent",
			revert: true,
			revertDuration:10,
			start: function( event, ui ) {
				draggStart2 = event.pageY;
			}, 
			drag: function( event, ui ) {
				var draggMove = event.pageY;															console.log(draggMove);
				
				if ( draggStart2<draggMove )  {
					countPosition = ( countPosition==0 ) ? 0 : countPosition-8;
				}else  {
					countPosition = ( countPosition==88 ) ? 88 : countPosition+8;
				};																					//console.log(draggMove);
				
				$(".position_head").css({'-webkit-transform':'translate3d(0,-'+countPosition+'px,0)'});
				$(".position_back").css({'-webkit-transform':'translate3d(0,-'+(countPosition*0.38)+'px,0)'});
				
				if ( countPosition==0 ) $(".position_back").addClass('shadow');
				else  $(".position_back").removeClass('shadow');
				
				draggStart2 = draggMove;
			} 
		});


// ----------------------------------------------------------------------------------------   Rotator
		var countRotate = 1;
		
		Hammer(document.getElementById("rotator")).on("swipeleft", function(ev) {						
			countRotate = ( countRotate==3 ) ? 1 : countRotate+1;										//console.log(countRotate);
				
			$(".slide, .box_note p, .box_content h2").removeClass('active');
			
			$('.visual .slide:nth-child('+countRotate+')').addClass('active');
			$('.box_note p:nth-child('+countRotate+')').addClass('active');
			$('.box_content h2:nth-child('+countRotate+')').addClass('active');
			
			countPosition = 0;
			$(".position_head").css({'-webkit-transform':'translate3d(0,0,0)'});
			$(".position_back").css({'-webkit-transform':'translate3d(0,0,0)'});
			$(".position_back").addClass('shadow');
			
			countMask = 0;
			$("#over").css({'-webkit-mask-size':'0% 100%'});
		});
		Hammer(document.getElementById("rotator")).on("swiperight", function(ev) {					
			countRotate = ( countRotate==1 ) ? 3 : countRotate-1;										//console.log(countRotate);
				
			$(".slide, .box_note p, .box_content h2").removeClass('active');
			
			$('.visual .slide:nth-child('+countRotate+')').addClass('active');
			$('.box_note p:nth-child('+countRotate+')').addClass('active');
			$('.box_content h2:nth-child('+countRotate+')').addClass('active');
			
			countPosition = 0;
			$(".position_head").css({'-webkit-transform':'translate3d(0,0,0)'});
			$(".position_back").css({'-webkit-transform':'translate3d(0,0,0)'});
			$(".position_back").addClass('shadow');
			
			countMask = 0;
			$("#over").css({'-webkit-mask-size':'0% 100%'});
		});







});

