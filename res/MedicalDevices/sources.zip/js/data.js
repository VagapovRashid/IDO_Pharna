// JavaScript Document


var dentalOrder = [['Sovereign',0,'a0M2000000xVgPH'],['Sovereign Classic',0,'a0M2000000xVgPM'],['Compact i Touch',0,'a0M2000000xVgPR']];

var handpieceOrder = [['',0,'a0M2000000xVgOk'],['',0,'a0M2000000xVgOi'],['',0,'a0M2000000xVgOj'],['',0,'a0M2000000xVgOp'],['',0,'a0M2000000xVgOq'],['',0,'a0M2000000xVgOr'],['',0,'a0M2000000xVgOl'],['',0,'a0M2000000xVgOm'],['',0,'a0M2000000xVgOn'],['',0,'a0M2000000xVgOo']];

var dentalUnit = [
		{
			brand: 'Legrin',
			model: 'L515',
			state_mark: 2,
			serv_diagnos: 'active',
			serv_repair: 'active',
			serv_svc: '',
			coment: '',
			date_month: 'April',
			date_year: '2013',
			image: 'images/lib/legrin/l515.jpg'
		}, 
		{
			brand: 'Diplomat',
			model: 'Adept DA270',
			state_mark: 4,
			serv_diagnos: '',
			serv_repair: '',
			serv_svc: 'active',
			coment: 'dgetmdj,hk.k.dhjmdsghmdj djmju,mdey',
			date_month: 'November',
			date_year: '2009',
			image: 'images/lib/diplomat/adept-da270.jpg'
		} 


];



// localStorage  loading

$(document).ready(function(){
	
	localStorage.clear();
	localStorage.setItem('storage_dentalUnit', JSON.stringify(dentalUnit));      // console.log(JSON.stringify(dentalUnit));	
	localStorage.setItem('storage_dentalOrder', JSON.stringify(dentalOrder)); 
	localStorage.setItem('storage_handpieceOrder', JSON.stringify(handpieceOrder));  

	
});


