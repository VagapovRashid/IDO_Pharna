// JavaScript Document


var dentalOrder = [
	['Sovereign',0,'a0M2000000xVgPH'],
	['Sovereign Classic',0,'a0M2000000xVgPM'],
	['Compact i Touch',0,'a0M2000000xVgPR']
];

var handpieceOrder = [
	['14ES',0,'a0M2000000xVgOk'],
	['10ES',0,'a0M2000000xVgOi'],
	['31ES',0,'a0M2000000xVgOj'],
	['T25',0,'a0M2000000xVgOp'],
	['T7',0,'a0M2000000xVgOq'],
	['T9000',0,'a0M2000000xVgOr'],
	['E25L',0,'a0M2000000xVgOl'],
	['7LP',0,'a0M2000000xVgOm'],
	['9000L',0,'a0M2000000xVgOn'],
	['25LP',0,'a0M2000000xVgOo']];

var dentalUnit = [
		{
			brand: 'Legrin',
			model: 'L515',
			state_mark: 2,
			serv_diagnos: 'active',
			serv_repair: 'active',
			serv_svc: '',
			coment: '',
			date_month: 'April',
			date_year: '2013',
			image: 'images/lib/legrin/l515.jpg'
		}, 
		{
			brand: 'Diplomat',
			model: 'Adept DA270',
			state_mark: 4,
			serv_diagnos: '',
			serv_repair: '',
			serv_svc: 'active',
			coment: 'dgetmdj,hk.k.dhjmdsghmdj djmju,mdey',
			date_month: 'November',
			date_year: '2009',
			image: 'images/lib/diplomat/adept-da270.jpg'
		} 
];


var inventoryID = [['L515','a0M2000000xVPEz'],['L520-505','a0M2000000xVPF0'],['L540','a0M2000000xVPF1'],['LINEA Patavium FE','a0M2000000xVPF2'],['OMS Tempo PX-New','a0M2000000xVPF3'],
	['TEMPO 9 ELX','a0M2000000xVPF4'],['Premier05','a0M2000000xVPF5'],['Premier08new','a0M2000000xVPF6'],['Premier10','a0M2000000xVPF7'],['Premier11','a0M2000000xVPF8'],
	['Premier15','a0M2000000xVPF9'],['Premier16','a0M2000000xVPFA'],['Premier17','a0M2000000xVPFB'],['Impuls S200','a0M2000000xVPFC'],['Impuls S300','a0M2000000xVPFD'],
	['Impuls S100','a0M2000000xVPFE'],['Impuls S100 NEO','a0M2000000xVPFF'],['Harmony S100','a0M2000000xVPFG'],['Harmony S200','a0M2000000xVPFH'],
	['Harmony S300','a0M2000000xVPFI'],['V100','a0M2000000xVPFJ'],['V200','a0M2000000xVPFK'],['V300','a0M2000000xVPFL'],['SD-80','a0M2000000xVPFM'],
	['SD-300','a0M2000000xVPFN'],['SD-150','a0M2000000xVPFO'],['SD-175','a0M2000000xVPFP'],['SD-350','a0M2000000xVPFQ'],['Adept DA270','a0M2000000xVPFR'],
	['Adept DA280','a0M2000000xVPFS'],['Adept DA370','a0M2000000xVPFT'],['Adept DA380','a0M2000000xVPFU'],['CONSUL DC350','a0M2000000xVPFV'],
	['CONSUL DC310','a0M2000000xVPFW'],['CONSUL DC180','a0M2000000xVPFX'],['CONSUL DC170','a0M2000000xVPFY'],['LUX DL210','a0M2000000xVPFZ'],['LUX DL320','a0M2000000xVPFa'],
	['C1000','a0M2000000xVPFb'],['L1000','a0M2000000xVPFc'],['LW1000','a0M2000000xVPFd'],['S1000','a0M2000000xVPFe'],['SW1000','a0M2000000xVPFf'],
	['Challenge','a0M2000000xVPFg'],['Challenge ever','a0M2000000xVPFh'],['Challenge-2','a0M2000000xVPFh']];



// localStorage  loading

$(document).ready(function(){
	
	localStorage.clear();
	localStorage.setItem('storage_dentalUnit', JSON.stringify(dentalUnit));      // console.log(JSON.stringify(dentalUnit));
	localStorage.setItem('dentalOrder', JSON.stringify(dentalOrder));
	localStorage.setItem('handpieceOrder', JSON.stringify(handpieceOrder));
	localStorage.setItem('InventoryIds', JSON.stringify(inventoryID));

});


