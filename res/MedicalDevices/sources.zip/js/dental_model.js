// JavaScript Document

$(document).ready(function(){
		 
		var dentalOrder = JSON.parse(localStorage.getItem('storage_dentalOrder'));
		//document.getElementById('input-dentalOrder').value = JSON.stringify(dentalOrder); 					 


// ----------------------------------------------------------------------------------------  Spritespin
	
		$('.spritespin').spritespin({
			source: SpriteSpin.sourceArray('images/sovereign/sv_zoom_{frame}.jpg', { frame: [1,20], digits: 3 }),
			width: 464,
			height: 534,
			frames: 20,
			sense: -1,
			animate : false,
			renderer: 'canvas'
		});
		
		
// ----------------------------------------------------------------------------------------   Order  Count
		
		var countStart = dentalOrder[0][1];																		//console.log(countStart);

		window.globalWheelBrand = new Swiper('#wheel_count',{
			centeredSlides: true,
			slidesPerView: 5,
			initialSlide: countStart,
			loop: true,
			onTouchEnd : function() {
				countStart = parseInt($('#wheel_count .swiper-slide-active').html());									
			}
		});
	

// ----------------------------------------------------------------------------------------   Add to Order  

		var orderBtn = document.getElementById("order_btn");
		
		orderBtn.addEventListener('touchend', function(event) {
			
			$('#order_btn').toggleClass('active');
			 
			if( this.className=="check_box active" ){
				$(".box_coment").addClass('open');                    
			}else {
				$(".box_coment").removeClass('open');
				dentalOrder[0][1] = 0;
				localStorage.setItem('storage_dentalOrder', JSON.stringify(dentalOrder)); 
				//document.getElementById('input-dentalOrder').value = JSON.stringify(dentalOrder); 	
			};
		});


		var saveOrder = document.getElementById("save_order");		

		saveOrder.addEventListener('touchend', function(event) { 
			$(".box_coment").removeClass('open');
		
			dentalOrder[0][1] = countStart;
			localStorage.setItem('storage_dentalOrder', JSON.stringify(dentalOrder)); 
			//document.getElementById('input-dentalOrder').value = JSON.stringify(dentalOrder); 					 
		});



});

