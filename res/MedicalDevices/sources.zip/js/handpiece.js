// JavaScript Document

$(document).ready(function(){
		 
		//var handpieceOrder = [['',0],['',0],['',0],['',0],['',0],['',0],['',0],['',0],['',0],['',0]];
		var handpieceOrder = JSON.parse(localStorage.getItem('storage_handpieceOrder'));

		//localStorage.setItem('storage_handpieceOrder', JSON.stringify(handpieceOrder)); 
		//document.getElementById('input-handpieceOrder').value = JSON.stringify(handpieceOrder); 					 


// ----------------------------------------------------------------------------------------   Brand  Model

		window.globalWheelBrand = new Swiper('#wheel_brand',{
			centeredSlides: true,
			slidesPerView: 3,
			initialSlide: 1,
			loop: true,
			onTouchEnd : function() {
				$(".tip").removeClass('active');
				$(".tip_set").removeClass('open');
				 
				var nameSlide = $('#wheel_brand .swiper-slide-active strong').text();								//console.log(nameSlide);	
				$(".tip_set."+nameSlide).addClass('open');								
			}
		});
	
	
// ----------------------------------------------------------------------------------------   Tips desc
	
		var tipBtns = getElementsByClassName("tip");  
		
		for(var i = 0; i < tipBtns.length; i++) {
			tipBtns[i].addEventListener('click', function(event) { 
			
				if( this.className=='tip' ) {
					$(".tip").removeClass('active');
					this.className += ' active';
				}else {
					this.className = 'tip';
				};
			});
		};
	
	
// ----------------------------------------------------------------------------------------   Order  Counter
	
		Hammer(document.getElementById("tip-1")).on("swipedown", function(ev) {						//console.log('-----');
			var counter = parseInt($("#tip-1 .counter span").html());														
			counter = ( counter>0 ) ? counter-1 : 0;												//console.log(counter);
			$("#tip-1 .counter span").html(counter);
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-1 .counter").addClass('down');
		});
		Hammer(document.getElementById("tip-1")).on("swipeup", function(ev) {					//console.log('+++++');
			var counter = parseInt($("#tip-1 .counter span").html());							
			counter++;																			//console.log(counter);
			$("#tip-1 .counter span").html(counter+'');
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-1 .counter").addClass('up');
		});

		Hammer(document.getElementById("tip-2")).on("swipedown", function(ev) {						 
			var counter = parseInt($("#tip-2 .counter span").html());														
			counter = ( counter>0 ) ? counter-1 : 0;												 
			$("#tip-2 .counter span").html(counter);
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-2 .counter").addClass('down');
		});
		Hammer(document.getElementById("tip-2")).on("swipeup", function(ev) {					 
			var counter = parseInt($("#tip-2 .counter span").html());							
			counter++;																			 
			$("#tip-2 .counter span").html(counter+'');
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-2 .counter").addClass('up');
		});

		Hammer(document.getElementById("tip-3")).on("swipedown", function(ev) {						 
			var counter = parseInt($("#tip-3 .counter span").html());														
			counter = ( counter>0 ) ? counter-1 : 0;												 
			$("#tip-3 .counter span").html(counter);
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-3 .counter").addClass('down');
		});
		Hammer(document.getElementById("tip-3")).on("swipeup", function(ev) {					 
			var counter = parseInt($("#tip-3 .counter span").html());							
			counter++;																			 
			$("#tip-3 .counter span").html(counter+'');
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-3 .counter").addClass('up');
		});

		Hammer(document.getElementById("tip-4")).on("swipedown", function(ev) {						 
			var counter = parseInt($("#tip-4 .counter span").html());														
			counter = ( counter>0 ) ? counter-1 : 0;												 
			$("#tip-4 .counter span").html(counter);
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-4 .counter").addClass('down');
		});
		Hammer(document.getElementById("tip-4")).on("swipeup", function(ev) {					 
			var counter = parseInt($("#tip-4 .counter span").html());							
			counter++;																			 
			$("#tip-4 .counter span").html(counter+'');
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-4 .counter").addClass('up');
		});

		Hammer(document.getElementById("tip-5")).on("swipedown", function(ev) {						 
			var counter = parseInt($("#tip-5 .counter span").html());														
			counter = ( counter>0 ) ? counter-1 : 0;												 
			$("#tip-5 .counter span").html(counter);
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-5 .counter").addClass('down');
		});
		Hammer(document.getElementById("tip-5")).on("swipeup", function(ev) {					 
			var counter = parseInt($("#tip-5 .counter span").html());							
			counter++;																			 
			$("#tip-5 .counter span").html(counter+'');
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-5 .counter").addClass('up');
		});

		Hammer(document.getElementById("tip-6")).on("swipedown", function(ev) {						 
			var counter = parseInt($("#tip-6 .counter span").html());														
			counter = ( counter>0 ) ? counter-1 : 0;												 
			$("#tip-6 .counter span").html(counter);
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-6 .counter").addClass('down');
		});
		Hammer(document.getElementById("tip-6")).on("swipeup", function(ev) {					 
			var counter = parseInt($("#tip-6 .counter span").html());							
			counter++;																			 
			$("#tip-6 .counter span").html(counter+'');
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-6 .counter").addClass('up');
		});

		Hammer(document.getElementById("tip-7")).on("swipedown", function(ev) {						 
			var counter = parseInt($("#tip-7 .counter span").html());														
			counter = ( counter>0 ) ? counter-1 : 0;												 
			$("#tip-7 .counter span").html(counter);
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-7 .counter").addClass('down');
		});
		Hammer(document.getElementById("tip-7")).on("swipeup", function(ev) {					 
			var counter = parseInt($("#tip-7 .counter span").html());							
			counter++;																			 
			$("#tip-7 .counter span").html(counter+'');
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-7 .counter").addClass('up');
		});

		Hammer(document.getElementById("tip-8")).on("swipedown", function(ev) {						 
			var counter = parseInt($("#tip-8 .counter span").html());														
			counter = ( counter>0 ) ? counter-1 : 0;												 
			$("#tip-8 .counter span").html(counter);
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-8 .counter").addClass('down');
		});
		Hammer(document.getElementById("tip-8")).on("swipeup", function(ev) {					 
			var counter = parseInt($("#tip-8 .counter span").html());							
			counter++;																			 
			$("#tip-8 .counter span").html(counter+'');
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-8 .counter").addClass('up');
		});

		Hammer(document.getElementById("tip-9")).on("swipedown", function(ev) {						 
			var counter = parseInt($("#tip-9 .counter span").html());														
			counter = ( counter>0 ) ? counter-1 : 0;												 
			$("#tip-9 .counter span").html(counter);
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-9 .counter").addClass('down');
		});
		Hammer(document.getElementById("tip-9")).on("swipeup", function(ev) {					 
			var counter = parseInt($("#tip-9 .counter span").html());							
			counter++;																			 
			$("#tip-9 .counter span").html(counter+'');
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-9 .counter").addClass('up');
		});

		Hammer(document.getElementById("tip-10")).on("swipedown", function(ev) {						 
			var counter = parseInt($("#tip-10 .counter span").html());														
			counter = ( counter>0 ) ? counter-1 : 0;												 
			$("#tip-10 .counter span").html(counter);
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-10 .counter").addClass('down');
		});
		Hammer(document.getElementById("tip-10")).on("swipeup", function(ev) {					 
			var counter = parseInt($("#tip-10 .counter span").html());							
			counter++;																			 
			$("#tip-10 .counter span").html(counter+'');
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-10 .counter").addClass('up');
		});



// ----------------------------------------------------------------------------------------   Add to Order  

		var saveOrder = document.getElementById("save_order");		

		saveOrder.addEventListener('touchend', function(event) { 
		
			$("#save_order").addClass('active');
			setTimeout( function() { 
				$("#save_order").removeClass('active');
			}, 1800);
		
		  	$(".tip").each(function(j) {
				var modelTip = $(this).find('h4').html();
				var countTip = parseInt($(this).find('.counter').children('span').html());
				
				handpieceOrder[j][0] = modelTip;
				handpieceOrder[j][1] = countTip;
			});
		
			localStorage.setItem('storage_handpieceOrder', JSON.stringify(handpieceOrder)); 
			//document.getElementById('input-handpieceOrder').value = JSON.stringify(handpieceOrder); 					 
		});



});

