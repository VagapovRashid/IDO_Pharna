// JavaScript Document

$(document).ready(function(){
		 
		var dentalOrder = JSON.parse(localStorage.getItem('dentalOrder'));


// ----------------------------------------------------------------------------------------   Current  Counter

		$("#tip-1 .counter span").html(dentalOrder[0][1]+'');
		$("#tip-2 .counter span").html(dentalOrder[1][1]+'');
		$("#tip-3 .counter span").html(dentalOrder[2][1]+'');


// ----------------------------------------------------------------------------------------   Order  Counter
	
		Hammer(document.getElementById("tip-1")).on("swipedown", function(ev) {						//console.log('-----');
			var counter = parseInt($("#tip-1 .counter span").html());														
			counter = ( counter>0 ) ? counter-1 : 0;												//console.log(counter);
			$("#tip-1 .counter span").html(counter);
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-1 .counter").addClass('down');
		});
		Hammer(document.getElementById("tip-1")).on("swipeup", function(ev) {					//console.log('+++++');
			var counter = parseInt($("#tip-1 .counter span").html());							
			counter++;																			//console.log(counter);
			$("#tip-1 .counter span").html(counter+'');
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-1 .counter").addClass('up');
		});

		Hammer(document.getElementById("tip-2")).on("swipedown", function(ev) {						 
			var counter = parseInt($("#tip-2 .counter span").html());														
			counter = ( counter>0 ) ? counter-1 : 0;												 
			$("#tip-2 .counter span").html(counter);
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-2 .counter").addClass('down');
		});
		Hammer(document.getElementById("tip-2")).on("swipeup", function(ev) {					 
			var counter = parseInt($("#tip-2 .counter span").html());							
			counter++;																			 
			$("#tip-2 .counter span").html(counter+'');
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-2 .counter").addClass('up');
		});

		Hammer(document.getElementById("tip-3")).on("swipedown", function(ev) {						 
			var counter = parseInt($("#tip-3 .counter span").html());														
			counter = ( counter>0 ) ? counter-1 : 0;												 
			$("#tip-3 .counter span").html(counter);
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-3 .counter").addClass('down');
		});
		Hammer(document.getElementById("tip-3")).on("swipeup", function(ev) {					 
			var counter = parseInt($("#tip-3 .counter span").html());							
			counter++;																			 
			$("#tip-3 .counter span").html(counter+'');
			$(".counter").removeClass('down').removeClass('up');
			$("#tip-3 .counter").addClass('up');
		});
		


// ----------------------------------------------------------------------------------------   Add to Order  

		var saveOrder = document.getElementById("save_order");		

		saveOrder.addEventListener('touchend', function(event) { 
		
			$("#save_order").addClass('active');
			setTimeout( function() { 
				$("#save_order").removeClass('active');
			}, 1800);
		
		  	$(".tip").each(function(j) {
				var modelTip = $(this).attr("data-tip");
				var countTip = parseInt($(this).find('.counter').children('span').html());

				for(var i = 0; i < dentalOrder.length; i++) {
					if( dentalOrder[j][0]===modelTip ) {
						dentalOrder[j][1] = countTip;
					};
				};
			});
		
			localStorage.setItem('dentalOrder', JSON.stringify(dentalOrder));

		});



});

