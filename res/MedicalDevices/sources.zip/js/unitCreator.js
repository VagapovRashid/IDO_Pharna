// JavaScript Document

$(document).ready(function(){
	
		var dentalUnit = JSON.parse(localStorage.getItem('storage_dentalUnit'));
		var dentalOrder = JSON.parse(localStorage.getItem('dentalOrder'));
		
		 
		var itemUnit = {
							brand: '',
							model: '',
							state_mark: 0,
							serv_diagnos: '',
							serv_repair: '',
							serv_svc: '',
							coment: '',
							date_month: 'February',
							date_year: '2007',
							image: 'images/lib/'
						};
						
		var helperUnit = $.extend({},itemUnit);
		var imgModel = 'images/lib/';
		var countHelper = 0;
		

		
// ------------------------------------------------------------------------------------- choise from list-unit
		$(".copyNewUnit li").bind("click", function(){																
			
			indexNewItem = parseInt($(this).attr('data-stack'));																	 	
			helperUnit = dentalUnit[indexNewItem];
																											//console.log('edit____'+indexNewItem);	
			$("ul.stars_list li").removeClass('active');
			for(var k = 1; k <= helperUnit.state_mark; k++) {            	
				$('ul.stars_list li:nth-child('+k+')').addClass('active');           
			};
			$("ul.check_list li").removeClass('active');
			$('ul.check_list li:nth-child(1)').addClass(helperUnit.serv_diagnos);   
			$('ul.check_list li:nth-child(2)').addClass(helperUnit.serv_repair);            
			$('ul.check_list li:nth-child(3)').addClass(helperUnit.serv_svc);            
			
			if( helperUnit.coment!='' ) {
				$(".box_coment textarea").val(helperUnit.coment);
				$(".box_coment").removeClass('empty_coment');
			}else {
				$(".box_coment textarea").val('Notice...');
				$(".box_coment").addClass('empty_coment');
			};
			
			$(".box_scroll").addClass('disable');
			$(".unit_creator").addClass('open');
			
			BrandModel(1);
			ServiceDate(1);
		});    
		
		
		
// ----------------------------------------------------------------------------------------   Setup
	
		for(var m = 0; m < dentalUnit.length; m++) {
			
			var newUnit = $(".copyNewUnit li").clone(true).insertBefore("ul.units li.creator");
			newUnit.attr({'data-stack':m+''});
			
			newUnit.find('h4').html(dentalUnit[m].brand);
			newUnit.find('h5').html(dentalUnit[m].model);
			newUnit.find('p.status').removeAttr('class').addClass('status').addClass('s'+dentalUnit[m].state_mark);
			newUnit.find('.visual .unit_img').css({'background-image':'url('+dentalUnit[m].image+')' });
			
			newUnit.find('.service span:nth-child(1)').removeClass('active').addClass(dentalUnit[m].serv_diagnos);   
			newUnit.find('.service span:nth-child(2)').removeClass('active').addClass(dentalUnit[m].serv_repair);            
			newUnit.find('.service span:nth-child(3)').removeClass('active').addClass(dentalUnit[m].serv_svc);            
		};
		
		if( dentalUnit.length>3 ) {
			boxScroll.refresh();	
		};
							 


// ----------------------------------------------------------------------------------------   Brand  Model

function ImageModel() {
		imgModel = 'images/lib/';
		helperUnit.image = imgModel + helperUnit.brand +'/'+ helperUnit.model +'.jpg';
					
		imgModel = helperUnit.image.split(' ');
		helperUnit.image = imgModel.join('-');
		helperUnit.image = helperUnit.image.toLowerCase();
		
		$("#unit_img").css({'background-image':'url('+helperUnit.image+')' });
};



function BrandModel( statusCreat ) {
		var arrBrand = [0,0,0,0,0,0,0,0,0];
		
		$(".model_st .swiper-container").removeClass('onbrand');

		if( statusCreat<0 ) {
			var brandStart = 0,
				modelStart = 0;
			$(".model_st>div:nth-child(1)").addClass('onbrand');
			helperUnit.brand = 'Ancar';
			helperUnit.model = 'SD-80';
			ImageModel();
		}
		else {
			var brandCurrent = $('.copyBrand div.swiper-slide[data-state="'+helperUnit.brand+'"]');     
			var brandStart = $('.copyBrand div.swiper-slide').index(brandCurrent);	
			$("#"+helperUnit.brand).addClass('onbrand');		
			
			var modelCurrent = $('.copy'+helperUnit.brand+' div.swiper-slide[data-state="'+helperUnit.model+'"]');     
			var modelStart = $('.copy'+helperUnit.brand+' div.swiper-slide').index(modelCurrent);
			ImageModel();			
		};
		arrBrand[brandStart] = modelStart;
		
		
		$('#wheel_brand').html( $('.fantom_storage .copyBrand').html() );
		if (countHelper>0) window.globalWheelBrand.destroy(true);
		window.globalWheelBrand = new Swiper('#wheel_brand',{
			centeredSlides: true,
			slidesPerView: 3,
			initialSlide: brandStart,
			loop: true,
			onTouchStart : function() {
				$('#wheel_brand .swiper-slide-visible').css({'opacity':0.4});
			},
			onTouchEnd : function() {
				$('#wheel_brand .swiper-slide-visible').css({'opacity':0});
				helperUnit.brand = $('#wheel_brand .swiper-slide-active').html();
									 
				$(".model_st .swiper-container").removeClass('onbrand');
				$("#"+helperUnit.brand).addClass('onbrand');
				
				helperUnit.model = $('#'+helperUnit.brand+' .swiper-wrapper .swiper-slide-active').html();									//console.log(JSON.stringify(helperUnit));	
				ImageModel();																												//console.log(helperUnit.image);
			}
		});
		
		$('#Ancar').html( $('.fantom_storage .copyAncar').html() );
		if (countHelper>0) window.globalAncar.destroy(true);
		window.globalAncar = new Swiper('#Ancar',{
			centeredSlides: true,
			slidesPerView: 3,
			initialSlide: arrBrand[0],
			loop: true,
			onTouchStart : function() {
				$('#Ancar .swiper-slide-visible').css({'opacity':0.4});
			},
			onTouchEnd : function() {
				$('#Ancar .swiper-slide-visible').css({'opacity':0});
				helperUnit.model = $('.model_st .onbrand .swiper-slide-active').html();
				ImageModel();			 
			}
		});	
		
		$('#Diplomat').html( $('.fantom_storage .copyDiplomat').html() );
		if (countHelper>0) window.globalDiplomat.destroy(true);
		window.globalDiplomat = new Swiper('#Diplomat',{
			centeredSlides: true,
			slidesPerView: 3,
			initialSlide: arrBrand[1],
			loop: true,
			onTouchStart : function() {
				$('#Diplomat .swiper-slide-visible').css({'opacity':0.4});
			},
			onTouchEnd : function() {
				$('#Diplomat .swiper-slide-visible').css({'opacity':0});
				helperUnit.model = $('.model_st .onbrand .swiper-slide-active').html();	
				ImageModel();		 
			}
		});
		
		$('#Fona').html( $('.fantom_storage .copyFona').html() );
		if (countHelper>0) window.globalFona.destroy(true);
		window.globalFona = new Swiper('#Fona',{
			centeredSlides: true,
			slidesPerView: 3,
			initialSlide: arrBrand[2],
			loop: true,
			onTouchStart : function() {
				$('#Fona .swiper-slide-visible').css({'opacity':0.4});
			},
			onTouchEnd : function() {
				$('#Fona .swiper-slide-visible').css({'opacity':0});
				helperUnit.model = $('.model_st .onbrand .swiper-slide-active').html();	
				ImageModel();		 
			}
		});
		
		$('#Hallim').html( $('.fantom_storage .copyHallim').html() );
		if (countHelper>0) window.globalHallim.destroy(true);
		window.globalHallim = new Swiper('#Hallim',{
			centeredSlides: true,
			slidesPerView: 3,
			initialSlide: arrBrand[3],
			loop: true,
			onTouchStart : function() {
				$('#Hallim .swiper-slide-visible').css({'opacity':0.4});
			},
			onTouchEnd : function() {
				$('#Hallim .swiper-slide-visible').css({'opacity':0});
				helperUnit.model = $('.model_st .onbrand .swiper-slide-active').html();	
				ImageModel();		 
			}
		});	
		
		$('#Legrin').html( $('.fantom_storage .copyLegrin').html() );
		if (countHelper>0) window.globalLegrin.destroy(true);
		window.globalLegrin = new Swiper('#Legrin',{
			centeredSlides: true,
			slidesPerView: 3,
			initialSlide: arrBrand[4],
			loop: true,
			onTouchStart : function() {
				$('#Legrin .swiper-slide-visible').css({'opacity':0.4});
			},
			onTouchEnd : function() {
				$('#Legrin .swiper-slide-visible').css({'opacity':0});
				helperUnit.model = $('.model_st .onbrand .swiper-slide-active').html();	
				ImageModel();		 
			}
		});	
		
		$('#Oms').html( $('.fantom_storage .copyOms').html() );
		if (countHelper>0) window.globalOms.destroy(true);
		window.globalOms = new Swiper('#Oms',{
			centeredSlides: true,
			slidesPerView: 3,
			initialSlide: arrBrand[5],
			loop: true,
			onTouchStart : function() {
				$('#Oms .swiper-slide-visible').css({'opacity':0.4});
			},
			onTouchEnd : function() {
				$('#Oms .swiper-slide-visible').css({'opacity':0});
				helperUnit.model = $('.model_st .onbrand .swiper-slide-active').html();	
				ImageModel();		 
			}
		});	
		
		$('#Premier').html( $('.fantom_storage .copyPremier').html() );
		if (countHelper>0) window.globalPremier.destroy(true);
		window.globalPremier = new Swiper('#Premier',{
			centeredSlides: true,
			slidesPerView: 3,
			initialSlide: arrBrand[6],
			loop: true,
			onTouchStart : function() {
				$('#Premier .swiper-slide-visible').css({'opacity':0.4});
			},
			onTouchEnd : function() {
				$('#Premier .swiper-slide-visible').css({'opacity':0});
				helperUnit.model = $('.model_st .onbrand .swiper-slide-active').html();	
				ImageModel();		 
			}
		});	
		
		$('#Stomadent').html( $('.fantom_storage .copyStomadent').html() );
		if (countHelper>0) window.globalStomadent.destroy(true);
		window.globalStomadent = new Swiper('#Stomadent',{
			centeredSlides: true,
			slidesPerView: 3,
			initialSlide: arrBrand[7],
			loop: true,
			onTouchStart : function() {
				$('#Stomadent .swiper-slide-visible').css({'opacity':0.4});
			},
			onTouchEnd : function() {
				$('#Stomadent .swiper-slide-visible').css({'opacity':0});
				helperUnit.model = $('.model_st .onbrand .swiper-slide-active').html();	
				ImageModel();		 
			}
		});	
		
		$('#Victor').html( $('.fantom_storage .copyVictor').html() );
		if (countHelper>0) window.globalVictor.destroy(true);
		window.globalVictor = new Swiper('#Victor',{
			centeredSlides: true,
			slidesPerView: 3,
			initialSlide: arrBrand[8],
			loop: true,
			onTouchStart : function() {
				$('#Victor .swiper-slide-visible').css({'opacity':0.4});
			},
			onTouchEnd : function() {
				$('#Victor .swiper-slide-visible').css({'opacity':0});
				helperUnit.model = $('.model_st .onbrand .swiper-slide-active').html();	
				ImageModel();		 
			}
		});	
		
};
	
	
// ----------------------------------------------------------------------------------------   Service  Date

function ServiceDate( statusCreat ) {
	
		if( statusCreat<0 ) {
			var monStart = 1,
				yearStart = 1;
		}else {
			var monCurrent = $('.copyMonth div.swiper-slide[data-state="'+helperUnit.date_month+'"]');     
			var monStart = $('.copyMonth div.swiper-slide').index(monCurrent);			
			
			var yearCurrent = $('.copyYear div.swiper-slide[data-state="'+helperUnit.date_year+'"]');     
			var yearStart = $('.copyYear div.swiper-slide').index(yearCurrent);			
		};
		
		$('#wheel_month').html( $('.fantom_storage .copyMonth').html() );
		if (countHelper>0) window.globalWheelMonth.destroy(true);
		window.globalWheelMonth = new Swiper('#wheel_month',{
			centeredSlides: true,
			slidesPerView: 5,
			initialSlide: monStart,
			mode: 'vertical',
			loop: true,
			onTouchEnd : function() {
				helperUnit.date_month = $('#wheel_month .swiper-slide-active').html();	
			}
		});	
																						
		$('#wheel_year').html( $('.fantom_storage .copyYear').html() );
		if (countHelper>0) window.globalWheelYear.destroy(true);
		window.globalWheelYear = new Swiper('#wheel_year',{
			centeredSlides: true,
			slidesPerView: 5,
			initialSlide: yearStart,
			mode: 'vertical',
			loop: true,
			onTouchEnd : function() {
				helperUnit.date_year = $('#wheel_year .swiper-slide-active').html();	
			}
		});																											//console.log('monStart '+window.globalWheelMonth.activeIndex);
					
};

	
	
// ----------------------------------------------------------------------------------------   Unit Create

			var indexNewItem = 0;
			var triggerOver = false;
			
			var creatorBtn = getElementsByClassName("add_unit")[0];  
			// --------------------------------------------------------- create
			creatorBtn.addEventListener('touchend', function(event) { 
				var clickedLi = $("ul.units li.creator")
				indexNewItem = $("ul.units li").index(clickedLi);													//console.log('creator___'+indexNewItem);					 	
				
				helperUnit = $.extend({},itemUnit);
				
				$("ul.stars_list li").removeClass('active');
				$("ul.check_list li").removeClass('active');
				$(".box_coment textarea").val('Notice...');
				$(".box_coment").addClass('empty_coment');
				
				$(".box_scroll").addClass('disable');
				$(".unit_creator").addClass('open');
				$(".box_brand").addClass('empty_unit');
				$("#unit_img").addClass('empty_unit');
				
				BrandModel(-1);
				ServiceDate(-1);
				
				countHelper = 5;
			});
			Hammer(document.getElementById("brand_over")).on("dragright", function(ev) {						 
				$(".brand_over").parent('.box_brand').removeClass('empty_unit');
				triggerOver = true;
			});
			Hammer(document.getElementById("brand_over")).on("dragleft", function(ev) {						 
				$(".brand_over").parent('.box_brand').removeClass('empty_unit');
				triggerOver = true;
			});
			Hammer(document.getElementById("model_over")).on("dragright", function(ev) {						 
				if( triggerOver ) {
					$(".model_over").parent('.box_brand').removeClass('empty_unit');
					$("#unit_img").removeClass('empty_unit');
					triggerOver = false;	
				};
			});
			Hammer(document.getElementById("model_over")).on("dragleft", function(ev) {						 
				if( triggerOver ) {
					$(".model_over").parent('.box_brand').removeClass('empty_unit');
					$("#unit_img").removeClass('empty_unit');
					triggerOver = false;	
				};
			});
			
			
	
			var starBtns = getElementsByClassName("star");  
			// ---------------------------------------------------------  state mark ON
			for(var i = 0; i < starBtns.length; i++) {
				starBtns[i].addEventListener('click', function(event) { 
					var indexBtn = starBtns.indexOf(this)+1;						 	
					
					$(".star").removeClass('active');
					this.className += ' active';
					$('ul.stars_list li:nth-child('+indexBtn+')').prevAll('li.star').addClass('active');
					
					helperUnit.state_mark = indexBtn;
				});
			};
	
			$('#stars_list').draggable({
				axis: "x",
				containment:"parent",
				revert: true,
				revertDuration:10,
				drag: function( event, ui ) {
					var draggMove = event.pageX;	
					var starMark = 0;															console.log(draggMove);
					
					starMark = Math.round((Math.abs(draggMove-35))/65)+1; 						//console.log(starMark);
					
					$(".star").removeClass('active');
					if ( starMark>5 ) {
						$(".star").addClass('active');
						helperUnit.state_mark = 5;
					} else {
						$('ul.stars_list li:nth-child('+starMark+')').prevAll('li.star').addClass('active'); 
						helperUnit.state_mark = starMark-1;
					};
				} 
			});
	

 
 
			var checkBtns = getElementsByClassName("check_box");  
			// ---------------------------------------------------------  services ON
			for(var i = 0; i < checkBtns.length; i++) {
				checkBtns[i].addEventListener('touchend', function(event) { 
					var indexBtn = checkBtns.indexOf(this)+1;	
										 	
					$('ul.check_list li:nth-child('+indexBtn+')').toggleClass('active');
					
					switch (indexBtn) {
						case 1:
								helperUnit.serv_diagnos = ( this.className=="check_box" ) ? '' : 'active';	
								break;
						case 2:
								helperUnit.serv_repair = ( this.className=="check_box" ) ? '' : 'active';	
								break;
						case 3:
								helperUnit.serv_svc = ( this.className=="check_box" ) ? '' : 'active';	
								if( this.className=="check_box active" ){
									$(".box_coment").addClass('open');
								}else {
									$(".box_coment").removeClass('open').addClass('empty_coment');
									$(".box_coment textarea").val('Notice...');
									helperUnit.coment = '';
								};
								break;
						default: break;
					};
				});
			};
			
			// ---------------------------------------------------------  save coment ON
			document.getElementById('save_coment').addEventListener('click', function(event) { 
				helperUnit.coment = ( $(".box_coment textarea").val()!='Notice...' ) ? $(".box_coment textarea").val() : '';
				$(".box_coment").removeClass('open').addClass('empty_coment');																//console.log(JSON.stringify(helperUnit));
			});
	
			$(".box_coment textarea").focus(function(){
				if( $(".box_coment").hasClass('empty_coment') ) {
					$(".box_coment textarea").val('');
					$(".box_coment").removeClass('empty_coment');
				};
			});
	
	
	
			// ------------------------------------------------------------------------------------- save  unit
			document.getElementById('save_unit').addEventListener('click', function(event) { 
				
				if( $('ul.units li:nth-child('+(indexNewItem+1)+')').hasClass("creator") ) { 							//console.log('save creator____'+indexNewItem);
					dentalUnit.push(helperUnit)	;															
					var newUnit = $(".copyNewUnit li").clone(true).insertBefore("ul.units li.creator");
					newUnit.attr({'data-stack':indexNewItem+''});
					if( indexNewItem>2 ) {
						boxScroll.refresh();	
					};
				}else {
					dentalUnit[indexNewItem] = helperUnit;																//console.log('save editor____'+indexNewItem);
					var newUnit = $('ul.units li:nth-child('+(indexNewItem+1)+')');
				};
				localStorage.setItem('storage_dentalUnit', JSON.stringify(dentalUnit));									//console.log(JSON.stringify(dentalUnit));
				//document.getElementById('input-dentalUnit').value = JSON.stringify(dentalUnit);
				
				newUnit.find('h4').html(helperUnit.brand);
				newUnit.find('h5').html(helperUnit.model);
				newUnit.find('p.status').removeAttr('class').addClass('status').addClass('s'+helperUnit.state_mark);
                newUnit.find('.visual .unit_img').css({'background-image':'url('+helperUnit.image+')' });
				
				newUnit.find('.service span:nth-child(1)').removeClass('active').addClass(helperUnit.serv_diagnos);   
				newUnit.find('.service span:nth-child(2)').removeClass('active').addClass(helperUnit.serv_repair);            
				newUnit.find('.service span:nth-child(3)').removeClass('active').addClass(helperUnit.serv_svc);            
				
				$(".unit_creator").removeClass('open');
				$(".box_scroll").removeClass('disable');
			});
	
		


});

