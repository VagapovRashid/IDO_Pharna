// JavaScript Document

$(document).ready(function(){

// ----------------------------------------------------------------------------------------   Slide 1
		var countMask = 0;
		var draggStart = 0;

		$('#over').draggable({
			axis: "x",
			containment:"parent",
			revert: true,
			revertDuration:10,
			start: function( event, ui ) {
				draggStart = event.pageX;
			}, 
			drag: function( event, ui ) {
				var draggMove = event.pageX;															//console.log(draggMove);
				
				if ( draggStart<draggMove )  {
					countMask = ( countMask==100 ) ? 100 : countMask+5;
				}else  {
					countMask = ( countMask==0 ) ? 0 : countMask-5;
				};
				
				$("#over").css({'-webkit-mask-size':countMask+'% 100%'});
				draggStart = draggMove;
			} 
		});


// ----------------------------------------------------------------------------------------   Slide 2

		var countPosition = 0;
		var draggStart2 = 0;

		$('.position_wrapper').draggable({
			axis: "y",
			containment:"parent",
			revert: true,
			revertDuration:10,
			start: function( event, ui ) {
				draggStart2 = event.pageY;
			}, 
			drag: function( event, ui ) {
				var draggMove = event.pageY;															//console.log(draggMove);
				
				if ( draggStart2<draggMove )  {
					countPosition = ( countPosition==0 ) ? 0 : countPosition-7;
				}else  {
					countPosition = ( countPosition==77 ) ? 77 : countPosition+7;
				};																					//console.log(draggMove);
				
				$(".position").css({'-webkit-transform':'translate3d(0,-'+countPosition+'px,0)'});
				draggStart2 = draggMove;
			} 
		});
		

// ----------------------------------------------------------------------------------------   Slide 3

		var countState = 0;
		var draggStart3 = 0;

		$('.statespin_wrapper').draggable({
			axis: "y",
			containment:"parent",
			revert: true,
			revertDuration:10,
			start: function( event, ui ) {
				draggStart3 = event.pageY;
			}, 
			drag: function( event, ui ) {
				var draggMove = event.pageY;															//console.log(draggMove);
				
				if ( draggStart3<draggMove )  {
					countState = ( countState==52 ) ? 52 : countState+4;
				}else  {
					countState = ( countState==0 ) ? 0 : countState-4;
				};																					//console.log(draggMove);
				
				$(".state").css({'-webkit-transform':'rotate(-'+countState+'deg)'});
				$(".state_body").css({'-webkit-transform':'rotate('+countState+'deg)'});
				
				if ( countState==52 ) $(".statespin_wrapper").addClass('shadow');
				else  $(".statespin_wrapper").removeClass('shadow');
				
				draggStart3 = draggMove;
			} 
		});


// ----------------------------------------------------------------------------------------   Rotator
		var countRotate = 1;
		
		Hammer(document.getElementById("rotator")).on("swipeleft", function(ev) {						
			countRotate = ( countRotate==3 ) ? 1 : countRotate+1;										//console.log(countRotate);
				
			$(".slide, .box_note p, .box_content h2").removeClass('active');
			
			$('.visual .slide:nth-child('+countRotate+')').addClass('active');
			$('.box_note p:nth-child('+countRotate+')').addClass('active');
			$('.box_content h2:nth-child('+countRotate+')').addClass('active');
			
			countState = 0;
			$(".state").css({'-webkit-transform':'rotate(0deg)'});
			$(".state_body").css({'-webkit-transform':'rotate(0deg)'});
			$(".statespin_wrapper").removeClass('shadow');
			
			countPosition = 0;
			$(".position").css({'-webkit-transform':'translate3d(0,0,0)'});
		});
		Hammer(document.getElementById("rotator")).on("swiperight", function(ev) {					
			countRotate = ( countRotate==1 ) ? 3 : countRotate-1;										//console.log(countRotate);
				
			$(".slide, .box_note p, .box_content h2").removeClass('active');
			
			$('.visual .slide:nth-child('+countRotate+')').addClass('active');
			$('.box_note p:nth-child('+countRotate+')').addClass('active');
			$('.box_content h2:nth-child('+countRotate+')').addClass('active');
			
			countState = 0;
			$(".state").css({'-webkit-transform':'rotate(0deg)'});
			$(".state_body").css({'-webkit-transform':'rotate(0deg)'});
			$(".statespin_wrapper").removeClass('shadow');
			
			countPosition = 0;
			$(".position").css({'-webkit-transform':'translate3d(0,0,0)'});
		});







});

