$(document).ready(function(){

    $('.b > div:not(.but_result)').click(function(){
        
        if($(this).attr('data-key') != 'act'){
           
           
           if($('.but_result').css('display') == 'block'){
                
                $('.but_result').fadeOut();
                $('.but_result > p').delay(300).each(function(){
                   $(this).fadeOut(); 
                });
                
                
                $('.but_result .' + $(this).attr('data-but')).delay(400).fadeIn(); 
                $('.but_result').delay(300).fadeIn();
            } else {
                
           $('.but_result .' + $(this).attr('data-but')).fadeIn(); 
               $('.but_result').delay(300).fadeIn(); 
                
            }
                
           
            $('.b > div').each(function(){
               $(this).removeClass('act').attr('data-key', ''); 
            });
            
            $(this).addClass('act').attr('data-key', 'act');
        } else {
            $('.but_result').fadeOut();
            $('.but_result .' + $(this).attr('data-but')).fadeOut(); 
            $(this).removeClass('act').attr('data-key', '');
        }
    
    
    });
 
 $('.but_result').click(function(){
    $(this).fadeOut();
     $('.but_result > p').each(function(){
                   $(this).fadeOut(); 
                });
    $('.b > div:not(.but_result)').each(function(){
        $(this).removeClass('act').attr('data-key', '');
    });
    
 });

});