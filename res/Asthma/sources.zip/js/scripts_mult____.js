//$(function() {
	
	function SliderStorage (slideName) {
		var arrSliders = ['FullControl','0','HalfControl','0','NonControl','0'];
		var infoSliders = '';
		//alert(arrSliders[0]);
		
		$( ".slider" ).each(function(iClass){  
		
			var tooltip = $('<div class="tooltip" id="tooltip' + iClass+ '" />').addClass('txt_border');
			
			$(this).slider({
				animate: false,
				range: "min",
				value: 0,
				min: 1,
				max: 50,
				step: 1,
				create: function (event, ui){
					var value = $(this).slider("option", "value");
					$(this).find(".ui-slider-handle").addClass('shadow').text(value);
					$(this).find(".ui-slider-handle").prepend(tooltip);
					$('#tooltip'+iClass).text(value);
				},
				slide: function( event, ui ) {
					$(this).find(".ui-slider-handle").text(ui.value);
					$(this).find(".ui-slider-handle").prepend(tooltip);
					$('#tooltip'+iClass).text(ui.value);
					arrSliders[iClass*2+1] = ui.value+'';
				},
				start: function( event, ui ) {
					$('#tooltip'+iClass).css({'display': 'block'});
				},
				stop: function( event, ui ) {
					$('#tooltip'+iClass).css({'display': 'none'});
					infoSliders = slideName + '||' + arrSliders.join('|');
					document.getElementById('infosliders').value = infoSliders;
					if (this.id == "slider-1") $("input[sfield='common_number_of_patients__c']").val($("#slider-1").slider("value"));
					if (this.id == "slider-2") $("input[sfield='number_of_patients2__c']").val($("#slider-2").slider("value"));
					if (this.id == "slider-3") $("input[sfield='number_of_patients3__c']").val($("#slider-3").slider("value"));
				//	sliderSum();
				}
			});
		
		});

		function sliderSum(){
			var sum = 0;
			$("input[sobject='ActivityData__c'].patients").each(function(){
				sum += parseInt($(this).val()); 
			});
			$("input[sfield='common_number_of_patients__c']").val(sum);
		}
	};
//});

				
