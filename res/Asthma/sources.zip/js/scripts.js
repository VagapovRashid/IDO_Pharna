$(function() {
    $( ".slider" ).slider({
      animate: true,
      range: "min",
      value: 25,
      min: 1,
      max: 100,
      step: 1,
      slide: function( event, ui ) {
        $( "#amount" ).val( "$" + ui.value );
      }
    });
    $( "#amount" ).val( "$" + $( ".slider" ).slider( "value" ) );
  });