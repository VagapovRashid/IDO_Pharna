/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/153/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'fon1',
            type:'rect',
            rect:['1','70','auto','auto','auto','auto']
         },
         {
            id:'fon1_2',
            type:'rect',
            rect:['307','225','auto','auto','auto','auto']
         },
         {
            id:'fon1_3',
            type:'rect',
            rect:['266','162','auto','auto','auto','auto']
         },
         {
            id:'blood1_1',
            type:'rect',
            rect:['186','257','auto','auto','auto','auto']
         },
         {
            id:'yellow1',
            type:'rect',
            rect:['110','198','auto','auto','auto','auto']
         },
         {
            id:'blood1_3',
            type:'rect',
            rect:['186','257','auto','auto','auto','auto']
         },
         {
            id:'blood1_2',
            type:'rect',
            rect:['186','257','auto','auto','auto','auto']
         },
         {
            id:'blood2_2',
            type:'rect',
            rect:['1','0','auto','auto','auto','auto']
         },
         {
            id:'blood2_1',
            type:'rect',
            rect:['1','0','auto','auto','auto','auto']
         },
         {
            id:'yellow2',
            type:'rect',
            rect:['249','270','auto','auto','auto','auto']
         },
         {
            id:'blood2_3',
            type:'rect',
            rect:['1','0','auto','auto','auto','auto']
         },
         {
            id:'blood7',
            type:'rect',
            rect:['0','0','auto','auto','auto','auto']
         },
         {
            id:'blood8',
            type:'rect',
            rect:['0','0','auto','auto','auto','auto']
         },
         {
            id:'yellow32',
            type:'rect',
            rect:['439','212','auto','auto','auto','auto']
         },
         {
            id:'blood9',
            type:'rect',
            rect:['0','0','auto','auto','auto','auto']
         }],
         symbolInstances: [
         {
            id:'blood1_2',
            symbolName:'blood1'
         },
         {
            id:'blood2_3',
            symbolName:'blood6'
         },
         {
            id:'blood1_1',
            symbolName:'blood2'
         },
         {
            id:'fon1_3',
            symbolName:'fon1_3'
         },
         {
            id:'blood9',
            symbolName:'blood9'
         },
         {
            id:'yellow32',
            symbolName:'yellow3'
         },
         {
            id:'blood8',
            symbolName:'blood8'
         },
         {
            id:'fon1',
            symbolName:'fon1'
         },
         {
            id:'yellow2',
            symbolName:'yellow2'
         },
         {
            id:'fon1_2',
            symbolName:'fon1_2'
         },
         {
            id:'blood7',
            symbolName:'blood7'
         },
         {
            id:'blood1_3',
            symbolName:'blood3'
         },
         {
            id:'blood2_1',
            symbolName:'blood4'
         },
         {
            id:'yellow1',
            symbolName:'yellow1'
         },
         {
            id:'blood2_2',
            symbolName:'blood5'
         }
         ]
      },
   states: {
      "Base State": {
         "${_blood1_1}": [
            ["style", "left", '-39px'],
            ["style", "top", '-42px']
         ],
         "${_fon1}": [
            ["style", "opacity", '0.5']
         ],
         "${_fon1_2}": [
            ["style", "top", '46px'],
            ["style", "opacity", '0.25'],
            ["style", "left", '1px']
         ],
         "${_blood1_3}": [
            ["style", "left", '-39px'],
            ["style", "top", '-42px']
         ],
         "${_fon1_3}": [
            ["style", "top", '113px'],
            ["style", "opacity", '0.75'],
            ["style", "left", '1px']
         ],
         "${_blood1_2}": [
            ["style", "left", '-39px'],
            ["style", "top", '-42px']
         ],
         "${_Stage}": [
            ["style", "width", '777px'],
            ["style", "height", '410px'],
            ["style", "overflow", 'hidden']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 11750,
         autoPlay: true,
         labels: {
            "Label 2": 6000,
            "Label 3": 11750
         },
         timeline: [
            { id: "eid878", tween: [ "style", "${_fon1_2}", "opacity", '0.25', { fromValue: '0.25'}], position: 0, duration: 0 },
            { id: "eid879", tween: [ "style", "${_fon1_3}", "opacity", '0.75', { fromValue: '0.75'}], position: 0, duration: 0 },
            { id: "eid877", tween: [ "style", "${_fon1}", "opacity", '0.5', { fromValue: '0.5'}], position: 0, duration: 0 }         ]
      }
   }
},
"blood1": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy2',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy2',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy19',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy19',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_blood_1Copy19}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${_blood_1_mCopy2}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${symbolSelector}": [
            ["style", "height", '0px'],
            ["style", "width", '0px']
         ],
         "${_blood_1_mCopy19}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${_blood_1Copy2}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 7738,
         autoPlay: true,
         labels: {
            "1": 1762
         },
         timeline: [
            { id: "eid61", tween: [ "transform", "${_blood_1Copy2}", "scaleX", '0.45', { fromValue: '0'}], position: 0, duration: 1763 },
            { id: "eid62", tween: [ "transform", "${_blood_1Copy2}", "scaleX", '1', { fromValue: '0.45'}], position: 4501, duration: 3238 },
            { id: "eid59", tween: [ "style", "${_blood_1Copy2}", "top", '113px', { fromValue: '-43px'}], position: 0, duration: 750 },
            { id: "eid716", tween: [ "style", "${_blood_1Copy2}", "top", '254px', { fromValue: '113px'}], position: 750, duration: 1013 },
            { id: "eid60", tween: [ "style", "${_blood_1Copy2}", "top", '196px', { fromValue: '254px'}], position: 4501, duration: 1500 },
            { id: "eid712", tween: [ "style", "${_blood_1Copy2}", "top", '-45px', { fromValue: '196px'}], position: 6000, duration: 1738 },
            { id: "eid410", tween: [ "transform", "${_blood_1Copy19}", "scaleY", '0.45', { fromValue: '0'}], position: 4000, duration: 1763 },
            { id: "eid412", tween: [ "style", "${_blood_1Copy19}", "left", '-7px', { fromValue: '-42px'}], position: 4000, duration: 750 },
            { id: "eid722", tween: [ "style", "${_blood_1Copy19}", "left", '111px', { fromValue: '-7px'}], position: 4750, duration: 1013 },
            { id: "eid53", tween: [ "transform", "${_blood_1_mCopy2}", "scaleX", '0.45', { fromValue: '0'}], position: 0, duration: 1763 },
            { id: "eid54", tween: [ "transform", "${_blood_1_mCopy2}", "scaleX", '1', { fromValue: '0.45'}], position: 4501, duration: 3238 },
            { id: "eid55", tween: [ "style", "${_blood_1_mCopy2}", "opacity", '0.5', { fromValue: '1'}], position: 0, duration: 1762 },
            { id: "eid56", tween: [ "style", "${_blood_1_mCopy2}", "opacity", '0', { fromValue: '0.5'}], position: 4500, duration: 3238 },
            { id: "eid51", tween: [ "transform", "${_blood_1_mCopy2}", "scaleY", '0.45', { fromValue: '0'}], position: 0, duration: 1763 },
            { id: "eid52", tween: [ "transform", "${_blood_1_mCopy2}", "scaleY", '1', { fromValue: '0.45'}], position: 4501, duration: 3238 },
            { id: "eid400", tween: [ "transform", "${_blood_1_mCopy19}", "scaleY", '0.45', { fromValue: '0'}], position: 4000, duration: 1763 },
            { id: "eid404", tween: [ "style", "${_blood_1_mCopy19}", "opacity", '0.5', { fromValue: '1'}], position: 4000, duration: 1762 },
            { id: "eid63", tween: [ "style", "${_blood_1Copy2}", "left", '-7px', { fromValue: '-42px'}], position: 0, duration: 750 },
            { id: "eid718", tween: [ "style", "${_blood_1Copy2}", "left", '111px', { fromValue: '-7px'}], position: 750, duration: 1013 },
            { id: "eid64", tween: [ "style", "${_blood_1Copy2}", "left", '834px', { fromValue: '111px'}], position: 4501, duration: 3238 },
            { id: "eid402", tween: [ "transform", "${_blood_1_mCopy19}", "scaleX", '0.45', { fromValue: '0'}], position: 4000, duration: 1763 },
            { id: "eid57", tween: [ "style", "${_blood_1_mCopy2}", "left", '-7px', { fromValue: '-42px'}], position: 0, duration: 750 },
            { id: "eid717", tween: [ "style", "${_blood_1_mCopy2}", "left", '111px', { fromValue: '-7px'}], position: 750, duration: 1013 },
            { id: "eid58", tween: [ "style", "${_blood_1_mCopy2}", "left", '834px', { fromValue: '111px'}], position: 4501, duration: 3238 },
            { id: "eid49", tween: [ "style", "${_blood_1_mCopy2}", "top", '113px', { fromValue: '-43px'}], position: 0, duration: 750 },
            { id: "eid715", tween: [ "style", "${_blood_1_mCopy2}", "top", '254px', { fromValue: '113px'}], position: 750, duration: 1013 },
            { id: "eid50", tween: [ "style", "${_blood_1_mCopy2}", "top", '196px', { fromValue: '254px'}], position: 4501, duration: 1500 },
            { id: "eid711", tween: [ "style", "${_blood_1_mCopy2}", "top", '-45px', { fromValue: '196px'}], position: 6000, duration: 1738 },
            { id: "eid65", tween: [ "transform", "${_blood_1Copy2}", "scaleY", '0.45', { fromValue: '0'}], position: 0, duration: 1763 },
            { id: "eid66", tween: [ "transform", "${_blood_1Copy2}", "scaleY", '1', { fromValue: '0.45'}], position: 4501, duration: 3238 },
            { id: "eid398", tween: [ "style", "${_blood_1_mCopy19}", "top", '113px', { fromValue: '-43px'}], position: 4000, duration: 750 },
            { id: "eid719", tween: [ "style", "${_blood_1_mCopy19}", "top", '254px', { fromValue: '113px'}], position: 4750, duration: 1013 },
            { id: "eid452", tween: [ "style", "${_blood_1Copy2}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
            { id: "eid414", tween: [ "transform", "${_blood_1Copy19}", "scaleX", '0.45', { fromValue: '0'}], position: 4000, duration: 1763 },
            { id: "eid408", tween: [ "style", "${_blood_1Copy19}", "top", '113px', { fromValue: '-43px'}], position: 4000, duration: 750 },
            { id: "eid720", tween: [ "style", "${_blood_1Copy19}", "top", '254px', { fromValue: '113px'}], position: 4750, duration: 1013 },
            { id: "eid406", tween: [ "style", "${_blood_1_mCopy19}", "left", '-7px', { fromValue: '-42px'}], position: 4000, duration: 750 },
            { id: "eid721", tween: [ "style", "${_blood_1_mCopy19}", "left", '111px', { fromValue: '-7px'}], position: 4750, duration: 1013 }         ]
      }
   }
},
"blood2": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy20',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy20',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_blood_1Copy}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${_blood_1_mCopy20}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${symbolSelector}": [
            ["style", "height", '0px'],
            ["style", "width", '0px']
         ],
         "${_blood_1_mCopy}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${_blood_1Copy20}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 9500,
         autoPlay: true,
         labels: {
            "2": 3524
         },
         timeline: [
            { id: "eid30", tween: [ "style", "${_blood_1_mCopy}", "top", '284px', { fromValue: '-43px'}], position: 1762, duration: 1763 },
            { id: "eid31", tween: [ "style", "${_blood_1_mCopy}", "top", '203px', { fromValue: '284px'}], position: 6263, duration: 1488 },
            { id: "eid723", tween: [ "style", "${_blood_1_mCopy}", "top", '-45px', { fromValue: '203px'}], position: 7750, duration: 1750 },
            { id: "eid47", tween: [ "style", "${_blood_1Copy}", "left", '31px', { fromValue: '-42px'}], position: 1762, duration: 738 },
            { id: "eid726", tween: [ "style", "${_blood_1Copy}", "left", '181px', { fromValue: '31px'}], position: 2500, duration: 1025 },
            { id: "eid48", tween: [ "style", "${_blood_1Copy}", "left", '834px', { fromValue: '181px'}], position: 6263, duration: 3238 },
            { id: "eid455", tween: [ "style", "${_blood_1Copy}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
            { id: "eid420", tween: [ "transform", "${_blood_1_mCopy20}", "scaleX", '0.4', { fromValue: '0'}], position: 5750, duration: 1763 },
            { id: "eid424", tween: [ "style", "${_blood_1_mCopy20}", "left", '33px', { fromValue: '-42px'}], position: 5750, duration: 750 },
            { id: "eid727", tween: [ "style", "${_blood_1_mCopy20}", "left", '181px', { fromValue: '33px'}], position: 6500, duration: 1013 },
            { id: "eid38", tween: [ "style", "${_blood_1_mCopy}", "left", '31px', { fromValue: '-42px'}], position: 1762, duration: 738 },
            { id: "eid725", tween: [ "style", "${_blood_1_mCopy}", "left", '181px', { fromValue: '31px'}], position: 2500, duration: 1025 },
            { id: "eid39", tween: [ "style", "${_blood_1_mCopy}", "left", '834px', { fromValue: '181px'}], position: 6263, duration: 3238 },
            { id: "eid430", tween: [ "transform", "${_blood_1Copy20}", "scaleY", '0.4', { fromValue: '0'}], position: 5750, duration: 1763 },
            { id: "eid426", tween: [ "transform", "${_blood_1Copy20}", "scaleX", '0.4', { fromValue: '0'}], position: 5750, duration: 1763 },
            { id: "eid418", tween: [ "transform", "${_blood_1_mCopy20}", "scaleY", '0.4', { fromValue: '0'}], position: 5750, duration: 1763 },
            { id: "eid36", tween: [ "style", "${_blood_1_mCopy}", "opacity", '0.5', { fromValue: '1'}], position: 1762, duration: 1762 },
            { id: "eid37", tween: [ "style", "${_blood_1_mCopy}", "opacity", '0', { fromValue: '0.5'}], position: 6262, duration: 3238 },
            { id: "eid432", tween: [ "style", "${_blood_1Copy20}", "left", '33px', { fromValue: '-42px'}], position: 5750, duration: 750 },
            { id: "eid728", tween: [ "style", "${_blood_1Copy20}", "left", '181px', { fromValue: '33px'}], position: 6500, duration: 1013 },
            { id: "eid428", tween: [ "style", "${_blood_1Copy20}", "top", '284px', { fromValue: '-43px'}], position: 5750, duration: 1763 },
            { id: "eid40", tween: [ "style", "${_blood_1Copy}", "top", '284px', { fromValue: '-43px'}], position: 1762, duration: 1763 },
            { id: "eid41", tween: [ "style", "${_blood_1Copy}", "top", '203px', { fromValue: '284px'}], position: 6263, duration: 1488 },
            { id: "eid724", tween: [ "style", "${_blood_1Copy}", "top", '-45px', { fromValue: '203px'}], position: 7750, duration: 1750 },
            { id: "eid416", tween: [ "style", "${_blood_1_mCopy20}", "top", '284px', { fromValue: '-43px'}], position: 5750, duration: 1763 },
            { id: "eid42", tween: [ "transform", "${_blood_1Copy}", "scaleY", '0.4', { fromValue: '0'}], position: 1762, duration: 1763 },
            { id: "eid43", tween: [ "transform", "${_blood_1Copy}", "scaleY", '1', { fromValue: '0.4'}], position: 6263, duration: 3238 },
            { id: "eid44", tween: [ "transform", "${_blood_1Copy}", "scaleX", '0.4', { fromValue: '0'}], position: 1762, duration: 1763 },
            { id: "eid45", tween: [ "transform", "${_blood_1Copy}", "scaleX", '1', { fromValue: '0.4'}], position: 6263, duration: 3238 },
            { id: "eid422", tween: [ "style", "${_blood_1_mCopy20}", "opacity", '0.5', { fromValue: '1'}], position: 5750, duration: 1762 },
            { id: "eid34", tween: [ "transform", "${_blood_1_mCopy}", "scaleX", '0.4', { fromValue: '0'}], position: 1762, duration: 1763 },
            { id: "eid35", tween: [ "transform", "${_blood_1_mCopy}", "scaleX", '1', { fromValue: '0.4'}], position: 6263, duration: 3238 },
            { id: "eid32", tween: [ "transform", "${_blood_1_mCopy}", "scaleY", '0.4', { fromValue: '0'}], position: 1762, duration: 1763 },
            { id: "eid33", tween: [ "transform", "${_blood_1_mCopy}", "scaleY", '1', { fromValue: '0.4'}], position: 6263, duration: 3238 }         ]
      }
   }
},
"blood3": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_m',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy21',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy21',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_blood_1_mCopy21}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${symbolSelector}": [
            ["style", "height", '0px'],
            ["style", "width", '0px']
         ],
         "${_blood_1Copy21}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${_blood_1_m}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${_blood_1}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 11262,
         autoPlay: true,
         labels: {
            "3": 5286
         },
         timeline: [
            { id: "eid5", tween: [ "style", "${_blood_1_m}", "left", '172px', { fromValue: '-42px'}], position: 3524, duration: 1762 },
            { id: "eid23", tween: [ "style", "${_blood_1_m}", "left", '834px', { fromValue: '172px'}], position: 8024, duration: 3238 },
            { id: "eid17", tween: [ "transform", "${_blood_1}", "scaleX", '0.5', { fromValue: '0'}], position: 3524, duration: 1762 },
            { id: "eid21", tween: [ "transform", "${_blood_1}", "scaleX", '1', { fromValue: '0.5'}], position: 8024, duration: 3237 },
            { id: "eid7", tween: [ "style", "${_blood_1}", "left", '172px', { fromValue: '-42px'}], position: 3524, duration: 1762 },
            { id: "eid24", tween: [ "style", "${_blood_1}", "left", '834px', { fromValue: '172px'}], position: 8024, duration: 3238 },
            { id: "eid438", tween: [ "transform", "${_blood_1_mCopy21}", "scaleX", '0.5', { fromValue: '0'}], position: 7500, duration: 1763 },
            { id: "eid448", tween: [ "style", "${_blood_1Copy21}", "left", '172px', { fromValue: '-42px'}], position: 7500, duration: 1763 },
            { id: "eid457", tween: [ "style", "${_blood_1}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
            { id: "eid450", tween: [ "style", "${_blood_1Copy21}", "top", '83px', { fromValue: '-43px'}], position: 7500, duration: 750 },
            { id: "eid734", tween: [ "style", "${_blood_1Copy21}", "top", '207px', { fromValue: '83px'}], position: 8250, duration: 1013 },
            { id: "eid444", tween: [ "transform", "${_blood_1Copy21}", "scaleX", '0.5', { fromValue: '0'}], position: 7500, duration: 1763 },
            { id: "eid8", tween: [ "style", "${_blood_1}", "top", '80px', { fromValue: '-43px'}], position: 3524, duration: 726 },
            { id: "eid732", tween: [ "style", "${_blood_1}", "top", '207px', { fromValue: '80px'}], position: 4250, duration: 1037 },
            { id: "eid10", tween: [ "style", "${_blood_1}", "top", '162px', { fromValue: '207px'}], position: 8024, duration: 1476 },
            { id: "eid730", tween: [ "style", "${_blood_1}", "top", '-45px', { fromValue: '162px'}], position: 9500, duration: 1762 },
            { id: "eid446", tween: [ "transform", "${_blood_1Copy21}", "scaleY", '0.5', { fromValue: '0'}], position: 7500, duration: 1763 },
            { id: "eid442", tween: [ "style", "${_blood_1_mCopy21}", "left", '172px', { fromValue: '-42px'}], position: 7500, duration: 1763 },
            { id: "eid28", tween: [ "style", "${_blood_1_m}", "opacity", '0.5', { fromValue: '1'}], position: 3524, duration: 1762 },
            { id: "eid29", tween: [ "style", "${_blood_1_m}", "opacity", '0', { fromValue: '0.5'}], position: 8024, duration: 3238 },
            { id: "eid18", tween: [ "transform", "${_blood_1}", "scaleY", '0.5', { fromValue: '0'}], position: 3524, duration: 1762 },
            { id: "eid22", tween: [ "transform", "${_blood_1}", "scaleY", '1', { fromValue: '0.5'}], position: 8024, duration: 3237 },
            { id: "eid15", tween: [ "transform", "${_blood_1_m}", "scaleX", '0.5', { fromValue: '0'}], position: 3524, duration: 1762 },
            { id: "eid19", tween: [ "transform", "${_blood_1_m}", "scaleX", '1', { fromValue: '0.5'}], position: 8024, duration: 3237 },
            { id: "eid436", tween: [ "transform", "${_blood_1_mCopy21}", "scaleY", '0.5', { fromValue: '0'}], position: 7500, duration: 1763 },
            { id: "eid434", tween: [ "style", "${_blood_1_mCopy21}", "top", '83px', { fromValue: '-43px'}], position: 7500, duration: 750 },
            { id: "eid733", tween: [ "style", "${_blood_1_mCopy21}", "top", '207px', { fromValue: '83px'}], position: 8250, duration: 1013 },
            { id: "eid440", tween: [ "style", "${_blood_1_mCopy21}", "opacity", '0.5', { fromValue: '1'}], position: 7500, duration: 1762 },
            { id: "eid16", tween: [ "transform", "${_blood_1_m}", "scaleY", '0.5', { fromValue: '0'}], position: 3524, duration: 1762 },
            { id: "eid20", tween: [ "transform", "${_blood_1_m}", "scaleY", '1', { fromValue: '0.5'}], position: 8024, duration: 3237 },
            { id: "eid6", tween: [ "style", "${_blood_1_m}", "top", '80px', { fromValue: '-43px'}], position: 3524, duration: 726 },
            { id: "eid731", tween: [ "style", "${_blood_1_m}", "top", '207px', { fromValue: '80px'}], position: 4250, duration: 1037 },
            { id: "eid9", tween: [ "style", "${_blood_1_m}", "top", '162px', { fromValue: '207px'}], position: 8024, duration: 1476 },
            { id: "eid729", tween: [ "style", "${_blood_1_m}", "top", '-45px', { fromValue: '162px'}], position: 9500, duration: 1762 }         ]
      }
   }
},
"blood4": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy22',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy22',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy25',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy25',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_blood_1Copy25}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ],
         "${_blood_1Copy22}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ],
         "${_blood_1_mCopy22}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ],
         "${_blood_1_mCopy25}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ],
         "${symbolSelector}": [
            ["style", "height", '0px'],
            ["style", "width", '0px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 14988,
         autoPlay: true,
         labels: {
            "4": 9012
         },
         timeline: [
            { id: "eid547", tween: [ "style", "${_blood_1Copy25}", "top", '159px', { fromValue: '-43px'}], position: 11250, duration: 1500 },
            { id: "eid742", tween: [ "style", "${_blood_1Copy25}", "top", '303px', { fromValue: '159px'}], position: 12750, duration: 1513 },
            { id: "eid462", tween: [ "transform", "${_blood_1_mCopy22}", "scaleX", '0.55', { fromValue: '0'}], position: 6000, duration: 3013 },
            { id: "eid463", tween: [ "transform", "${_blood_1_mCopy22}", "scaleX", '1', { fromValue: '0.55'}], position: 11751, duration: 3238 },
            { id: "eid531", tween: [ "style", "${_blood_1_mCopy25}", "top", '160px', { fromValue: '-43px'}], position: 11250, duration: 1500 },
            { id: "eid741", tween: [ "style", "${_blood_1_mCopy25}", "top", '304px', { fromValue: '160px'}], position: 12750, duration: 1513 },
            { id: "eid470", tween: [ "transform", "${_blood_1Copy22}", "scaleY", '0.55', { fromValue: '0'}], position: 6000, duration: 3013 },
            { id: "eid471", tween: [ "transform", "${_blood_1Copy22}", "scaleY", '1', { fromValue: '0.55'}], position: 11751, duration: 3238 },
            { id: "eid464", tween: [ "style", "${_blood_1_mCopy22}", "opacity", '0.35', { fromValue: '1'}], position: 6000, duration: 3012 },
            { id: "eid465", tween: [ "style", "${_blood_1_mCopy22}", "opacity", '0', { fromValue: '0.35'}], position: 11750, duration: 3238 },
            { id: "eid541", tween: [ "transform", "${_blood_1Copy25}", "scaleX", '0.55', { fromValue: '0'}], position: 11250, duration: 3013 },
            { id: "eid533", tween: [ "transform", "${_blood_1_mCopy25}", "scaleY", '0.55', { fromValue: '0'}], position: 11250, duration: 3013 },
            { id: "eid539", tween: [ "style", "${_blood_1_mCopy25}", "left", '108px', { fromValue: '-43px'}], position: 11250, duration: 1500 },
            { id: "eid743", tween: [ "style", "${_blood_1_mCopy25}", "left", '320px', { fromValue: '108px'}], position: 12750, duration: 1513 },
            { id: "eid535", tween: [ "transform", "${_blood_1_mCopy25}", "scaleX", '0.55', { fromValue: '0'}], position: 11250, duration: 3013 },
            { id: "eid472", tween: [ "transform", "${_blood_1Copy22}", "scaleX", '0.55', { fromValue: '0'}], position: 6000, duration: 3013 },
            { id: "eid473", tween: [ "transform", "${_blood_1Copy22}", "scaleX", '1', { fromValue: '0.55'}], position: 11751, duration: 3238 },
            { id: "eid460", tween: [ "transform", "${_blood_1_mCopy22}", "scaleY", '0.55', { fromValue: '0'}], position: 6000, duration: 3013 },
            { id: "eid461", tween: [ "transform", "${_blood_1_mCopy22}", "scaleY", '1', { fromValue: '0.55'}], position: 11751, duration: 3238 },
            { id: "eid543", tween: [ "transform", "${_blood_1Copy25}", "scaleY", '0.55', { fromValue: '0'}], position: 11250, duration: 3013 },
            { id: "eid475", tween: [ "style", "${_blood_1Copy22}", "left", '108px', { fromValue: '-43px'}], position: 6000, duration: 1500 },
            { id: "eid738", tween: [ "style", "${_blood_1Copy22}", "left", '320px', { fromValue: '108px'}], position: 7500, duration: 1513 },
            { id: "eid476", tween: [ "style", "${_blood_1Copy22}", "left", '834px', { fromValue: '320px'}], position: 11751, duration: 3238 },
            { id: "eid468", tween: [ "style", "${_blood_1Copy22}", "top", '179px', { fromValue: '-43px'}], position: 6000, duration: 1500 },
            { id: "eid736", tween: [ "style", "${_blood_1Copy22}", "top", '303px', { fromValue: '179px'}], position: 7500, duration: 1513 },
            { id: "eid469", tween: [ "style", "${_blood_1Copy22}", "top", '210px', { fromValue: '303px'}], position: 11751, duration: 1750 },
            { id: "eid740", tween: [ "style", "${_blood_1Copy22}", "top", '75px', { fromValue: '210px'}], position: 13500, duration: 1488 },
            { id: "eid537", tween: [ "style", "${_blood_1_mCopy25}", "opacity", '0.35', { fromValue: '1'}], position: 11250, duration: 3012 },
            { id: "eid458", tween: [ "style", "${_blood_1_mCopy22}", "top", '180px', { fromValue: '-43px'}], position: 6000, duration: 1500 },
            { id: "eid735", tween: [ "style", "${_blood_1_mCopy22}", "top", '304px', { fromValue: '180px'}], position: 7500, duration: 1513 },
            { id: "eid459", tween: [ "style", "${_blood_1_mCopy22}", "top", '210px', { fromValue: '304px'}], position: 11751, duration: 1750 },
            { id: "eid739", tween: [ "style", "${_blood_1_mCopy22}", "top", '75px', { fromValue: '210px'}], position: 13500, duration: 1488 },
            { id: "eid466", tween: [ "style", "${_blood_1_mCopy22}", "left", '108px', { fromValue: '-43px'}], position: 6000, duration: 1500 },
            { id: "eid737", tween: [ "style", "${_blood_1_mCopy22}", "left", '320px', { fromValue: '108px'}], position: 7500, duration: 1513 },
            { id: "eid467", tween: [ "style", "${_blood_1_mCopy22}", "left", '834px', { fromValue: '320px'}], position: 11751, duration: 3238 },
            { id: "eid545", tween: [ "style", "${_blood_1Copy25}", "left", '108px', { fromValue: '-43px'}], position: 11250, duration: 1500 },
            { id: "eid744", tween: [ "style", "${_blood_1Copy25}", "left", '320px', { fromValue: '108px'}], position: 12750, duration: 1513 }         ]
      }
   }
},
"blood5": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy23',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy23',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy26',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy26',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_blood_1Copy26}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ],
         "${symbolSelector}": [
            ["style", "height", '0px'],
            ["style", "width", '0px']
         ],
         "${_blood_1_mCopy26}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ],
         "${_blood_1_mCopy23}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ],
         "${_blood_1Copy23}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 16488,
         autoPlay: true,
         labels: {
            "5": 10512
         },
         timeline: [
            { id: "eid487", tween: [ "transform", "${_blood_1_mCopy23}", "scaleX", '0.5', { fromValue: '0'}], position: 7500, duration: 3013 },
            { id: "eid488", tween: [ "transform", "${_blood_1_mCopy23}", "scaleX", '1', { fromValue: '0.5'}], position: 13251, duration: 3238 },
            { id: "eid491", tween: [ "style", "${_blood_1_mCopy23}", "left", '63px', { fromValue: '-43px'}], position: 7500, duration: 1500 },
            { id: "eid746", tween: [ "style", "${_blood_1_mCopy23}", "left", '230px', { fromValue: '63px'}], position: 9000, duration: 1513 },
            { id: "eid492", tween: [ "style", "${_blood_1_mCopy23}", "left", '834px', { fromValue: '230px'}], position: 13251, duration: 3238 },
            { id: "eid483", tween: [ "style", "${_blood_1_mCopy23}", "top", '170px', { fromValue: '-43px'}], position: 7500, duration: 1500 },
            { id: "eid745", tween: [ "style", "${_blood_1_mCopy23}", "top", '324px', { fromValue: '170px'}], position: 9000, duration: 1513 },
            { id: "eid484", tween: [ "style", "${_blood_1_mCopy23}", "top", '220px', { fromValue: '324px'}], position: 13251, duration: 1750 },
            { id: "eid753", tween: [ "style", "${_blood_1_mCopy23}", "top", '75px', { fromValue: '220px'}], position: 15000, duration: 1488 },
            { id: "eid497", tween: [ "style", "${_blood_1Copy23}", "left", '63px', { fromValue: '-43px'}], position: 7500, duration: 1500 },
            { id: "eid748", tween: [ "style", "${_blood_1Copy23}", "left", '230px', { fromValue: '63px'}], position: 9000, duration: 1513 },
            { id: "eid498", tween: [ "style", "${_blood_1Copy23}", "left", '834px', { fromValue: '230px'}], position: 13251, duration: 3238 },
            { id: "eid495", tween: [ "transform", "${_blood_1Copy23}", "scaleY", '0.5', { fromValue: '0'}], position: 7500, duration: 3013 },
            { id: "eid496", tween: [ "transform", "${_blood_1Copy23}", "scaleY", '1', { fromValue: '0.5'}], position: 13251, duration: 3238 },
            { id: "eid555", tween: [ "style", "${_blood_1_mCopy26}", "opacity", '0.35', { fromValue: '1'}], position: 12750, duration: 3012 },
            { id: "eid551", tween: [ "transform", "${_blood_1_mCopy26}", "scaleY", '0.5', { fromValue: '0'}], position: 12750, duration: 3013 },
            { id: "eid557", tween: [ "style", "${_blood_1_mCopy26}", "left", '63px', { fromValue: '-43px'}], position: 12750, duration: 1500 },
            { id: "eid750", tween: [ "style", "${_blood_1_mCopy26}", "left", '230px', { fromValue: '63px'}], position: 14250, duration: 1513 },
            { id: "eid565", tween: [ "transform", "${_blood_1Copy26}", "scaleX", '0.5', { fromValue: '0'}], position: 12750, duration: 3013 },
            { id: "eid563", tween: [ "style", "${_blood_1Copy26}", "left", '63px', { fromValue: '-43px'}], position: 12750, duration: 1500 },
            { id: "eid752", tween: [ "style", "${_blood_1Copy26}", "left", '230px', { fromValue: '63px'}], position: 14250, duration: 1513 },
            { id: "eid561", tween: [ "transform", "${_blood_1Copy26}", "scaleY", '0.5', { fromValue: '0'}], position: 12750, duration: 3013 },
            { id: "eid493", tween: [ "transform", "${_blood_1Copy23}", "scaleX", '0.5', { fromValue: '0'}], position: 7500, duration: 3013 },
            { id: "eid494", tween: [ "transform", "${_blood_1Copy23}", "scaleX", '1', { fromValue: '0.5'}], position: 13251, duration: 3238 },
            { id: "eid485", tween: [ "transform", "${_blood_1_mCopy23}", "scaleY", '0.5', { fromValue: '0'}], position: 7500, duration: 3013 },
            { id: "eid486", tween: [ "transform", "${_blood_1_mCopy23}", "scaleY", '1', { fromValue: '0.5'}], position: 13251, duration: 3238 },
            { id: "eid499", tween: [ "style", "${_blood_1Copy23}", "top", '170px', { fromValue: '-43px'}], position: 7500, duration: 1500 },
            { id: "eid747", tween: [ "style", "${_blood_1Copy23}", "top", '324px', { fromValue: '170px'}], position: 9000, duration: 1513 },
            { id: "eid500", tween: [ "style", "${_blood_1Copy23}", "top", '220px', { fromValue: '324px'}], position: 13251, duration: 1750 },
            { id: "eid754", tween: [ "style", "${_blood_1Copy23}", "top", '75px', { fromValue: '220px'}], position: 15000, duration: 1488 },
            { id: "eid549", tween: [ "style", "${_blood_1_mCopy26}", "top", '170px', { fromValue: '-43px'}], position: 12750, duration: 1500 },
            { id: "eid749", tween: [ "style", "${_blood_1_mCopy26}", "top", '324px', { fromValue: '170px'}], position: 14250, duration: 1513 },
            { id: "eid489", tween: [ "style", "${_blood_1_mCopy23}", "opacity", '0.35', { fromValue: '1'}], position: 7500, duration: 3012 },
            { id: "eid490", tween: [ "style", "${_blood_1_mCopy23}", "opacity", '0', { fromValue: '0.35'}], position: 13250, duration: 3238 },
            { id: "eid559", tween: [ "style", "${_blood_1Copy26}", "top", '170px', { fromValue: '-43px'}], position: 12750, duration: 1500 },
            { id: "eid751", tween: [ "style", "${_blood_1Copy26}", "top", '324px', { fromValue: '170px'}], position: 14250, duration: 1513 },
            { id: "eid553", tween: [ "transform", "${_blood_1_mCopy26}", "scaleX", '0.5', { fromValue: '0'}], position: 12750, duration: 3013 }         ]
      }
   }
},
"blood6": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy24',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy24',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy27',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-42px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy27',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_blood_1Copy27}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ],
         "${_blood_1Copy24}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ],
         "${symbolSelector}": [
            ["style", "height", '0px'],
            ["style", "width", '0px']
         ],
         "${_blood_1_mCopy27}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ],
         "${_blood_1_mCopy24}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 18000,
         autoPlay: true,
         labels: {
            "6": 12024
         },
         timeline: [
            { id: "eid521", tween: [ "style", "${_blood_1Copy24}", "left", '81px', { fromValue: '-43px'}], position: 9012, duration: 1488 },
            { id: "eid758", tween: [ "style", "${_blood_1Copy24}", "left", '268px', { fromValue: '81px'}], position: 10500, duration: 1524 },
            { id: "eid522", tween: [ "style", "${_blood_1Copy24}", "left", '834px', { fromValue: '268px'}], position: 14762, duration: 3238 },
            { id: "eid505", tween: [ "style", "${_blood_1_mCopy24}", "top", '122px', { fromValue: '-43px'}], position: 9012, duration: 1488 },
            { id: "eid755", tween: [ "style", "${_blood_1_mCopy24}", "top", '231px', { fromValue: '122px'}], position: 10500, duration: 1524 },
            { id: "eid506", tween: [ "style", "${_blood_1_mCopy24}", "top", '189px', { fromValue: '231px'}], position: 14762, duration: 1488 },
            { id: "eid763", tween: [ "style", "${_blood_1_mCopy24}", "top", '75px', { fromValue: '189px'}], position: 16250, duration: 1750 },
            { id: "eid575", tween: [ "style", "${_blood_1_mCopy27}", "left", '82px', { fromValue: '-43px'}], position: 14250, duration: 1500 },
            { id: "eid761", tween: [ "style", "${_blood_1_mCopy27}", "left", '268px', { fromValue: '82px'}], position: 15750, duration: 1513 },
            { id: "eid573", tween: [ "style", "${_blood_1_mCopy27}", "opacity", '0.35', { fromValue: '1'}], position: 14250, duration: 3012 },
            { id: "eid519", tween: [ "transform", "${_blood_1Copy24}", "scaleY", '0.65', { fromValue: '0'}], position: 9012, duration: 3013 },
            { id: "eid520", tween: [ "transform", "${_blood_1Copy24}", "scaleY", '1', { fromValue: '0.65'}], position: 14762, duration: 3238 },
            { id: "eid577", tween: [ "transform", "${_blood_1Copy27}", "scaleX", '0.65', { fromValue: '0'}], position: 14250, duration: 3013 },
            { id: "eid569", tween: [ "transform", "${_blood_1_mCopy27}", "scaleY", '0.65', { fromValue: '0'}], position: 14250, duration: 3013 },
            { id: "eid513", tween: [ "style", "${_blood_1_mCopy24}", "left", '81px', { fromValue: '-43px'}], position: 9012, duration: 1488 },
            { id: "eid757", tween: [ "style", "${_blood_1_mCopy24}", "left", '268px', { fromValue: '81px'}], position: 10500, duration: 1524 },
            { id: "eid514", tween: [ "style", "${_blood_1_mCopy24}", "left", '834px', { fromValue: '268px'}], position: 14762, duration: 3238 },
            { id: "eid583", tween: [ "style", "${_blood_1Copy27}", "top", '123px', { fromValue: '-43px'}], position: 14250, duration: 1500 },
            { id: "eid760", tween: [ "style", "${_blood_1Copy27}", "top", '231px', { fromValue: '123px'}], position: 15750, duration: 1513 },
            { id: "eid571", tween: [ "transform", "${_blood_1_mCopy27}", "scaleX", '0.65', { fromValue: '0'}], position: 14250, duration: 3013 },
            { id: "eid579", tween: [ "transform", "${_blood_1Copy27}", "scaleY", '0.65', { fromValue: '0'}], position: 14250, duration: 3013 },
            { id: "eid515", tween: [ "transform", "${_blood_1Copy24}", "scaleX", '0.65', { fromValue: '0'}], position: 9012, duration: 3013 },
            { id: "eid516", tween: [ "transform", "${_blood_1Copy24}", "scaleX", '1', { fromValue: '0.65'}], position: 14762, duration: 3238 },
            { id: "eid511", tween: [ "style", "${_blood_1_mCopy24}", "opacity", '0.35', { fromValue: '1'}], position: 9012, duration: 3012 },
            { id: "eid512", tween: [ "style", "${_blood_1_mCopy24}", "opacity", '0', { fromValue: '0.35'}], position: 14762, duration: 3238 },
            { id: "eid507", tween: [ "transform", "${_blood_1_mCopy24}", "scaleY", '0.65', { fromValue: '0'}], position: 9012, duration: 3013 },
            { id: "eid508", tween: [ "transform", "${_blood_1_mCopy24}", "scaleY", '1', { fromValue: '0.65'}], position: 14762, duration: 3238 },
            { id: "eid509", tween: [ "transform", "${_blood_1_mCopy24}", "scaleX", '0.65', { fromValue: '0'}], position: 9012, duration: 3013 },
            { id: "eid510", tween: [ "transform", "${_blood_1_mCopy24}", "scaleX", '1', { fromValue: '0.65'}], position: 14762, duration: 3238 },
            { id: "eid581", tween: [ "style", "${_blood_1Copy27}", "left", '82px', { fromValue: '-43px'}], position: 14250, duration: 1500 },
            { id: "eid762", tween: [ "style", "${_blood_1Copy27}", "left", '268px', { fromValue: '82px'}], position: 15750, duration: 1513 },
            { id: "eid567", tween: [ "style", "${_blood_1_mCopy27}", "top", '123px', { fromValue: '-43px'}], position: 14250, duration: 1500 },
            { id: "eid759", tween: [ "style", "${_blood_1_mCopy27}", "top", '231px', { fromValue: '123px'}], position: 15750, duration: 1513 },
            { id: "eid517", tween: [ "style", "${_blood_1Copy24}", "top", '122px', { fromValue: '-43px'}], position: 9012, duration: 1488 },
            { id: "eid756", tween: [ "style", "${_blood_1Copy24}", "top", '231px', { fromValue: '122px'}], position: 10500, duration: 1524 },
            { id: "eid518", tween: [ "style", "${_blood_1Copy24}", "top", '189px', { fromValue: '231px'}], position: 14762, duration: 1488 },
            { id: "eid764", tween: [ "style", "${_blood_1Copy24}", "top", '75px', { fromValue: '189px'}], position: 16250, duration: 1750 }         ]
      }
   }
},
"blood7": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['-41px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy28',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-41px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy28',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   },
   {
      rect: ['-41px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy31',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-41px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy31',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '0px'],
            ["style", "width", '0px']
         ],
         "${_blood_1_mCopy28}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${_blood_1Copy28}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${_blood_1Copy31}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${_blood_1_mCopy31}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 20272,
         autoPlay: true,
         labels: {
            "7": 15479
         },
         timeline: [
            { id: "eid671", tween: [ "style", "${_blood_1Copy31}", "left", '203px', { fromValue: '-42px'}], position: 16500, duration: 1750 },
            { id: "eid774", tween: [ "style", "${_blood_1Copy31}", "left", '548px', { fromValue: '203px'}], position: 18250, duration: 2000 },
            { id: "eid589", tween: [ "transform", "${_blood_1_mCopy28}", "scaleX", '0.8', { fromValue: '0'}], position: 11750, duration: 3750 },
            { id: "eid590", tween: [ "transform", "${_blood_1_mCopy28}", "scaleX", '1', { fromValue: '0.8'}], position: 18250, duration: 2000 },
            { id: "eid591", tween: [ "style", "${_blood_1_mCopy28}", "opacity", '0.1', { fromValue: '1'}], position: 11750, duration: 3749 },
            { id: "eid592", tween: [ "style", "${_blood_1_mCopy28}", "opacity", '0', { fromValue: '0.1'}], position: 18250, duration: 2000 },
            { id: "eid597", tween: [ "style", "${_blood_1Copy28}", "top", '125px', { fromValue: '-43px'}], position: 11750, duration: 1762 },
            { id: "eid766", tween: [ "style", "${_blood_1Copy28}", "top", '251px', { fromValue: '125px'}], position: 13512, duration: 1988 },
            { id: "eid598", tween: [ "style", "${_blood_1Copy28}", "top", '238px', { fromValue: '251px'}], position: 18250, duration: 1000 },
            { id: "eid770", tween: [ "style", "${_blood_1Copy28}", "top", '165px', { fromValue: '238px'}], position: 19250, duration: 1000 },
            { id: "eid599", tween: [ "transform", "${_blood_1Copy28}", "scaleY", '0.8', { fromValue: '0'}], position: 11750, duration: 3750 },
            { id: "eid600", tween: [ "transform", "${_blood_1Copy28}", "scaleY", '1', { fromValue: '0.8'}], position: 18250, duration: 2000 },
            { id: "eid595", tween: [ "transform", "${_blood_1Copy28}", "scaleX", '0.8', { fromValue: '0'}], position: 11750, duration: 3750 },
            { id: "eid596", tween: [ "transform", "${_blood_1Copy28}", "scaleX", '1', { fromValue: '0.8'}], position: 18250, duration: 2000 },
            { id: "eid601", tween: [ "style", "${_blood_1Copy28}", "left", '205px', { fromValue: '-42px'}], position: 11750, duration: 1762 },
            { id: "eid768", tween: [ "style", "${_blood_1Copy28}", "left", '548px', { fromValue: '205px'}], position: 13512, duration: 1988 },
            { id: "eid602", tween: [ "style", "${_blood_1Copy28}", "left", '794px', { fromValue: '548px'}], position: 18250, duration: 2000 },
            { id: "eid673", tween: [ "transform", "${_blood_1Copy31}", "scaleX", '0.8', { fromValue: '0'}], position: 16500, duration: 3750 },
            { id: "eid669", tween: [ "transform", "${_blood_1Copy31}", "scaleY", '0.8', { fromValue: '0'}], position: 16500, duration: 3750 },
            { id: "eid587", tween: [ "transform", "${_blood_1_mCopy28}", "scaleY", '0.8', { fromValue: '0'}], position: 11750, duration: 3750 },
            { id: "eid588", tween: [ "transform", "${_blood_1_mCopy28}", "scaleY", '1', { fromValue: '0.8'}], position: 18250, duration: 2000 },
            { id: "eid665", tween: [ "style", "${_blood_1_mCopy31}", "left", '203px', { fromValue: '-42px'}], position: 16500, duration: 1750 },
            { id: "eid773", tween: [ "style", "${_blood_1_mCopy31}", "left", '548px', { fromValue: '203px'}], position: 18250, duration: 2000 },
            { id: "eid657", tween: [ "style", "${_blood_1_mCopy31}", "top", '124px', { fromValue: '-43px'}], position: 16500, duration: 1750 },
            { id: "eid771", tween: [ "style", "${_blood_1_mCopy31}", "top", '251px', { fromValue: '124px'}], position: 18250, duration: 2000 },
            { id: "eid661", tween: [ "transform", "${_blood_1_mCopy31}", "scaleX", '0.8', { fromValue: '0'}], position: 16500, duration: 3750 },
            { id: "eid667", tween: [ "style", "${_blood_1Copy31}", "top", '124px', { fromValue: '-43px'}], position: 16500, duration: 1750 },
            { id: "eid772", tween: [ "style", "${_blood_1Copy31}", "top", '251px', { fromValue: '124px'}], position: 18250, duration: 2000 },
            { id: "eid659", tween: [ "transform", "${_blood_1_mCopy31}", "scaleY", '0.8', { fromValue: '0'}], position: 16500, duration: 3750 },
            { id: "eid663", tween: [ "style", "${_blood_1_mCopy31}", "opacity", '0.1', { fromValue: '1'}], position: 16500, duration: 3749 },
            { id: "eid585", tween: [ "style", "${_blood_1_mCopy28}", "top", '125px', { fromValue: '-43px'}], position: 11750, duration: 1762 },
            { id: "eid765", tween: [ "style", "${_blood_1_mCopy28}", "top", '251px', { fromValue: '125px'}], position: 13512, duration: 1988 },
            { id: "eid586", tween: [ "style", "${_blood_1_mCopy28}", "top", '238px', { fromValue: '251px'}], position: 18250, duration: 1000 },
            { id: "eid769", tween: [ "style", "${_blood_1_mCopy28}", "top", '165px', { fromValue: '238px'}], position: 19250, duration: 1000 },
            { id: "eid593", tween: [ "style", "${_blood_1_mCopy28}", "left", '205px', { fromValue: '-42px'}], position: 11750, duration: 1762 },
            { id: "eid767", tween: [ "style", "${_blood_1_mCopy28}", "left", '548px', { fromValue: '205px'}], position: 13512, duration: 1988 },
            { id: "eid594", tween: [ "style", "${_blood_1_mCopy28}", "left", '794px', { fromValue: '548px'}], position: 18250, duration: 2000 }         ]
      }
   }
},
"blood8": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['-41px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy29',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-41px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy29',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   },
   {
      rect: ['-41px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy32',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-41px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy32',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '0px'],
            ["style", "width", '0px']
         ],
         "${_blood_1Copy32}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${_blood_1_mCopy29}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${_blood_1_mCopy32}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${_blood_1Copy29}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 23000,
         autoPlay: true,
         labels: {
            "8": 18249
         },
         timeline: [
            { id: "eid612", tween: [ "transform", "${_blood_1_mCopy29}", "scaleX", '0.7', { fromValue: '0'}], position: 14500, duration: 3750 },
            { id: "eid613", tween: [ "transform", "${_blood_1_mCopy29}", "scaleX", '1', { fromValue: '0.7'}], position: 21000, duration: 2000 },
            { id: "eid681", tween: [ "style", "${_blood_1_mCopy32}", "opacity", '0.1', { fromValue: '1'}], position: 19250, duration: 3749 },
            { id: "eid614", tween: [ "style", "${_blood_1_mCopy29}", "opacity", '0.1', { fromValue: '1'}], position: 14500, duration: 3749 },
            { id: "eid615", tween: [ "style", "${_blood_1_mCopy29}", "opacity", '0', { fromValue: '0.1'}], position: 21000, duration: 2000 },
            { id: "eid624", tween: [ "transform", "${_blood_1Copy29}", "scaleY", '0.7', { fromValue: '0'}], position: 14500, duration: 3750 },
            { id: "eid625", tween: [ "transform", "${_blood_1Copy29}", "scaleY", '1', { fromValue: '0.7'}], position: 21000, duration: 2000 },
            { id: "eid618", tween: [ "style", "${_blood_1Copy29}", "top", '96px', { fromValue: '-43px'}], position: 14500, duration: 1750 },
            { id: "eid776", tween: [ "style", "${_blood_1Copy29}", "top", '190px', { fromValue: '96px'}], position: 16250, duration: 2000 },
            { id: "eid619", tween: [ "style", "${_blood_1Copy29}", "top", '148px', { fromValue: '190px'}], position: 21000, duration: 1000 },
            { id: "eid784", tween: [ "style", "${_blood_1Copy29}", "top", '25px', { fromValue: '148px'}], position: 22000, duration: 1000 },
            { id: "eid683", tween: [ "style", "${_blood_1_mCopy32}", "left", '152px', { fromValue: '-42px'}], position: 19250, duration: 1750 },
            { id: "eid781", tween: [ "style", "${_blood_1_mCopy32}", "left", '438px', { fromValue: '152px'}], position: 21000, duration: 2000 },
            { id: "eid685", tween: [ "transform", "${_blood_1Copy32}", "scaleX", '0.7', { fromValue: '0'}], position: 19250, duration: 3750 },
            { id: "eid689", tween: [ "style", "${_blood_1Copy32}", "left", '152px', { fromValue: '-42px'}], position: 19250, duration: 1750 },
            { id: "eid782", tween: [ "style", "${_blood_1Copy32}", "left", '438px', { fromValue: '152px'}], position: 21000, duration: 2000 },
            { id: "eid608", tween: [ "style", "${_blood_1_mCopy29}", "top", '96px', { fromValue: '-43px'}], position: 14500, duration: 1750 },
            { id: "eid775", tween: [ "style", "${_blood_1_mCopy29}", "top", '190px', { fromValue: '96px'}], position: 16250, duration: 2000 },
            { id: "eid609", tween: [ "style", "${_blood_1_mCopy29}", "top", '148px', { fromValue: '190px'}], position: 21000, duration: 1000 },
            { id: "eid783", tween: [ "style", "${_blood_1_mCopy29}", "top", '25px', { fromValue: '148px'}], position: 22000, duration: 1000 },
            { id: "eid622", tween: [ "style", "${_blood_1Copy29}", "left", '152px', { fromValue: '-42px'}], position: 14500, duration: 1750 },
            { id: "eid778", tween: [ "style", "${_blood_1Copy29}", "left", '438px', { fromValue: '152px'}], position: 16250, duration: 2000 },
            { id: "eid623", tween: [ "style", "${_blood_1Copy29}", "left", '794px', { fromValue: '438px'}], position: 21000, duration: 2000 },
            { id: "eid687", tween: [ "transform", "${_blood_1Copy32}", "scaleY", '0.7', { fromValue: '0'}], position: 19250, duration: 3750 },
            { id: "eid616", tween: [ "style", "${_blood_1_mCopy29}", "left", '152px', { fromValue: '-42px'}], position: 14500, duration: 1750 },
            { id: "eid777", tween: [ "style", "${_blood_1_mCopy29}", "left", '438px', { fromValue: '152px'}], position: 16250, duration: 2000 },
            { id: "eid617", tween: [ "style", "${_blood_1_mCopy29}", "left", '794px', { fromValue: '438px'}], position: 21000, duration: 2000 },
            { id: "eid679", tween: [ "transform", "${_blood_1_mCopy32}", "scaleX", '0.7', { fromValue: '0'}], position: 19250, duration: 3750 },
            { id: "eid620", tween: [ "transform", "${_blood_1Copy29}", "scaleX", '0.7', { fromValue: '0'}], position: 14500, duration: 3750 },
            { id: "eid621", tween: [ "transform", "${_blood_1Copy29}", "scaleX", '1', { fromValue: '0.7'}], position: 21000, duration: 2000 },
            { id: "eid610", tween: [ "transform", "${_blood_1_mCopy29}", "scaleY", '0.7', { fromValue: '0'}], position: 14500, duration: 3750 },
            { id: "eid611", tween: [ "transform", "${_blood_1_mCopy29}", "scaleY", '1', { fromValue: '0.7'}], position: 21000, duration: 2000 },
            { id: "eid691", tween: [ "style", "${_blood_1Copy32}", "top", '106px', { fromValue: '-43px'}], position: 19250, duration: 1750 },
            { id: "eid780", tween: [ "style", "${_blood_1Copy32}", "top", '190px', { fromValue: '106px'}], position: 21000, duration: 2000 },
            { id: "eid677", tween: [ "transform", "${_blood_1_mCopy32}", "scaleY", '0.7', { fromValue: '0'}], position: 19250, duration: 3750 },
            { id: "eid675", tween: [ "style", "${_blood_1_mCopy32}", "top", '106px', { fromValue: '-43px'}], position: 19250, duration: 1750 },
            { id: "eid779", tween: [ "style", "${_blood_1_mCopy32}", "top", '190px', { fromValue: '106px'}], position: 21000, duration: 2000 }         ]
      }
   }
},
"blood9": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['-41px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy30',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-41px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy30',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   },
   {
      rect: ['-41px','-43px','85px','86px','auto','auto'],
      id: 'blood_1Copy33',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-41px','-43px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy33',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_blood_1_mCopy30}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${symbolSelector}": [
            ["style", "height", '0px'],
            ["style", "width", '0px']
         ],
         "${_blood_1_mCopy33}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${_blood_1Copy30}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ],
         "${_blood_1Copy33}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-42px'],
            ["style", "width", '85px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 26500,
         autoPlay: true,
         labels: {
            "9": 21749
         },
         timeline: [
            { id: "eid640", tween: [ "style", "${_blood_1Copy30}", "top", '148px', { fromValue: '-43px'}], position: 18000, duration: 1750 },
            { id: "eid786", tween: [ "style", "${_blood_1Copy30}", "top", '301px', { fromValue: '148px'}], position: 19750, duration: 2000 },
            { id: "eid641", tween: [ "style", "${_blood_1Copy30}", "top", '248px', { fromValue: '301px'}], position: 24500, duration: 1000 },
            { id: "eid794", tween: [ "style", "${_blood_1Copy30}", "top", '135px', { fromValue: '248px'}], position: 25500, duration: 1000 },
            { id: "eid646", tween: [ "transform", "${_blood_1Copy30}", "scaleX", '0.8', { fromValue: '0'}], position: 18000, duration: 3750 },
            { id: "eid647", tween: [ "transform", "${_blood_1Copy30}", "scaleX", '1', { fromValue: '0.8'}], position: 24500, duration: 2000 },
            { id: "eid636", tween: [ "style", "${_blood_1_mCopy30}", "opacity", '0.1', { fromValue: '1'}], position: 18000, duration: 3749 },
            { id: "eid637", tween: [ "style", "${_blood_1_mCopy30}", "opacity", '0', { fromValue: '0.1'}], position: 24500, duration: 2000 },
            { id: "eid632", tween: [ "transform", "${_blood_1_mCopy30}", "scaleY", '0.8', { fromValue: '0'}], position: 18000, duration: 3750 },
            { id: "eid633", tween: [ "transform", "${_blood_1_mCopy30}", "scaleY", '1', { fromValue: '0.8'}], position: 24500, duration: 2000 },
            { id: "eid709", tween: [ "transform", "${_blood_1Copy33}", "scaleY", '0.8', { fromValue: '0'}], position: 22750, duration: 3750 },
            { id: "eid707", tween: [ "style", "${_blood_1Copy33}", "left", '152px', { fromValue: '-42px'}], position: 22750, duration: 1750 },
            { id: "eid792", tween: [ "style", "${_blood_1Copy33}", "left", '438px', { fromValue: '152px'}], position: 24500, duration: 2000 },
            { id: "eid705", tween: [ "transform", "${_blood_1Copy33}", "scaleX", '0.8', { fromValue: '0'}], position: 22750, duration: 3750 },
            { id: "eid642", tween: [ "style", "${_blood_1Copy30}", "left", '152px', { fromValue: '-42px'}], position: 18000, duration: 1750 },
            { id: "eid788", tween: [ "style", "${_blood_1Copy30}", "left", '438px', { fromValue: '152px'}], position: 19750, duration: 2000 },
            { id: "eid643", tween: [ "style", "${_blood_1Copy30}", "left", '884px', { fromValue: '438px'}], position: 24500, duration: 2000 },
            { id: "eid703", tween: [ "style", "${_blood_1Copy33}", "top", '148px', { fromValue: '-43px'}], position: 22750, duration: 1750 },
            { id: "eid790", tween: [ "style", "${_blood_1Copy33}", "top", '301px', { fromValue: '148px'}], position: 24500, duration: 2000 },
            { id: "eid695", tween: [ "transform", "${_blood_1_mCopy33}", "scaleY", '0.8', { fromValue: '0'}], position: 22750, duration: 3750 },
            { id: "eid699", tween: [ "style", "${_blood_1_mCopy33}", "opacity", '0.1', { fromValue: '1'}], position: 22750, duration: 3749 },
            { id: "eid630", tween: [ "style", "${_blood_1_mCopy30}", "top", '148px', { fromValue: '-43px'}], position: 18000, duration: 1750 },
            { id: "eid785", tween: [ "style", "${_blood_1_mCopy30}", "top", '301px', { fromValue: '148px'}], position: 19750, duration: 2000 },
            { id: "eid631", tween: [ "style", "${_blood_1_mCopy30}", "top", '248px', { fromValue: '301px'}], position: 24500, duration: 1000 },
            { id: "eid793", tween: [ "style", "${_blood_1_mCopy30}", "top", '135px', { fromValue: '248px'}], position: 25500, duration: 1000 },
            { id: "eid634", tween: [ "transform", "${_blood_1_mCopy30}", "scaleX", '0.8', { fromValue: '0'}], position: 18000, duration: 3750 },
            { id: "eid635", tween: [ "transform", "${_blood_1_mCopy30}", "scaleX", '1', { fromValue: '0.8'}], position: 24500, duration: 2000 },
            { id: "eid697", tween: [ "transform", "${_blood_1_mCopy33}", "scaleX", '0.8', { fromValue: '0'}], position: 22750, duration: 3750 },
            { id: "eid638", tween: [ "style", "${_blood_1_mCopy30}", "left", '152px', { fromValue: '-42px'}], position: 18000, duration: 1750 },
            { id: "eid787", tween: [ "style", "${_blood_1_mCopy30}", "left", '438px', { fromValue: '152px'}], position: 19750, duration: 2000 },
            { id: "eid639", tween: [ "style", "${_blood_1_mCopy30}", "left", '884px', { fromValue: '438px'}], position: 24500, duration: 2000 },
            { id: "eid701", tween: [ "style", "${_blood_1_mCopy33}", "left", '152px', { fromValue: '-42px'}], position: 22750, duration: 1750 },
            { id: "eid791", tween: [ "style", "${_blood_1_mCopy33}", "left", '438px', { fromValue: '152px'}], position: 24500, duration: 2000 },
            { id: "eid644", tween: [ "transform", "${_blood_1Copy30}", "scaleY", '0.8', { fromValue: '0'}], position: 18000, duration: 3750 },
            { id: "eid645", tween: [ "transform", "${_blood_1Copy30}", "scaleY", '1', { fromValue: '0.8'}], position: 24500, duration: 2000 },
            { id: "eid693", tween: [ "style", "${_blood_1_mCopy33}", "top", '148px', { fromValue: '-43px'}], position: 22750, duration: 1750 },
            { id: "eid789", tween: [ "style", "${_blood_1_mCopy33}", "top", '301px', { fromValue: '148px'}], position: 24500, duration: 2000 }         ]
      }
   }
},
"fon1": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['-42px','-113px','85px','86px','auto','auto'],
      id: 'blood_1Copy34',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-42px','-113px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy34',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_blood_1Copy34}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ],
         "${symbolSelector}": [
            ["style", "height", '0px'],
            ["style", "width", '0px']
         ],
         "${_blood_1_mCopy34}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 7000,
         autoPlay: true,
         labels: {
            "1": 0
         },
         timeline: [
            { id: "eid805", tween: [ "style", "${_blood_1_mCopy34}", "left", '834px', { fromValue: '-43px'}], position: 0, duration: 7000 },
            { id: "eid803", tween: [ "style", "${_blood_1_mCopy34}", "opacity", '0', { fromValue: '1'}], position: 0, duration: 7000 },
            { id: "eid817", tween: [ "style", "${_blood_1Copy34}", "left", '834px', { fromValue: '-43px'}], position: 0, duration: 7000 },
            { id: "eid808", tween: [ "style", "${_blood_1Copy34}", "top", '37px', { fromValue: '-43px'}], position: 0, duration: 1500 },
            { id: "eid825", tween: [ "style", "${_blood_1Copy34}", "top", '66px', { fromValue: '37px'}], position: 1500, duration: 1750 },
            { id: "eid821", tween: [ "style", "${_blood_1Copy34}", "top", '54px', { fromValue: '66px'}], position: 3250, duration: 1750 },
            { id: "eid823", tween: [ "style", "${_blood_1Copy34}", "top", '-45px', { fromValue: '54px'}], position: 5000, duration: 2000 },
            { id: "eid812", tween: [ "transform", "${_blood_1Copy34}", "scaleY", '0.75', { fromValue: '0'}], position: 0, duration: 7000 },
            { id: "eid814", tween: [ "transform", "${_blood_1Copy34}", "scaleX", '0.75', { fromValue: '0'}], position: 0, duration: 7000 },
            { id: "eid801", tween: [ "transform", "${_blood_1_mCopy34}", "scaleX", '0.75', { fromValue: '0'}], position: 0, duration: 7000 },
            { id: "eid795", tween: [ "style", "${_blood_1_mCopy34}", "top", '37px', { fromValue: '-43px'}], position: 0, duration: 1500 },
            { id: "eid824", tween: [ "style", "${_blood_1_mCopy34}", "top", '66px', { fromValue: '37px'}], position: 1500, duration: 1750 },
            { id: "eid820", tween: [ "style", "${_blood_1_mCopy34}", "top", '54px', { fromValue: '66px'}], position: 3250, duration: 1750 },
            { id: "eid822", tween: [ "style", "${_blood_1_mCopy34}", "top", '-45px', { fromValue: '54px'}], position: 5000, duration: 2000 },
            { id: "eid799", tween: [ "transform", "${_blood_1_mCopy34}", "scaleY", '0.75', { fromValue: '0'}], position: 0, duration: 7000 }         ]
      }
   }
},
"fon1_2": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['-42px','-113px','85px','86px','auto','auto'],
      id: 'blood_1Copy34',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-42px','-113px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy34',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_blood_1Copy34}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ],
         "${_blood_1_mCopy34}": [
            ["style", "top", '-43px'],
            ["transform", "scaleX", '0'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["style", "height", '86px'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ],
         "${symbolSelector}": [
            ["style", "height", '0px'],
            ["style", "width", '0px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 9500,
         autoPlay: true,
         labels: {
            "1": 2500
         },
         timeline: [
            { id: "eid805", tween: [ "style", "${_blood_1_mCopy34}", "left", '834px', { fromValue: '-43px'}], position: 2500, duration: 7000 },
            { id: "eid803", tween: [ "style", "${_blood_1_mCopy34}", "opacity", '0', { fromValue: '1'}], position: 2500, duration: 7000 },
            { id: "eid817", tween: [ "style", "${_blood_1Copy34}", "left", '834px', { fromValue: '-43px'}], position: 2500, duration: 7000 },
            { id: "eid808", tween: [ "style", "${_blood_1Copy34}", "top", '37px', { fromValue: '-43px'}], position: 2500, duration: 1500 },
            { id: "eid825", tween: [ "style", "${_blood_1Copy34}", "top", '66px', { fromValue: '37px'}], position: 4000, duration: 1750 },
            { id: "eid821", tween: [ "style", "${_blood_1Copy34}", "top", '54px', { fromValue: '66px'}], position: 5750, duration: 1750 },
            { id: "eid823", tween: [ "style", "${_blood_1Copy34}", "top", '-45px', { fromValue: '54px'}], position: 7500, duration: 2000 },
            { id: "eid812", tween: [ "transform", "${_blood_1Copy34}", "scaleY", '0.75', { fromValue: '0'}], position: 2500, duration: 7000 },
            { id: "eid814", tween: [ "transform", "${_blood_1Copy34}", "scaleX", '0.75', { fromValue: '0'}], position: 2500, duration: 7000 },
            { id: "eid801", tween: [ "transform", "${_blood_1_mCopy34}", "scaleX", '0.75', { fromValue: '0'}], position: 2500, duration: 7000 },
            { id: "eid795", tween: [ "style", "${_blood_1_mCopy34}", "top", '37px', { fromValue: '-43px'}], position: 2500, duration: 1500 },
            { id: "eid824", tween: [ "style", "${_blood_1_mCopy34}", "top", '66px', { fromValue: '37px'}], position: 4000, duration: 1750 },
            { id: "eid820", tween: [ "style", "${_blood_1_mCopy34}", "top", '54px', { fromValue: '66px'}], position: 5750, duration: 1750 },
            { id: "eid822", tween: [ "style", "${_blood_1_mCopy34}", "top", '-45px', { fromValue: '54px'}], position: 7500, duration: 2000 },
            { id: "eid799", tween: [ "transform", "${_blood_1_mCopy34}", "scaleY", '0.75', { fromValue: '0'}], position: 2500, duration: 7000 }         ]
      }
   }
},
"fon1_3": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      rect: ['-42px','-113px','85px','86px','auto','auto'],
      id: 'blood_1Copy34',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1.png','0px','0px']
   },
   {
      rect: ['-42px','-113px','85px','86px','auto','auto'],
      id: 'blood_1_mCopy34',
      transform: [[],['206']],
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/blood_1_m.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_blood_1Copy34}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ],
         "${symbolSelector}": [
            ["style", "height", '0px'],
            ["style", "width", '0px']
         ],
         "${_blood_1_mCopy34}": [
            ["style", "top", '-43px'],
            ["style", "height", '86px'],
            ["transform", "scaleY", '0'],
            ["transform", "rotateZ", '206deg'],
            ["transform", "scaleX", '0'],
            ["style", "opacity", '1'],
            ["style", "left", '-43px'],
            ["style", "width", '85px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 11750,
         autoPlay: true,
         labels: {
            "1": 4750
         },
         timeline: [
            { id: "eid805", tween: [ "style", "${_blood_1_mCopy34}", "left", '834px', { fromValue: '-43px'}], position: 4750, duration: 7000 },
            { id: "eid803", tween: [ "style", "${_blood_1_mCopy34}", "opacity", '0', { fromValue: '1'}], position: 4750, duration: 7000 },
            { id: "eid817", tween: [ "style", "${_blood_1Copy34}", "left", '834px', { fromValue: '-43px'}], position: 4750, duration: 7000 },
            { id: "eid808", tween: [ "style", "${_blood_1Copy34}", "top", '37px', { fromValue: '-43px'}], position: 4750, duration: 1500 },
            { id: "eid825", tween: [ "style", "${_blood_1Copy34}", "top", '66px', { fromValue: '37px'}], position: 6250, duration: 1750 },
            { id: "eid821", tween: [ "style", "${_blood_1Copy34}", "top", '54px', { fromValue: '66px'}], position: 8000, duration: 1750 },
            { id: "eid823", tween: [ "style", "${_blood_1Copy34}", "top", '-45px', { fromValue: '54px'}], position: 9750, duration: 2000 },
            { id: "eid812", tween: [ "transform", "${_blood_1Copy34}", "scaleY", '0.75', { fromValue: '0'}], position: 4750, duration: 7000 },
            { id: "eid814", tween: [ "transform", "${_blood_1Copy34}", "scaleX", '0.75', { fromValue: '0'}], position: 4750, duration: 7000 },
            { id: "eid801", tween: [ "transform", "${_blood_1_mCopy34}", "scaleX", '0.75', { fromValue: '0'}], position: 4750, duration: 7000 },
            { id: "eid795", tween: [ "style", "${_blood_1_mCopy34}", "top", '37px', { fromValue: '-43px'}], position: 4750, duration: 1500 },
            { id: "eid824", tween: [ "style", "${_blood_1_mCopy34}", "top", '66px', { fromValue: '37px'}], position: 6250, duration: 1750 },
            { id: "eid820", tween: [ "style", "${_blood_1_mCopy34}", "top", '54px', { fromValue: '66px'}], position: 8000, duration: 1750 },
            { id: "eid822", tween: [ "style", "${_blood_1_mCopy34}", "top", '-45px', { fromValue: '54px'}], position: 9750, duration: 2000 },
            { id: "eid799", tween: [ "transform", "${_blood_1_mCopy34}", "scaleY", '0.75', { fromValue: '0'}], position: 4750, duration: 7000 }         ]
      }
   }
},
"yellow3": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'yellow_1',
      type: 'image',
      rect: ['0px','0px','155px','154px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/153/yellow_1.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${symbolSelector}": [
            ["style", "height", '154px'],
            ["style", "width", '155px']
         ],
         "${_yellow_1}": [
            ["style", "top", '0px'],
            ["style", "height", '154px'],
            ["style", "left", '0px'],
            ["style", "width", '155px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 4000,
         autoPlay: true,
         labels: {
            "1": 0
         },
         timeline: [
            { id: "eid848", tween: [ "style", "${_yellow_1}", "top", '3px', { fromValue: '0px'}], position: 0, duration: 1000 },
            { id: "eid849", tween: [ "style", "${_yellow_1}", "top", '0px', { fromValue: '3px'}], position: 1000, duration: 1000 },
            { id: "eid850", tween: [ "style", "${_yellow_1}", "top", '-3px', { fromValue: '0px'}], position: 2000, duration: 1000 },
            { id: "eid851", tween: [ "style", "${_yellow_1}", "top", '0px', { fromValue: '-3px'}], position: 3000, duration: 1000 }         ]
      }
   }
},
"yellow2": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'yellow_2',
      type: 'image',
      rect: ['0px','0px','116px','116px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/153/yellow_2.png','0px','0px']
   },
   {
      rect: ['0px','0px','116px','116px','auto','auto'],
      id: 'yellow_2_m',
      opacity: 0.35,
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/yellow_2_m.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_yellow_2_m}": [
            ["style", "top", '0px'],
            ["transform", "scaleY", '1.03'],
            ["transform", "scaleX", '1.03'],
            ["style", "height", '116px'],
            ["style", "opacity", '0.35'],
            ["style", "left", '0px'],
            ["style", "width", '116px']
         ],
         "${_yellow_2}": [
            ["style", "top", '0px'],
            ["style", "height", '116px'],
            ["style", "left", '0px'],
            ["style", "width", '116px']
         ],
         "${symbolSelector}": [
            ["style", "height", '116px'],
            ["style", "width", '116px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 4000,
         autoPlay: true,
         labels: {
            "1": 0
         },
         timeline: [
            { id: "eid855", tween: [ "style", "${_yellow_2}", "top", '2px', { fromValue: '0px'}], position: 0, duration: 1000 },
            { id: "eid857", tween: [ "style", "${_yellow_2}", "top", '0px', { fromValue: '2px'}], position: 1000, duration: 1000 },
            { id: "eid858", tween: [ "style", "${_yellow_2}", "top", '-2px', { fromValue: '0px'}], position: 2000, duration: 1000 },
            { id: "eid861", tween: [ "style", "${_yellow_2}", "top", '0px', { fromValue: '-2px'}], position: 3000, duration: 1000 },
            { id: "eid854", tween: [ "style", "${_yellow_2_m}", "top", '2px', { fromValue: '0px'}], position: 0, duration: 1000 },
            { id: "eid856", tween: [ "style", "${_yellow_2_m}", "top", '0px', { fromValue: '2px'}], position: 1000, duration: 1000 },
            { id: "eid859", tween: [ "style", "${_yellow_2_m}", "top", '-2px', { fromValue: '0px'}], position: 2000, duration: 1000 },
            { id: "eid860", tween: [ "style", "${_yellow_2_m}", "top", '0px', { fromValue: '-2px'}], position: 3000, duration: 1000 }         ]
      }
   }
},
"yellow1": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'yellow_3',
      type: 'image',
      rect: ['2px','2px','96px','95px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/153/yellow_3.png','0px','0px']
   },
   {
      rect: ['2px','2px','96px','95px','auto','auto'],
      transform: [[],[],[],['1.05','1.05']],
      id: 'yellow_3_m',
      opacity: 0.75,
      type: 'image',
      fill: ['rgba(0,0,0,0)','images/153/yellow_3_m.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_yellow_3}": [
            ["style", "top", '2px'],
            ["style", "height", '95px'],
            ["style", "left", '2px'],
            ["style", "width", '96px']
         ],
         "${_yellow_3_m}": [
            ["style", "top", '2px'],
            ["transform", "scaleY", '1.05'],
            ["style", "height", '95px'],
            ["transform", "scaleX", '1.05'],
            ["style", "opacity", '0.5'],
            ["style", "left", '2px'],
            ["style", "width", '96px']
         ],
         "${symbolSelector}": [
            ["style", "height", '100px'],
            ["style", "width", '101px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 4000,
         autoPlay: true,
         labels: {
            "1": 0
         },
         timeline: [
            { id: "eid864", tween: [ "style", "${_yellow_3_m}", "top", '3px', { fromValue: '2px'}], position: 0, duration: 1000 },
            { id: "eid866", tween: [ "style", "${_yellow_3_m}", "top", '2px', { fromValue: '3px'}], position: 1000, duration: 1000 },
            { id: "eid868", tween: [ "style", "${_yellow_3_m}", "top", '1px', { fromValue: '2px'}], position: 2000, duration: 1000 },
            { id: "eid870", tween: [ "style", "${_yellow_3_m}", "top", '2px', { fromValue: '1px'}], position: 3000, duration: 1000 },
            { id: "eid865", tween: [ "style", "${_yellow_3}", "top", '3px', { fromValue: '2px'}], position: 0, duration: 1000 },
            { id: "eid867", tween: [ "style", "${_yellow_3}", "top", '2px', { fromValue: '3px'}], position: 1000, duration: 1000 },
            { id: "eid869", tween: [ "style", "${_yellow_3}", "top", '1px', { fromValue: '2px'}], position: 2000, duration: 1000 },
            { id: "eid871", tween: [ "style", "${_yellow_3}", "top", '2px', { fromValue: '1px'}], position: 3000, duration: 1000 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-2746708");
