/***********************
* Adobe Edge Animate Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge Animate
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
   })("stage");
   //Edge symbol end:'stage'

   //=========================================================
   
   //Edge symbol: 'blood1'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 7738, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("1");

      });
      //Edge binding end

   })("blood1");
   //Edge symbol end:'blood1'

   //=========================================================
   
   //Edge symbol: 'blood2'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 9500, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("2");

      });
      //Edge binding end

   })("blood2");
   //Edge symbol end:'blood2'

   //=========================================================
   
   //Edge symbol: 'blood3'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 11262, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("3");

      });
      //Edge binding end

   })("blood3");
   //Edge symbol end:'blood3'

   //=========================================================
   
   //Edge symbol: 'blood4'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 14988, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("4");

      });
      //Edge binding end

   })("blood4");
   //Edge symbol end:'blood4'

   //=========================================================
   
   //Edge symbol: 'blood5'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 16488, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("5");

      });
      //Edge binding end

   })("blood5");
   //Edge symbol end:'blood5'

   //=========================================================
   
   //Edge symbol: 'blood6'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 18000, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("6");

      });
      //Edge binding end

   })("blood6");
   //Edge symbol end:'blood6'

   //=========================================================
   
   //Edge symbol: 'blood7'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 20272, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("7");

      });
      //Edge binding end

   })("blood7");
   //Edge symbol end:'blood7'

   //=========================================================
   
   //Edge symbol: 'blood8'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 22999, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("8");

      });
      //Edge binding end

   })("blood8");
   //Edge symbol end:'blood8'

   //=========================================================
   
   //Edge symbol: 'blood9'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 26499, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("9");

      });
      //Edge binding end

   })("blood9");
   //Edge symbol end:'blood9'

   //=========================================================
   
   //Edge symbol: 'fon1'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 7000, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("1");

      });
      //Edge binding end

   })("fon1");
   //Edge symbol end:'fon1'

   //=========================================================
   
   //Edge symbol: 'fon1_1'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 9500, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("1");

      });
      //Edge binding end

   })("fon1_2");
   //Edge symbol end:'fon1_2'

   //=========================================================
   
   //Edge symbol: 'fon1_1'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 11750, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("1");

      });
      //Edge binding end

   })("fon1_3");
   //Edge symbol end:'fon1_3'

   //=========================================================
   
   //Edge symbol: 'yellow3'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 4000, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("1");

      });
      //Edge binding end

   })("yellow3");
   //Edge symbol end:'yellow3'

   //=========================================================
   
   //Edge symbol: 'yellow2'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 4000, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("1");

      });
      //Edge binding end

   })("yellow2");
   //Edge symbol end:'yellow2'

   //=========================================================
   
   //Edge symbol: 'yellow1'
   (function(symbolName) {   
   
      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 4000, function(sym, e) {
         // play the timeline from the given position (ms or label)
         sym.play("1");

      });
      //Edge binding end

   })("yellow1");
   //Edge symbol end:'yellow1'

})(jQuery, AdobeEdge, "EDGE-2746708");