/**  * @author Sergey Chikuyonok (sc@design.ru) */

/** * Случайное число в заданном диапазоне  */
function rnd(n1, n2){
	return n1 + Math.round(Math.random() * (n2 - n1));
}


/** * Частица */
function sprayParticle(sprayObjectName, startX, startY, cp1X, cp1Y, cp2X, cp2Y, endX1, endX2, endY1, endY2, stClr1, stClr2, stClr3, endClr1, endClr2, endClr3, stSize1, stSize2, endSize1, endSize2){
	var sprayObject = $(sprayObjectName);
	/** Параметры кривой Безье */
	var bezier_params = {
		// начальная точка        start_x:  viewport_width / 2,
		start_x: startX, 
		start_y: startY,

		// первая контрольная точка
		cp1_x: cp1X,
		cp1_y: cp1Y,

		// вторая контрольная точка
		cp2_x: cp2X,
		cp2_y: cp2Y,
		
		// конечная точка
		end_x: rnd(endX1, endX2),
		end_y: rnd(endY1, endY2)
	};

	//var start_color = new jTweener.Utils.Color(rnd(0, 255), rnd(0, 255), rnd(0, 255));
	var start_color = new jTweener.Utils.Color(stClr1, stClr2, stClr3);
	var end_color = new jTweener.Utils.Color(endClr1, endClr2, endClr3);

	var start_size = rnd(stSize1, stSize2);
	var end_size = rnd(endSize1, endSize2);

	// создаю элемент частицы
	var particle = $('<div  class="particle">&bull;</div>');

	// определяем внешний вид и позицию частицы
	particle.css({
		color: start_color + '',
		fontSize: start_size,
		top: bezier_params.start_y,
		left: bezier_params.start_x
	});

	sprayObject.append(particle);

	var target_size = rnd(20, 40);

	/** Основной итератор */
	var time = 0;

	return {
		/** * getter/setter для позиции и внешнего вида частицы */
		value: function(){
			if (!arguments.length) {
				return time;
			} else {
				time = arguments[0];

				var x = jTweener.Utils.bezier3(time, bezier_params.start_x, bezier_params.cp1_x, bezier_params.cp2_x, bezier_params.end_x);
				var y = jTweener.Utils.bezier3(time, bezier_params.start_y, bezier_params.cp1_y, bezier_params.cp2_y, bezier_params.end_y);

				var s = particle[0].style;

				s.color = jTweener.Utils.Color.blend(start_color, end_color, time) + '';
				s.fontSize = Math.round(start_size + (end_size - start_size) * time) + 'px';
				s.left = x + 'px';
				s.top = y + 'px';
			}
		},

		/**  Удаляет частицу со страницы 	 */
		remove: function(){
			particle.remove();
		}
	}
};

/** * Создает частицу и запускает ее анимацию */
function generateParticleLungs(){
	var p = sprayParticle('#spray_lungs', 18, -1, 135, -15, 70, 125, 0, 200, 105, 220, 143, 195, 247, 237, 13, 92, 6, 25, 40, 50);
	jTweener.addTween(p, {
		value: 1,
		transition: 'easeoutquint',
		time: 12,
		onComplete: function(){
			p.remove();
		}
	});
};
function generateParticleStomach(){
	var p = sprayParticle('#spray_stomach', 65, -5, 30, 180, 170, 50, 0, 140, 153, 210, 116, 174, 232, 109, 176, 248, 6, 25, 40, 45);
	jTweener.addTween(p, {
		value: 1,
		transition: 'easeoutsine',
		time: 6,
		onComplete: function(){
			p.remove();
		}
	});
};
function generateParticleLiver(){
	var p = sprayParticle('#spray_liver', 110, -15, -20, 130, 0, -50, -15, 130, -15, 100, 205, 102, 118, 237, 13, 92, 6, 25, 40, 45);
	jTweener.addTween(p, {
		value: 1,
		transition: 'easeoutsine',
		time: 4,
		onComplete: function(){
			p.remove();
		}
	});
};
function generateParticleBowel(){
	var p = sprayParticle('#spray_bowel', 30, -10, 3, 80, 120, 30, 0, 170, 30, 150, 142, 193, 243, 206, 216, 224, 30, 30, 25, 30);
	jTweener.addTween(p, {
		value: 1,
		transition: 'easeinoutsine',
		time: 2,
		onComplete: function(){
			p.remove();
		}
	});
};



function startLungs(){
	setInterval(generateParticleLungs, 200);
	generateParticleLungs();
};
function startStomach(){
	setInterval(generateParticleStomach, 500);
	generateParticleStomach();
};
function startLiver(){
	setInterval(generateParticleLiver, 900);
	generateParticleLiver();
};
function startBowel(){
	setInterval(generateParticleBowel, 1100);
	generateParticleBowel();
};




