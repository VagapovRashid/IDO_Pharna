/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/152/';

var fonts = {};
   fonts['Helvetica']='';


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Symbol_82',
            type:'rect',
            rect:['-64','315','auto','auto','auto','auto']
         },
         {
            id:'_8a',
            type:'rect',
            rect:['88px','315px','392px','35px','auto','auto'],
            fill:["rgba(50,85,118,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'Text8',
            type:'text',
            rect:['489px','324px','auto','auto','auto','auto'],
            text:"1800",
            font:['Helvetica',14,"rgba(50,85,118,1.00)","800","none",""]
         },
         {
            id:'Symbol_7',
            type:'rect',
            rect:['-63','270','auto','auto','auto','auto']
         },
         {
            id:'_7a',
            type:'rect',
            rect:['88px','270px','296px','35px','auto','auto'],
            fill:["rgba(152,136,127,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'Text7',
            type:'text',
            rect:['393px','279px','auto','auto','auto','auto'],
            text:"1345",
            font:['Helvetica',14,"rgba(152,136,127,1.00)","800","none",""]
         },
         {
            id:'_6a',
            type:'rect',
            rect:['88px','225px','266px','35px','auto','auto'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'Symbol_6',
            type:'rect',
            rect:['-63','225','auto','auto','auto','auto']
         },
         {
            id:'Text6',
            type:'text',
            rect:['365px','234px','auto','auto','auto','auto'],
            text:"1200",
            font:['Helvetica',14,"rgba(218,35,24,1.00)","800","none",""]
         },
         {
            id:'Symbol_5',
            type:'rect',
            rect:['-63','180','auto','auto','auto','auto']
         },
         {
            id:'_5a',
            type:'rect',
            rect:['88px','180px','208px','35px','auto','auto'],
            fill:["rgba(75,107,65,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'Text5',
            type:'text',
            rect:['306px','189px','auto','auto','auto','auto'],
            text:"935",
            font:['Helvetica',14,"rgba(75,107,65,1.00)","800","none",""]
         },
         {
            id:'Symbol_4',
            type:'rect',
            rect:['-63','135','auto','auto','auto','auto']
         },
         {
            id:'_4a',
            type:'rect',
            rect:['88px','135px','28px','35px','auto','auto'],
            fill:["rgba(105,87,76,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'Text4',
            type:'text',
            rect:['126px','144px','auto','auto','auto','auto'],
            text:"76",
            font:['Helvetica',14,"rgba(105,87,76,1.00)","800","none",""]
         },
         {
            id:'Symbol_3',
            type:'rect',
            rect:['-63','90','auto','auto','auto','auto']
         },
         {
            id:'_3a',
            type:'rect',
            rect:['88px','90px','23px','35px','auto','auto'],
            fill:["rgba(171,160,152,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'Text3',
            type:'text',
            rect:['119px','99px','auto','auto','auto','auto'],
            text:"53",
            font:['Helvetica',14,"rgba(171,160,152,1.00)","800","none",""]
         },
         {
            id:'Symbol_2',
            type:'rect',
            rect:['-47','45','auto','auto','auto','auto']
         },
         {
            id:'_2a',
            type:'rect',
            rect:['88px','45px','16px','35px','auto','auto'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'Text2',
            type:'text',
            rect:['113px','54px','auto','auto','auto','auto'],
            text:"12",
            font:['Helvetica',14,"rgba(218,35,24,1.00)","800","none",""]
         },
         {
            id:'Symbol_1',
            type:'rect',
            rect:['-63px','0px','auto','auto','auto','auto'],
            transform:[[],[],[],['0.936']]
         },
         {
            id:'_1a',
            type:'rect',
            rect:['88px','0px','14px','35px','auto','auto'],
            fill:["rgba(135,135,134,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'Text1',
            type:'text',
            rect:['111px','9px','auto','auto','auto','auto'],
            text:"10",
            font:['Helvetica',14,"rgba(135,135,134,1.00)","800","none",""]
         },
         {
            id:'gradient',
            type:'image',
            rect:['0','0','25px','350px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"gradient.png",'0px','0px']
         }],
         symbolInstances: [
         {
            id:'Symbol_82',
            symbolName:'Symbol_8'
         },
         {
            id:'Symbol_2',
            symbolName:'Symbol_2'
         },
         {
            id:'Symbol_1',
            symbolName:'Symbol_1'
         },
         {
            id:'Symbol_6',
            symbolName:'Symbol_6'
         },
         {
            id:'Symbol_3',
            symbolName:'Symbol_3'
         },
         {
            id:'Symbol_7',
            symbolName:'Symbol_7'
         },
         {
            id:'Symbol_4',
            symbolName:'Symbol_4'
         },
         {
            id:'Symbol_5',
            symbolName:'Symbol_5'
         }
         ]
      },
   states: {
      "Base State": {
         "${_Text7}": [
            ["style", "top", '279px'],
            ["style", "opacity", '0'],
            ["style", "font-family", 'Helvetica'],
            ["color", "color", 'rgba(152,136,127,1.00)'],
            ["style", "font-weight", '800'],
            ["style", "left", '393px'],
            ["style", "font-size", '14px']
         ],
         "${_Text3}": [
            ["style", "top", '99px'],
            ["style", "opacity", '0'],
            ["style", "font-family", 'Helvetica'],
            ["color", "color", 'rgba(171,160,152,1.00)'],
            ["style", "font-weight", '800'],
            ["style", "left", '122px'],
            ["style", "font-size", '14px']
         ],
         "${_Text8}": [
            ["style", "top", '324px'],
            ["style", "opacity", '0'],
            ["style", "font-family", 'Helvetica'],
            ["color", "color", 'rgba(50,85,118,1.00)'],
            ["style", "font-weight", '800'],
            ["style", "left", '489px'],
            ["style", "font-size", '14px']
         ],
         "${__6a}": [
            ["style", "height", '35px'],
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["style", "top", '225px'],
            ["style", "width", '0px']
         ],
         "${__2a}": [
            ["style", "height", '35px'],
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["style", "top", '45px'],
            ["style", "width", '0px']
         ],
         "${__4a}": [
            ["style", "height", '35px'],
            ["color", "background-color", 'rgba(105,87,76,1.00)'],
            ["style", "top", '135px'],
            ["style", "width", '0px']
         ],
         "${__8a}": [
            ["style", "height", '35px'],
            ["color", "background-color", 'rgba(50,85,118,1.00)'],
            ["style", "top", '315px'],
            ["style", "width", '0px']
         ],
         "${__1a}": [
            ["style", "height", '35px'],
            ["color", "background-color", 'rgba(135,135,134,1.00)'],
            ["style", "width", '0px']
         ],
         "${_Text1}": [
            ["style", "top", '9px'],
            ["style", "opacity", '0'],
            ["style", "font-family", 'Helvetica'],
            ["color", "color", 'rgba(135,135,134,1.00)'],
            ["style", "font-weight", '800'],
            ["style", "left", '111px'],
            ["style", "font-size", '14px']
         ],
         "${__5a}": [
            ["color", "background-color", 'rgba(75,107,65,1.00)'],
            ["style", "height", '35px'],
            ["style", "top", '180px'],
            ["style", "width", '0px']
         ],
         "${__3a}": [
            ["color", "background-color", 'rgba(171,160,152,1.00)'],
            ["style", "height", '35px'],
            ["style", "top", '90px'],
            ["style", "width", '0px']
         ],
         "${_Symbol_1}": [
            ["style", "top", '0px'],
            ["transform", "scaleX", '0.93569'],
            ["style", "left", '-63px'],
            ["transform", "scaleY", '1']
         ],
         "${_Text6}": [
            ["style", "top", '234px'],
            ["style", "opacity", '0'],
            ["style", "font-family", 'Helvetica'],
            ["color", "color", 'rgba(218,35,24,1.00)'],
            ["style", "font-weight", '800'],
            ["style", "left", '365px'],
            ["style", "font-size", '14px']
         ],
         "${_gradient}": [
            ["style", "height", '350px'],
            ["style", "width", '25px']
         ],
         "${_Text4}": [
            ["style", "top", '144px'],
            ["style", "opacity", '0'],
            ["style", "font-family", 'Helvetica'],
            ["color", "color", 'rgba(105,87,76,1.00)'],
            ["style", "font-weight", '800'],
            ["style", "left", '126px'],
            ["style", "font-size", '14px']
         ],
         "${_Text2}": [
            ["style", "top", '54px'],
            ["style", "opacity", '0'],
            ["style", "font-family", 'Helvetica'],
            ["color", "color", 'rgba(218,35,24,1.00)'],
            ["style", "font-weight", '800'],
            ["style", "left", '113px'],
            ["style", "font-size", '14px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,0.00)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '350px'],
            ["style", "width", '561px']
         ],
         "${_Text5}": [
            ["style", "top", '189px'],
            ["style", "opacity", '0'],
            ["style", "font-family", 'Helvetica'],
            ["color", "color", 'rgba(75,107,65,1.00)'],
            ["style", "font-weight", '800'],
            ["style", "left", '306px'],
            ["style", "font-size", '14px']
         ],
         "${__7a}": [
            ["color", "background-color", 'rgba(152,136,127,1.00)'],
            ["style", "height", '35px'],
            ["style", "top", '270px'],
            ["style", "width", '0px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 9500,
         autoPlay: true,
         timeline: [
            { id: "eid127", tween: [ "style", "${_Text2}", "opacity", '1', { fromValue: '0.000000'}], position: 6500, duration: 64 },
            { id: "eid197", tween: [ "style", "${_Text5}", "left", '306px', { fromValue: '306px'}], position: 7021, duration: 0 },
            { id: "eid194", tween: [ "style", "${_Text3}", "left", '122px', { fromValue: '122px'}], position: 9500, duration: 0 },
            { id: "eid83", tween: [ "style", "${__7a}", "width", '296px', { fromValue: '0px'}], position: 4000, duration: 2564, easing: "easeOutQuad" },
            { id: "eid70", tween: [ "style", "${__5a}", "width", '208px', { fromValue: '0px'}], position: 4000, duration: 2176, easing: "easeOutQuad" },
            { id: "eid62", tween: [ "style", "${__4a}", "width", '28px', { fromValue: '0px'}], position: 4000, duration: 1076, easing: "easeOutQuad" },
            { id: "eid130", tween: [ "style", "${_Text7}", "opacity", '1', { fromValue: '0.000000'}], position: 6500, duration: 64 },
            { id: "eid14", tween: [ "style", "${__1a}", "width", '14px', { fromValue: '0px'}], position: 4000, duration: 388, easing: "easeOutQuad" },
            { id: "eid132", tween: [ "style", "${_Text1}", "opacity", '1', { fromValue: '0.000000'}], position: 6500, duration: 64 },
            { id: "eid131", tween: [ "style", "${_Text6}", "opacity", '1', { fromValue: '0.000000'}], position: 6500, duration: 64 },
            { id: "eid77", tween: [ "style", "${__6a}", "width", '266px', { fromValue: '0px'}], position: 4000, duration: 2564, easing: "easeOutQuad" },
            { id: "eid53", tween: [ "style", "${__3a}", "width", '23px', { fromValue: '0px'}], position: 4000, duration: 750, easing: "easeOutQuad" },
            { id: "eid133", tween: [ "style", "${_Text4}", "opacity", '1', { fromValue: '0.000000'}], position: 6500, duration: 64 },
            { id: "eid91", tween: [ "style", "${__8a}", "width", '392px', { fromValue: '0px'}], position: 4000, duration: 2564, easing: "easeOutQuad" },
            { id: "eid129", tween: [ "style", "${_Text8}", "opacity", '1', { fromValue: '0.000000'}], position: 6500, duration: 64 },
            { id: "eid126", tween: [ "style", "${_Text5}", "opacity", '1', { fromValue: '0.000000'}], position: 6500, duration: 64 },
            { id: "eid42", tween: [ "style", "${__2a}", "width", '16px', { fromValue: '0px'}], position: 4000, duration: 388, easing: "easeOutQuad" },
            { id: "eid128", tween: [ "style", "${_Text3}", "opacity", '1', { fromValue: '0.000000'}], position: 6500, duration: 64 }         ]
      }
   }
},
"Symbol_1": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: '_1',
      type: 'image',
      rect: ['0px','0px','156px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_13.png','0px','0px']
   },
   {
      id: '_1Copy3',
      type: 'image',
      rect: ['0px','0px','156px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_13.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${__1Copy3}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "background-position", [-156,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '0px'],
            ["style", "width", '156px']
         ],
         "${__1}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "left", '0px'],
            ["style", "background-position", [-156,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '156px']
         ],
         "${symbolSelector}": [
            ["style", "height", '35px'],
            ["style", "width", '156px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 12000,
         autoPlay: true,
         labels: {
            "loop": 4000
         },
         timeline: [
            { id: "eid137", tween: [ "style", "${__1}", "background-position", [156,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-156,0]}], position: 0, duration: 8000 },
            { id: "eid143", tween: [ "style", "${__1Copy3}", "background-position", [0,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-156,0]}], position: 4000, duration: 4000 },
            { id: "eid144", tween: [ "style", "${__1Copy3}", "background-position", [156,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [0,0]}], position: 8000, duration: 4000 }         ]
      }
   }
},
"Symbol_2": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: '_2',
      type: 'image',
      rect: ['0px','0px','145px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_2.png','0px','0px']
   },
   {
      id: '_2Copy2',
      type: 'image',
      rect: ['0px','0px','145px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_2.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${__2Copy2}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "left", '0px'],
            ["style", "background-position", [-145,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '145px']
         ],
         "${__2}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "background-position", [-145,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '0px'],
            ["style", "width", '145px']
         ],
         "${symbolSelector}": [
            ["style", "height", '35px'],
            ["style", "width", '145px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 12000,
         autoPlay: true,
         labels: {
            "loop": 4000
         },
         timeline: [
            { id: "eid36", tween: [ "style", "${__2}", "background-position", [145,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-145,0]}], position: 0, duration: 8000 },
            { id: "eid38", tween: [ "style", "${__2Copy2}", "background-position", [0,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-145,0]}], position: 4000, duration: 4000 },
            { id: "eid39", tween: [ "style", "${__2Copy2}", "background-position", [145,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [0,0]}], position: 8000, duration: 4000 }         ]
      }
   }
},
"Symbol_3": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: '_3',
      type: 'image',
      rect: ['0px','0px','161px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_32.png','0px','0px']
   },
   {
      id: '_3Copy',
      type: 'image',
      rect: ['0px','0px','161px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_32.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${__3}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "left", '0px'],
            ["style", "background-position", [-161,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '161px']
         ],
         "${__3Copy}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "background-position", [-161,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '0px'],
            ["style", "width", '161px']
         ],
         "${symbolSelector}": [
            ["style", "height", '35px'],
            ["style", "width", '161px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 12000,
         autoPlay: true,
         labels: {
            "loop": 4000
         },
         timeline: [
            { id: "eid152", tween: [ "style", "${__3Copy}", "background-position", [0,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-161,0]}], position: 4000, duration: 4000 },
            { id: "eid153", tween: [ "style", "${__3Copy}", "background-position", [161,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [0,0]}], position: 8000, duration: 4000 },
            { id: "eid151", tween: [ "style", "${__3}", "background-position", [161,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-161,0]}], position: 0, duration: 8000 }         ]
      }
   }
},
"Symbol_4": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: '_4',
      type: 'image',
      rect: ['0px','0px','161px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_42.png','0px','0px']
   },
   {
      id: '_4Copy',
      type: 'image',
      rect: ['0px','0px','161px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_42.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${__4}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "left", '0px'],
            ["style", "background-position", [-161,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '161px']
         ],
         "${symbolSelector}": [
            ["style", "height", '35px'],
            ["style", "width", '161px']
         ],
         "${__4Copy}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "background-position", [-161,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '0px'],
            ["style", "width", '161px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 12000,
         autoPlay: true,
         labels: {
            "loop": 4000
         },
         timeline: [
            { id: "eid156", tween: [ "style", "${__4}", "background-position", [161,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-161,0]}], position: 0, duration: 8000 },
            { id: "eid157", tween: [ "style", "${__4Copy}", "background-position", [0,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-161,0]}], position: 4000, duration: 4000 },
            { id: "eid158", tween: [ "style", "${__4Copy}", "background-position", [161,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [0,0]}], position: 8000, duration: 4000 }         ]
      }
   }
},
"Symbol_5": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: '_5',
      type: 'image',
      rect: ['0px','0px','161px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_52.png','0px','0px']
   },
   {
      id: '_5Copy',
      type: 'image',
      rect: ['0px','0px','161px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_52.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${__5Copy}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "background-position", [-161,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '0px'],
            ["style", "width", '161px']
         ],
         "${__5}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "left", '0px'],
            ["style", "background-position", [-161,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '161px']
         ],
         "${symbolSelector}": [
            ["style", "height", '35px'],
            ["style", "width", '161px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 12000,
         autoPlay: true,
         labels: {
            "loop": 4000
         },
         timeline: [
            { id: "eid162", tween: [ "style", "${__5Copy}", "background-position", [0,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-161,0]}], position: 4000, duration: 4000 },
            { id: "eid163", tween: [ "style", "${__5Copy}", "background-position", [161,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [0,0]}], position: 8000, duration: 4000 },
            { id: "eid161", tween: [ "style", "${__5}", "background-position", [161,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-161,0]}], position: 0, duration: 8000 }         ]
      }
   }
},
"Symbol_6": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: '_62',
      type: 'image',
      rect: ['0px','0px','161px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_62.png','0px','0px']
   },
   {
      id: '_62Copy',
      type: 'image',
      rect: ['0px','0px','161px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_62.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${__62Copy}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "background-position", [-161,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '0px'],
            ["style", "width", '161px']
         ],
         "${__62}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "left", '0px'],
            ["style", "background-position", [-161,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '161px']
         ],
         "${symbolSelector}": [
            ["style", "height", '35px'],
            ["style", "width", '161px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 12000,
         autoPlay: true,
         labels: {
            "loop": 4000
         },
         timeline: [
            { id: "eid166", tween: [ "style", "${__62}", "background-position", [161,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-161,0]}], position: 0, duration: 8000 },
            { id: "eid167", tween: [ "style", "${__62Copy}", "background-position", [0,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-161,0]}], position: 4000, duration: 4000 },
            { id: "eid168", tween: [ "style", "${__62Copy}", "background-position", [161,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [0,0]}], position: 8000, duration: 4000 }         ]
      }
   }
},
"Symbol_7": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: '_7',
      type: 'image',
      rect: ['0px','0px','161px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_72.png','0px','0px']
   },
   {
      id: '_7Copy',
      type: 'image',
      rect: ['0px','0px','161px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_72.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${__7}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "left", '0px'],
            ["style", "background-position", [-161,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '161px']
         ],
         "${__7Copy}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "background-position", [-161,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '0px'],
            ["style", "width", '161px']
         ],
         "${symbolSelector}": [
            ["style", "height", '35px'],
            ["style", "width", '161px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 12000,
         autoPlay: true,
         labels: {
            "loop": 4000
         },
         timeline: [
            { id: "eid172", tween: [ "style", "${__7}", "background-position", [161,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-161,0]}], position: 0, duration: 8000 },
            { id: "eid190", tween: [ "style", "${__7Copy}", "background-position", [-0.012386,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-161,0]}], position: 4000, duration: 4000 },
            { id: "eid192", tween: [ "style", "${__7Copy}", "background-position", [161,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-0.012386,0]}], position: 8000, duration: 4000 }         ]
      }
   }
},
"Symbol_8": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: '_85',
      type: 'image',
      rect: ['0px','0px','161px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_85.png','0px','0px']
   },
   {
      id: '_85Copy',
      type: 'image',
      rect: ['0px','0px','161px','35px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/152/_85.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${__85Copy}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "background-position", [-161,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '0px'],
            ["style", "width", '161px']
         ],
         "${__85}": [
            ["style", "top", '0px'],
            ["style", "height", '35px'],
            ["style", "left", '0px'],
            ["style", "background-position", [-161,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '161px']
         ],
         "${symbolSelector}": [
            ["style", "height", '35px'],
            ["style", "width", '161px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 12000,
         autoPlay: true,
         labels: {
            "loop": 4000
         },
         timeline: [
            { id: "eid182", tween: [ "style", "${__85Copy}", "background-position", [0,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-161,0]}], position: 4000, duration: 4000 },
            { id: "eid191", tween: [ "style", "${__85Copy}", "background-position", [161,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [0,0]}], position: 8000, duration: 4000 },
            { id: "eid181", tween: [ "style", "${__85}", "background-position", [161,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-161,0]}], position: 0, duration: 8000 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-31889407");
