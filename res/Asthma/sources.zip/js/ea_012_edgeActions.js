/***********************
* Adobe Edge Animate Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge Animate
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes
var countSlide1 = 0;
var countSlide2 = 0;
var countSlide3 = 0;

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      

      

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 7500, function(sym, e) {
         countSlide2 = 0;
         countSlide3 = 0;

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 8000, function(sym, e) {
         countSlide2 = countSlide2 + 1;

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 12412, function(sym, e) {
         sym.stop();
         if( countSlide2 < 1 ) {
         	sym.play('loop_2');
         } else {
         	var inhaler = sym.$( "inhaler" );
         	inhaler.addClass('slide3');
         	sym.play('slide_3');
         }

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 13688, function(sym, e) {
         countSlide3 = countSlide3+1;
         
         var inhaler = sym.$( "inhaler" );
         inhaler.addClass('slide3');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 19998, function(sym, e) {
         if( countSlide3 < 1000 ) {
         	sym.play('loop_3');
         } else {
         	var inhaler = sym.$( "inhaler" );
         	inhaler.removeClass('slide3');
         	sym.play('run_3-2');
         };

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 0, function(sym, e) {
         sym.stop();
         // play the timeline from the given position (ms or label)
         sym.play('run_start');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 21156, function(sym, e) {
         sym.stop();
         
         countSlide2 = 0;
         countSlide3 = 0;
         
         sym.play('start');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 22500, function(sym, e) {
         sym.stop();
         
         countSlide1 = 0;
         countSlide2 = 0;
         countSlide3 = 0;
         
         sym.play('start');

      });
      //Edge binding end

      Symbol.bindSymbolAction(compId, symbolName, "creationComplete", function(sym, e) {
         var inhaler = sym.$( "inhaler" );
         var dropped = sym.$( "dropped" );
         
         inhaler.addClass("ui-widget-content");
         
         yepnope({
         	load: "js/script.js",
         	callback: function() {
         		inhaler.draggable({
         			containment: $("#Stage"),
         			revert: "invalid", 
         			scroll: false 
         		});
         		dropped.droppable({
                     drop: function( event, ui ) {
                         inhaler.animate({
         							left: "70px",
         							top: "130px"
                         }, 200, 
                         function() {
         							sym.stop();
         							countSlide1 = 0;
         							countSlide2 = 0;
         							countSlide3 = 0;
         							if(inhaler.hasClass('slide3')) {
         								inhaler.removeClass('slide3')
         								sym.play('slide_1');
         							} else if(inhaler.hasClass('slide1')) {
         											countSlide1 = 0;
         											sym.play('loop_1');
         									} else {
         											sym.play('run_2-1');
         									};
         							inhaler.animate({
         								left: "70px",
         								top: "130px"
         								}, 1500
         							);
         							inhaler.animate({
         								left: "870px",
         								top: "182px"
         								}, 600
         							);
                         });
         				}
         		});
         	}
         });

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 6000, function(sym, e) {
         sym.stop();
         
         if( countSlide1 < 1 ) {
         	sym.play('loop_1');
         } else {
         	var inhaler = sym.$( "inhaler" );
         	inhaler.removeClass('slide1');
         	sym.play('slide_11');
         }

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 23665, function(sym, e) {
         sym.stop();
         
         countSlide1 = 0;
         countSlide2 = 0;
         countSlide3 = 0;
         
         sym.play('loop_1');

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1000, function(sym, e) {
         countSlide1 = countSlide1 + 1;
         
         var inhaler = sym.$( "inhaler" );
         inhaler.addClass('slide1');

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

})(jQuery, AdobeEdge, "EDGE-293129185");