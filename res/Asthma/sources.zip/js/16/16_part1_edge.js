/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/16/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Rectangle',
            type:'rect',
            rect:['160px','auto','60px','48px','auto','12px'],
            fill:["rgba(104,104,103,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy',
            type:'rect',
            rect:['240px','auto','60px','151px','auto','12px'],
            fill:["rgba(244,142,108,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy2',
            type:'rect',
            rect:['320px','auto','60px','284px','auto','12px'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy3',
            type:'rect',
            rect:['480px','auto','60px','32px','auto','12px'],
            fill:["rgba(104,104,103,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy4',
            type:'rect',
            rect:['560px','auto','60px','133px','auto','12px'],
            fill:["rgba(244,142,108,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy5',
            type:'rect',
            rect:['640px','auto','60px','296px','auto','12px'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'grid',
            type:'image',
            rect:['0','0','940px','341px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"grid.png",'0px','0px']
         },
         {
            id:'_1',
            type:'image',
            rect:['240px','33px','460px','183px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"_1.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_RectangleCopy3}": [
            ["style", "top", 'auto'],
            ["style", "bottom", '12px'],
            ["style", "height", '0px'],
            ["style", "left", '480px'],
            ["color", "background-color", 'rgba(104,104,103,1.00)']
         ],
         "${_RectangleCopy4}": [
            ["style", "top", 'auto'],
            ["style", "bottom", '12px'],
            ["style", "height", '0px'],
            ["style", "left", '560px'],
            ["color", "background-color", 'rgba(244,142,108,1.00)']
         ],
         "${__1}": [
            ["style", "top", '33px'],
            ["style", "height", '183px'],
            ["style", "opacity", '0'],
            ["style", "left", '240px'],
            ["style", "width", '460px']
         ],
         "${_RectangleCopy}": [
            ["color", "background-color", 'rgba(244,142,108,1.00)'],
            ["style", "bottom", '12px'],
            ["style", "height", '0px'],
            ["style", "left", '240px'],
            ["style", "top", 'auto']
         ],
         "${_RectangleCopy2}": [
            ["style", "top", 'auto'],
            ["style", "bottom", '12px'],
            ["style", "height", '0px'],
            ["style", "left", '320px'],
            ["color", "background-color", 'rgba(218,35,24,1.00)']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,0.00)'],
            ["style", "width", '940px'],
            ["style", "height", '341px'],
            ["style", "overflow", 'hidden']
         ],
         "${_Rectangle}": [
            ["color", "background-color", 'rgba(104,104,103,1.00)'],
            ["style", "bottom", '12px'],
            ["style", "height", '0px'],
            ["style", "left", '160px'],
            ["style", "top", 'auto']
         ],
         "${_grid}": [
            ["style", "height", '341px'],
            ["style", "width", '940px']
         ],
         "${_RectangleCopy5}": [
            ["style", "top", 'auto'],
            ["style", "bottom", '12px'],
            ["style", "height", '0px'],
            ["style", "left", '640px'],
            ["color", "background-color", 'rgba(218,35,24,1.00)']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 665,
         autoPlay: true,
         timeline: [
            { id: "eid6", tween: [ "style", "${_RectangleCopy}", "height", '151px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid12", tween: [ "style", "${_RectangleCopy4}", "height", '133px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid14", tween: [ "style", "${_RectangleCopy5}", "height", '296px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid4", tween: [ "style", "${_Rectangle}", "height", '48px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid10", tween: [ "style", "${_RectangleCopy3}", "height", '32px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid22", tween: [ "style", "${__1}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165, easing: "easeOutQuad" },
            { id: "eid8", tween: [ "style", "${_RectangleCopy2}", "height", '284px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-3035272");
