/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/new2/';

var fonts = {};
   fonts['Helvetica']='';


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'line',
            type:'image',
            rect:['0','3px','940px','308px','auto','auto'],
            fill:["rgba(49,49,49,0)",im+"line.png",'0px','0px']
         },
         {
            id:'Rectangle',
            type:'rect',
            rect:['160px','auto','60px','239px','auto','10px'],
            fill:["rgba(104,104,103,1.00)"],
            stroke:[0,"rgba(49,49,49,1)","none"]
         },
         {
            id:'RectangleCopy',
            type:'rect',
            rect:['240px','auto','60px','216px','auto','10px'],
            fill:["rgba(104,104,103,1.00)"],
            stroke:[0,"rgba(49,49,49,1)","none"]
         },
         {
            id:'RectangleCopy2',
            type:'rect',
            rect:['320px','auto','60px','108px','auto','10px'],
            fill:["rgba(104,104,103,1.00)"],
            stroke:[0,"rgba(49,49,49,1)","none"]
         },
         {
            id:'RectangleCopy3',
            type:'rect',
            rect:['400px','auto','60px','281px','auto','10px'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(49,49,49,1)","none"]
         },
         {
            id:'RectangleCopy4',
            type:'rect',
            rect:['480px','auto','60px','264px','auto','10px'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(49,49,49,1)","none"]
         },
         {
            id:'RectangleCopy5',
            type:'rect',
            rect:['560px','auto','60px','233px','auto','10px'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(49,49,49,1)","none"]
         },
         {
            id:'TextCopy',
            type:'text',
            rect:['345px','238px','auto','10px','auto','auto'],
            text:"**",
            font:['Helvetica',18,"rgba(255,255,255,1.00)","normal","none",""]
         },
         {
            id:'Text',
            type:'text',
            rect:['307px','259px','auto','10px','auto','auto'],
            text:"***",
            font:['Helvetica',18,"rgba(255,255,255,1.00)","normal","none",""]
         },
         {
            id:'TextCopy3',
            type:'text',
            rect:['588px','121px','auto','10px','auto','auto'],
            text:"***",
            font:['Helvetica',16,"rgba(255,255,255,1.00)","normal","none",""]
         },
         {
            id:'TextCopy2',
            type:'text',
            rect:['583px','91px','auto','10px','auto','auto'],
            text:"*",
            font:['Helvetica',18,"rgba(255,255,255,1.00)","normal","none",""]
         },
         {
            id:'TextCopy4',
            type:'text',
            rect:['342px','218px','auto','10px','auto','auto'],
            text:"*",
            font:['Helvetica',18,"rgba(255,255,255,1.00)","normal","none",""]
         },
/*   {
            id:'s2',
            type:'image',
            rect:['343px','72px','15px','116px','auto','auto'],
            fill:["rgba(49,49,49,0)",im+"s2.png",'0px','0px']
         },
*/
         {
            id:'s2Copy',
            type:'image',
            rect:['264px','-41px','15px','116px','auto','auto'],
            clip:['rect(57px 15px 116px 0px)'],
            fill:["rgba(49,49,49,0)",im+"s2.png",'0px','0px']
         },
   /*       {
            id:'s1',
            type:'image',
            rect:['584px','28px','15px','34px','auto','auto'],
            fill:["rgba(49,49,49,0)",im+"s1.png",'0px','0px']
         },
*/
         {
            id:'s1Copy',
            type:'image',
            rect:['504px','-3px','15px','34px','auto','auto'],
            clip:['rect(13px 15px 34px 0px)'],
            fill:["rgba(49,49,49,0)",im+"s1.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_RectangleCopy4}": [
            ["color", "background-color", 'rgba(218,35,24,1)'],
            ["style", "bottom", '10px'],
            ["style", "height", '0px'],
            ["style", "top", 'auto'],
            ["style", "left", '480px'],
            ["style", "width", '60px']
         ],
         "${_line}": [
            ["style", "top", '3px'],
            ["style", "height", '308px'],
            ["style", "width", '940px']
         ],
         "${_TextCopy2}": [
            ["style", "top", '91px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "font-family", 'Helvetica'],
            ["style", "height", '10px'],
            ["style", "opacity", '0'],
            ["style", "left", '586px'],
            ["style", "font-size", '18px']
         ],
         "${_Rectangle}": [
            ["style", "top", 'auto'],
            ["style", "bottom", '10px'],
            ["style", "height", '0px'],
            ["color", "background-color", 'rgba(104,104,103,1)'],
            ["style", "left", '160px'],
            ["style", "width", '60px']
         ],
         "${_s1}": [
            ["style", "top", '15px'],
            ["style", "height", '52px'],
            ["style", "opacity", '0'],
            ["style", "left", '584px'],
            ["style", "width", '15px']
         ],
         "${_TextCopy4}": [
            ["style", "top", '218px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "font-family", 'Helvetica'],
            ["style", "height", '10px'],
            ["style", "opacity", '0'],
            ["style", "left", '348px'],
            ["style", "font-size", '18px']
         ],
         "${_TextCopy3}": [
            ["style", "top", '111px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "font-family", 'Helvetica'],
            ["style", "height", '10px'],
            ["style", "opacity", '0'],
            ["style", "left", '580px'],
            ["style", "font-size", '18px']
         ],
         "${_s2}": [
            ["style", "top", '42px'],
            ["style", "height", '146px'],
            ["style", "opacity", '0'],
            ["style", "left", '343px'],
            ["style", "width", '15px']
         ],
         "${_RectangleCopy3}": [
            ["color", "background-color", 'rgba(218,35,24,1)'],
            ["style", "bottom", '10px'],
            ["style", "height", '0px'],
            ["style", "top", 'auto'],
            ["style", "left", '400px'],
            ["style", "width", '60px']
         ],
         "${_s2Copy}": [
            ["style", "top", '-35px'],
            ["style", "clip", [77,15,116,0], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ],
            ["style", "height", '116px'],
            ["style", "opacity", '0'],
            ["style", "left", '264px'],
            ["style", "width", '15px']
         ],
         "${_s1Copy}": [
            ["style", "top", '0px'],
            ["style", "clip", [13,15,34,0], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ],
            ["style", "height", '34px'],
            ["style", "opacity", '0'],
            ["style", "left", '504px'],
            ["style", "width", '15px']
         ],
         "${_TextCopy5}": [
            ["style", "top", '116px'],
            ["color", "color", 'rgba(255,255,255,1)'],
            ["style", "font-family", 'Helvetica'],
            ["style", "height", '10px'],
            ["style", "opacity", '1'],
            ["style", "left", '588px'],
            ["style", "font-size", '18px']
         ],
         "${_Text}": [
            ["style", "top", '259px'],
            ["color", "color", 'rgba(255,255,255,1)'],
            ["style", "font-family", 'Helvetica'],
            ["style", "height", '10px'],
            ["style", "opacity", '0'],
            ["style", "left", '342px'],
            ["style", "font-size", '18px']
         ],
         "${_RectangleCopy5}": [
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["style", "bottom", '10px'],
            ["style", "height", '0px'],
            ["style", "top", 'auto'],
            ["style", "left", '560px'],
            ["style", "width", '60px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,0.00)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '316px'],
            ["style", "width", '940px']
         ],
         "${_RectangleCopy}": [
            ["color", "background-color", 'rgba(104,104,103,1)'],
            ["style", "bottom", '10px'],
            ["style", "height", '0px'],
            ["style", "top", 'auto'],
            ["style", "left", '240px'],
            ["style", "width", '60px']
         ],
         "${_TextCopy}": [
            ["style", "top", '238px'],
            ["color", "color", 'rgba(255,255,255,1)'],
            ["style", "font-family", 'Helvetica'],
            ["style", "height", '10px'],
            ["style", "opacity", '0'],
            ["style", "left", '345px'],
            ["style", "font-size", '18px']
         ],
         "${_RectangleCopy2}": [
            ["color", "background-color", 'rgba(104,104,103,1)'],
            ["style", "bottom", '10px'],
            ["style", "height", '0px'],
            ["style", "top", 'auto'],
            ["style", "left", '320px'],
            ["style", "width", '60px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 665,
         autoPlay: true,
         timeline: [
            { id: "eid16", tween: [ "style", "${_s2Copy}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165 },
            { id: "eid11", tween: [ "style", "${_s2}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165 },
            { id: "eid5", tween: [ "style", "${_RectangleCopy4}", "height", '264px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid14", tween: [ "style", "${_s1Copy}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165 },
            { id: "eid13", tween: [ "style", "${_TextCopy4}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165 },
            { id: "eid6", tween: [ "style", "${_RectangleCopy5}", "height", '234px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid1", tween: [ "style", "${_Rectangle}", "height", '239px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid12", tween: [ "style", "${_s1}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165 },
            { id: "eid2", tween: [ "style", "${_RectangleCopy}", "height", '216px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid3", tween: [ "style", "${_RectangleCopy2}", "height", '108px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid4", tween: [ "style", "${_RectangleCopy3}", "height", '281px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid7", tween: [ "style", "${_TextCopy}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165 },
            { id: "eid8", tween: [ "style", "${_Text}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165 },
            { id: "eid10", tween: [ "style", "${_TextCopy3}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165 },
            { id: "eid9", tween: [ "style", "${_TextCopy2}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-875129");
