/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/new2/';

var fonts = {};
   fonts['Helvetica']='';


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Rectangle',
            type:'rect',
            rect:['160px','auto','60px','239px','auto','22px'],
            fill:["rgba(104,104,103,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy',
            type:'rect',
            rect:['240px','auto','60px','216px','auto','22px'],
            fill:["rgba(104,104,103,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy2',
            type:'rect',
            rect:['320px','auto','60px','108px','auto','22px'],
            fill:["rgba(104,104,103,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy3',
            type:'rect',
            rect:['400px','auto','60px','281px','auto','22px'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy4',
            type:'rect',
            rect:['480px','auto','60px','264px','auto','22px'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy5',
            type:'rect',
            rect:['560px','auto','60px','233px','auto','22px'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'Text',
            type:'text',
            rect:['344px','212px','auto','10px','auto','auto'],
            text:"**",
            font:['Helvetica',14,"rgba(255,255,255,1.00)","normal","none",""]
         },
         {
            id:'TextCopy',
            type:'text',
            rect:['347px','233px','auto','10px','auto','auto'],
            text:"*",
            font:['Helvetica',14,"rgba(255,255,255,1.00)","normal","none",""]
         },
         {
            id:'TextCopy2',
            type:'text',
            rect:['588px','116px','auto','10px','auto','auto'],
            text:"*",
            font:['Helvetica',16,"rgba(255,255,255,1.00)","normal","none",""]
         },
         {
            id:'TextCopy3',
            type:'text',
            rect:['583px','86px','auto','10px','auto','auto'],
            text:"***",
            font:['Helvetica',14,"rgba(255,255,255,1.00)","normal","none",""]
         },
         {
            id:'shkala',
            type:'image',
            rect:['0','0','940px','325px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"shkala.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_TextCopy3}": [
            ["style", "top", '86px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "font-family", 'Helvetica'],
            ["style", "height", '10px'],
            ["style", "opacity", '0'],
            ["style", "left", '583px'],
            ["style", "font-size", '14px']
         ],
         "${_RectangleCopy3}": [
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["style", "bottom", '22px'],
            ["style", "height", '0px'],
            ["style", "top", 'auto'],
            ["style", "left", '400px'],
            ["style", "width", '60px']
         ],
         "${_RectangleCopy2}": [
            ["color", "background-color", 'rgba(104,104,103,1.00)'],
            ["style", "bottom", '22px'],
            ["style", "height", '0px'],
            ["style", "top", 'auto'],
            ["style", "left", '320px'],
            ["style", "width", '60px']
         ],
         "${_RectangleCopy5}": [
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["style", "bottom", '22px'],
            ["style", "height", '0px'],
            ["style", "top", 'auto'],
            ["style", "left", '560px'],
            ["style", "width", '60px']
         ],
         "${_Text}": [
            ["style", "top", '212px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "font-family", 'Helvetica'],
            ["style", "height", '10px'],
            ["style", "opacity", '0'],
            ["style", "left", '344px'],
            ["style", "font-size", '14px']
         ],
         "${_shkala}": [
            ["style", "height", '325px'],
            ["style", "width", '940px']
         ],
         "${_RectangleCopy}": [
            ["color", "background-color", 'rgba(104,104,103,1.00)'],
            ["style", "bottom", '22px'],
            ["style", "height", '0px'],
            ["style", "top", 'auto'],
            ["style", "left", '240px'],
            ["style", "width", '60px']
         ],
         "${_TextCopy2}": [
            ["style", "top", '116px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "font-family", 'Helvetica'],
            ["style", "height", '10px'],
            ["style", "opacity", '0'],
            ["style", "left", '588px'],
            ["style", "font-size", '16px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,0.00)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '325px'],
            ["style", "width", '940px']
         ],
         "${_Rectangle}": [
            ["style", "top", 'auto'],
            ["style", "bottom", '22px'],
            ["style", "height", '0px'],
            ["color", "background-color", 'rgba(104,104,103,1.00)'],
            ["style", "left", '160px'],
            ["style", "width", '60px']
         ],
         "${_TextCopy}": [
            ["style", "top", '233px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["style", "font-family", 'Helvetica'],
            ["style", "height", '10px'],
            ["style", "opacity", '0'],
            ["style", "left", '347px'],
            ["style", "font-size", '14px']
         ],
         "${_RectangleCopy4}": [
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["style", "bottom", '22px'],
            ["style", "height", '0px'],
            ["style", "top", 'auto'],
            ["style", "left", '480px'],
            ["style", "width", '60px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 665,
         autoPlay: true,
         timeline: [
            { id: "eid27", tween: [ "style", "${_RectangleCopy}", "height", '216px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid18", tween: [ "style", "${_RectangleCopy4}", "height", '264px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid34", tween: [ "style", "${_RectangleCopy5}", "height", '234px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid33", tween: [ "style", "${_Rectangle}", "height", '239px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid46", tween: [ "style", "${_TextCopy3}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165 },
            { id: "eid21", tween: [ "style", "${_RectangleCopy3}", "height", '281px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid44", tween: [ "style", "${_TextCopy}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165 },
            { id: "eid24", tween: [ "style", "${_RectangleCopy2}", "height", '108px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid43", tween: [ "style", "${_Text}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165 },
            { id: "eid45", tween: [ "style", "${_TextCopy2}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-15144590");
