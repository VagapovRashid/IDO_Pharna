$(document).ready(function(){

$('.big_circl').click(function(){
     if($('.open').css('display') != 'block'){
        $('.open').fadeIn();
    } 
});
$('.open').click(function(){
        $('.open').fadeOut();
});

});
