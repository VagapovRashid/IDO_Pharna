

$('.wrap_activation > div > div').click(function(){
   
if($(this).hasClass('act')){
    
} else {
    $('.wrap_activation > div > div').each(function(){
       $(this).removeClass('act'); 
    });
    $(this).addClass('act');
    
    $('.slider').each(function(){
       if(!($(this).hasClass('none'))){
            $(this).addClass('none');
       } 
    });
    
    $('#slider' + $(this).attr('data-slide')).removeClass('none');
}  
    
});

$(function() {

   /*-add_TOP_BOX-*/
    var initialValue = 0;
    var sliderHandleValue = function (event, ui) {
        var curValue = ui.value || initialValue;

        if(curValue > 9){
            var value = '<div class="tooltip2">' + curValue + '</div>';
        }else{
            var value = '<div class="tooltip">' + curValue + '</div>';
        }

        $('.ui-slider-handle').html(value);
    };

    var sliderTooltip = function (event, ui) {
        var curValue = ui.value || initialValue;

        if(curValue > 9){
            var tooltip = '<div class="tooltip2">' + curValue + '<div class="tooltip-inner">' + curValue + '</div></div>';
        }else{
            var tooltip = '<div class="tooltip">' + curValue + '<div class="tooltip-inner2">' + curValue + '</div></div>';
        }
        $('.ui-slider-handle').html(tooltip);
    };

    var tooltip = $('<div id="tooltip" />');
   
   
    $( ".slider" ).each(function(){
        
       $(this).slider({
          animate: false,
          range: "min",
          value: 0,
          min: 1,
          max: 100,
          step: 1,
		  create: function (event, ui){
			var value = $(this).slider("option", "value");
			$(this).find(".ui-slider-handle").text(value);
			$(this).find(".ui-slider-handle").prepend(tooltip);
			$("#tooltip").text(value);
			document.getElementById('recomend').value = value;
		  },
		  slide: function( event, ui ) {
			$(this).find(".ui-slider-handle").text(ui.value);
			$(this).find(".ui-slider-handle").prepend(tooltip);
			$("#tooltip").text(ui.value);
		  },
		  start: function( event, ui ) {
			$("#tooltip").css({'display': 'block'});
		  },
		  stop: function( event, ui ) {
			$("#tooltip").css({'display': 'none'});
			document.getElementById('recomend').value = ui.value;
		  }
       });
    
    });

  });