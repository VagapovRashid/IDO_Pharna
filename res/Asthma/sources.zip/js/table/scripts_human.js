$(document).ready(function(){

var i = 0;
    $('.buttons > div').click(function(){
        $('.human_img').removeClass().addClass('human_img lh' + $(this).attr('data-id'));
        $('.treat').removeClass().addClass('treat lr' + $(this).attr('data-id'));
        
        if($(this).attr('data-id') == 5){
            $('.footnote').css('display', 'block');
        } else {
            $('.footnote').css('display', 'none');
        }
        
        
        if($(this).attr('data-id')>1){
            $('.wr_hum_but').addClass('ml');
            if($('.treat').css('display') != 'block'){
               $('.treat').delay(500).slideDown(); 
            }
        } else {
            $('.wr_hum_but').removeClass('ml');
            if($('.treat').css('display') == 'block'){
               $('.treat').slideUp(); 
            }
        }
        
         
        $('.treat .head').css('margin-bottom', 60);
        /*-Remove add content and hide block therapy-*/
        $('.therapy .cont .add_t').each(function(){
           $('.treat').append( '<div class="recip  ' + $(this).attr('data-step') + '" data-step="' + $(this).attr('data-step') + '">' + $(this).text() + '</div>');
           $(this).remove(); 
        });
        $('.therapy .cont .list_head').each(function(){
        $('.treat #'+ $(this).attr('data-num')).slideDown().css('display', '');
        $('.treat #'+ $(this).attr('data-num')).children('p').attr('data-add', 'yes');
        $(this).remove();        
     });
        
        $('.therapy').slideUp();
        
        
        $('.buttons > div').each(function(){
           $(this).removeClass(); 
        });
        
        $(this).addClass('active')
    });
    
      /**********add to cart***********/
    
    function addToCart( block, sec){
        var bascket = $('.therapy .cont');
        var pClone = block.clone();                          
        pClone.delay(sec).appendTo('body').css({position: 'absolute', zIndex: 100, top: block.offset().top, left: block.offset().left}).animate({
            top: bascket.offset().top, 
            left: bascket.offset().left,
            opacity: '0.3',
            height: bascket.height(), 
            width: bascket.width(), 
        }, 900, function(){
            pClone.remove();
        });
        return false;
    }
    
    /********add to cart end*********/ 
    
    
    $('.treat ').on("click", ".recip", function(e){
              
        if($('.therapy').css('display') != 'block'){
               $('.therapy').slideDown(); 
               
               $('.therapy .cont').delay(500).prepend( '<p class="add_t last" data-step="' + $(this).attr('data-step') + '">' + $(this).text() + '</p>');
          
                addToCart($(this), 600);
            } else {
            
            addToCart($(this), 0);
        
            $('.therapy .cont').delay(1000).prepend( '<p class="add_t" data-step="' + $(this).attr('data-step') + '">' + $(this).text() + '</p>');
          
        }
        
        $(this).remove();
    });
    
    $('.treat .list').on("click", "p", function(e){
        
        if($(this).attr('data-add') != 'none'){
           
             $(this).next().slideDown();
        }
        $(this).attr('data-add', 'none');
        
        
        });
    
    $('.treat .list').on("click", "li", function(e){
        
         $('.therapy').slideDown(); 
         
        $('.therapy .cont').prepend( '<p class="list_head lh'+ $(this).parent().parent().attr('data-num') +'" data-step="' + $(this).parent().parent().attr('data-step') + '" data-num="'+ $(this).parent().parent().attr('data-num') +'">' + $(this).parent().parent().children('p').text() + $(this).text() + '</p>');
           
        $(this).parent().parent().slideUp();
        $('.treat .list ul').slideUp();
        $('.treat .head').css('margin-bottom', 0);
        
        addToCart($(this), 0);
    });
    
     $('.therapy .cont ').on("click", ".list_head", function(e){
        $('.treat #'+ $(this).attr('data-num')).slideDown().css('display', '');
        $('.treat #'+ $(this).attr('data-num')).children('p').attr('data-add', 'yes');
        $('.treat .head').css('margin-bottom', '60px');
        $(this).remove();        
     });
    
    $('.therapy .cont ').on("click", ".add_t", function(e){
        $('.treat').append( '<div class="recip  ' + $(this).attr('data-step') + '" data-step="' + $(this).attr('data-step') + '">' + $(this).text() + '</div>');
        $(this).remove();
    });

});