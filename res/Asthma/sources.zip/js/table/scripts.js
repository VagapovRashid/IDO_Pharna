$(document).ready(function(){

var i = 0;
    $('.buttons > div').click(function(){
        $('.human_img').removeClass().addClass('human_img lh' + $(this).attr('data-id'));
        $('.therapy').removeClass().addClass('therapy lt' + $(this).attr('data-id'));
        $('.treat').removeClass().addClass('treat lr' + $(this).attr('data-id'));
        
        $('.buttons > div').each(function(){
           $(this).removeClass(); 
        });
        
        $(this).addClass('active')
    });
    
    $('.treat ').on("click", ".recip", function(e){
        $('.therapy .cont').prepend( '<p class="add_t" data-step="' + $(this).attr('data-step') + '">' + $(this).text() + '</p>');
        $(this).remove();
    });
    
    $('.treat .list').on("click", "p", function(e){
        
        if($(this).attr('data-add') != 'none'){
            $('.therapy .cont').prepend( '<p class="list_head lh'+ $(this).parent().attr('data-num') +'" data-step="' + $(this).parent().attr('data-step') + '" data-num="'+ $(this).parent().attr('data-num') +'">' + $(this).text() + '</p>');
            $(this).next().slideDown();
        }
        $(this).attr('data-add', 'none');
        });
    
    $('.treat .list').on("click", "li", function(e){
        $('.therapy .cont .lh'+ $(this).parent().parent().attr('data-num') +'').text($(this).parent().parent().children('p').text() + $(this).text());
        $(this).parent().parent().slideUp();
        $('.treat .list ul').slideUp();
    });
    
     $('.therapy .cont ').on("click", ".list_head", function(e){
        $('.treat #'+ $(this).attr('data-num')).slideDown().css('display', '');
        $('.treat #'+ $(this).attr('data-num')).children('p').attr('data-add', 'yes');
        $(this).remove();        
     });
    
    $('.therapy .cont ').on("click", ".add_t", function(e){
        $('.treat').append( '<div class="recip  ' + $(this).attr('data-step') + '" data-step="' + $(this).attr('data-step') + '">' + $(this).text() + '</div>');
        $(this).remove();
    });

});