/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/154/';

var fonts = {};
   fonts['helveticaneue-condensedbold']='';


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'slider',
            type:'rect',
            rect:['478px','396px','380px','1px','auto','auto'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'Rectangle3',
            type:'rect',
            rect:['478px','345px','380px','100px','auto','auto'],
            fill:["rgba(218,35,24,0.00)"],
            stroke:[0,"rgb(0, 0, 0)","none"]
         },
         {
            id:'line',
            type:'rect',
            rect:['0px','326px','492px','1px','auto','auto'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'chelovek',
            type:'image',
            rect:['8px','-50px','439px','543px','auto','auto'],
            clip:['rect(50px 439px 500px 0px)'],
            fill:["rgba(0,0,0,0)",im+"chelovek.png",'0px','0px']
         },
         {
            id:'Group2',
            type:'group',
            rect:['459','361px','100','100','auto','auto'],
            c:[
            {
               id:'time_1',
               type:'image',
               rect:['0px','0px','100px','100px','auto','auto'],
               fill:["rgba(0,0,0,0)",im+"time_1.png",'0px','0px']
            },
            {
               id:'sigment',
               type:'image',
               rect:['auto','auto','49px','50px','1px','50px'],
               fill:["rgba(0,0,0,0)",im+"sigment.png",'0px','0px']
            },
            {
               id:'sigmentCopy',
               type:'image',
               rect:['50px','1px','49px','50px','auto','auto'],
               fill:["rgba(0,0,0,0)",im+"sigment.png",'0px','0px']
            },
            {
               id:'sigmentCopy2',
               type:'image',
               rect:['50px','1px','49px','50px','auto','auto'],
               fill:["rgba(0,0,0,0)",im+"sigment.png",'0px','0px']
            },
            {
               id:'sigmentCopy3',
               type:'image',
               rect:['50px','1px','49px','50px','auto','auto'],
               fill:["rgba(0,0,0,0)",im+"sigment.png",'0px','0px']
            },
            {
               id:'sigment_mask',
               type:'image',
               rect:['0px','0px','50px','50px','auto','auto'],
               fill:["rgba(0,0,0,0)",im+"sigment_mask.png",'0px','0px']
            },
            {
               id:'time',
               type:'rect',
               rect:['47px','7px','5px','44px','auto','auto'],
               borderRadius:["10px","10px","10px","10px"],
               fill:["rgba(218,35,24,1.00)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            },
            {
               id:'timeCopy',
               type:'rect',
               rect:['auto','auto','5px','44px','48px','49px'],
               borderRadius:["10px","10px","10px","10px"],
               fill:["rgba(218,35,24,1.00)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            }]
         },
         {
            id:'legkie',
            type:'image',
            rect:['117px','138px','222px','178px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"legkie.png",'0px','0px']
         },
         {
            id:'ingalaytor',
            type:'image',
            rect:['620px','133px','100px','146px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"ingalaytor.png",'0px','0px']
         },
         {
            id:'axis',
            type:'rect',
            rect:['518px','326px','419px','1px','auto','auto'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'d7',
            type:'rect',
            rect:['518px','291px','20px','1px','auto','auto'],
            fill:["rgba(49,49,49,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'d6',
            type:'rect',
            rect:['518px','258px','20px','1px','auto','auto'],
            fill:["rgba(49,49,49,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'d5',
            type:'rect',
            rect:['518px','226px','20px','1px','auto','auto'],
            fill:["rgba(49,49,49,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'d4',
            type:'rect',
            rect:['518px','193px','20px','1px','auto','auto'],
            fill:["rgba(49,49,49,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'d3',
            type:'rect',
            rect:['518px','159px','20px','1px','auto','auto'],
            fill:["rgba(49,49,49,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'d2',
            type:'rect',
            rect:['518px','126px','20px','1px','auto','auto'],
            fill:["rgba(49,49,49,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'d1',
            type:'rect',
            rect:['518px','93px','20px','1px','auto','auto'],
            fill:["rgba(49,49,49,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'d1Copy',
            type:'rect',
            rect:['518px','93px','20px','1px','auto','auto'],
            fill:["rgba(49,49,49,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'_12',
            type:'image',
            rect:['248px','195px','85px','165px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"_12.png",'0px','0px']
         },
         {
            id:'_22',
            type:'image',
            rect:['248px','195px','85px','165px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"_22.png",'0px','0px']
         },
         {
            id:'_32',
            type:'image',
            rect:['248px','195px','85px','165px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"_32.png",'0px','0px']
         },
         {
            id:'_42',
            type:'image',
            rect:['248px','195px','85px','165px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"_42.png",'0px','0px']
         },
         {
            id:'_12Copy',
            type:'image',
            rect:['122px','195px','85px','165px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"_12.png",'0px','0px'],
            transform:[[],[],[],['-1']]
         },
         {
            id:'_22Copy',
            type:'image',
            rect:['122px','195px','85px','165px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"_22.png",'0px','0px'],
            transform:[[],[],[],['-1']]
         },
         {
            id:'_32Copy',
            type:'image',
            rect:['122px','195px','85px','165px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"_32.png",'0px','0px'],
            transform:[[],[],[],['-1']]
         },
         {
            id:'_42Copy',
            type:'image',
            rect:['122px','195px','85px','165px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"_42.png",'0px','0px'],
            transform:[[],[],[],['-1']]
         },
         {
            id:'Text',
            type:'text',
            rect:['489px','86px','auto','auto','auto','auto'],
            text:"350",
            font:['Arial, Helvetica, sans-serif',12,"rgba(49,49,49,1.00)","normal","none",""]
         },
         {
            id:'TextCopy8',
            type:'text',
            rect:['489px','86px','auto','auto','auto','auto'],
            text:"400",
            font:['Arial, Helvetica, sans-serif',12,"rgba(49,49,49,1.00)","normal","none",""]
         },
         {
            id:'TextCopy',
            type:'text',
            rect:['489px','119px','auto','auto','auto','auto'],
            text:"300",
            font:['Arial, Helvetica, sans-serif',12,"rgba(49,49,49,1.00)","normal","none",""]
         },
         {
            id:'TextCopy2',
            type:'text',
            rect:['489px','152px','auto','auto','auto','auto'],
            text:"250",
            font:['Arial, Helvetica, sans-serif',12,"rgba(49,49,49,1.00)","normal","none",""]
         },
         {
            id:'TextCopy3',
            type:'text',
            rect:['489px','185px','auto','auto','auto','auto'],
            text:"200",
            font:['Arial, Helvetica, sans-serif',12,"rgba(49,49,49,1.00)","normal","none",""]
         },
         {
            id:'TextCopy4',
            type:'text',
            rect:['489px','218px','auto','auto','auto','auto'],
            text:"150",
            font:['Arial, Helvetica, sans-serif',12,"rgba(49,49,49,1.00)","normal","none",""]
         },
         {
            id:'TextCopy5',
            type:'text',
            rect:['489px','251px','auto','auto','auto','auto'],
            text:"100",
            font:['Arial, Helvetica, sans-serif',12,"rgba(49,49,49,1.00)","normal","none",""]
         },
         {
            id:'TextCopy6',
            type:'text',
            rect:['496px','284px','auto','auto','auto','auto'],
            text:"50",
            font:['Arial, Helvetica, sans-serif',12,"rgba(49,49,49,1.00)","normal","none",""]
         },
         {
            id:'TextCopy7',
            type:'text',
            rect:['503px','318px','auto','auto','auto','auto'],
            text:"0",
            font:['Arial, Helvetica, sans-serif',12,"rgba(49,49,49,1.00)","normal","none",""]
         },
         {
            id:'TextCopy9',
            type:'text',
            rect:['706px','337px','auto','auto','auto','auto'],
            text:"3ч",
            font:['Arial, Helvetica, sans-serif',12,"rgba(49,49,49,1.00)","normal","none",""]
         },
         {
            id:'TextCopy10',
            type:'text',
            rect:['706px','337px','auto','auto','auto','auto'],
            text:"6ч",
            font:['Arial, Helvetica, sans-serif',12,"rgba(49,49,49,1.00)","normal","none",""]
         },
         {
            id:'TextCopy11',
            type:'text',
            rect:['707px','337px','auto','auto','auto','auto'],
            text:"9ч",
            font:['Arial, Helvetica, sans-serif',12,"rgba(49,49,49,1.00)","normal","none",""]
         },
         {
            id:'TextCopy12',
            type:'text',
            rect:['822px','337px','auto','auto','auto','auto'],
            text:"24ч",
            font:['Arial, Helvetica, sans-serif',12,"rgba(49,49,49,1.00)","normal","none",""]
         },
         {
            id:'stolbik1',
            type:'rect',
            rect:['auto','auto','28px','119px','25.4%','216px'],
            fill:["rgba(255,255,255,1.00)"],
            stroke:[1,"rgba(218,35,24,1.00)","solid"]
         },
         {
            id:'stolbik2',
            type:'rect',
            rect:['auto','auto','60px','186px','16.8%','216px'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(218,35,24,1.00)","solid"]
         },
         {
            id:'stolbik5',
            type:'rect',
            rect:['auto','auto','28px','47px','20.1%','216px'],
            fill:["rgba(255,255,255,1.00)"],
            stroke:[1,"rgba(218,35,24,1.00)","solid"]
         },
         {
            id:'stolbik6',
            type:'rect',
            rect:['auto','auto','30px','230px','8.3%','216px'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(218,35,24,1.00)","solid"]
         },
         {
            id:'stolbik4',
            type:'rect',
            rect:['auto','auto','30px','206px','25.4%','216px'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(218,35,24,1.00)","solid"]
         },
         {
            id:'stolbik3',
            type:'rect',
            rect:['auto','auto','28px','74px','28.6%','216px'],
            fill:["rgba(255,255,255,1.00)"],
            stroke:[1,"rgba(218,35,24,1.00)","solid"]
         },
         {
            id:'stolbik8',
            type:'rect',
            rect:['auto','auto','30px','253px','34%','216px'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(218,35,24,1.00)","solid"]
         },
         {
            id:'stolbik7',
            type:'rect',
            rect:['auto','auto','28px','18px','37.1%','216px'],
            fill:["rgba(255,255,255,1.00)"],
            stroke:[1,"rgba(218,35,24,1.00)","solid"]
         },
         {
            id:'p2',
            type:'image',
            rect:['145px','458px','11px','11px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"p2.png",'0px','0px']
         },
         {
            id:'p1',
            type:'image',
            rect:['145px','500px','11px','11px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"p1.png",'0px','0px']
         },
         {
            id:'Text2',
            type:'text',
            rect:['159px','456px','auto','auto','auto','auto'],
            text:"Конъюгат дезциклесонида с жирными кислотами",
            align:"left",
            font:['helveticaneue-condensedbold',12,"rgba(255,255,255,1.00)","normal","none","normal"]
         },
         {
            id:'Text2Copy',
            type:'text',
            rect:['159px','497px','auto','auto','auto','auto'],
            text:"Дезциклесонид",
            align:"left",
            font:['helveticaneue-condensedbold',12,"rgba(255,255,255,1.00)","normal","none","normal"]
         },
         {
            id:'Group3',
            type:'group',
            rect:['652','201','30','12','auto','auto'],
            c:[
            {
               id:'Rectangle',
               type:'rect',
               rect:['15px','0px','1px','12px','auto','auto'],
               fill:["rgba(49,49,49,1.00)"],
               stroke:[0,"rgb(218, 35, 24)","solid"],
               transform:[]
            },
            {
               id:'Rectangle2',
               type:'rect',
               rect:['0px','0px','30px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            },
            {
               id:'Rectangle2Copy',
               type:'rect',
               rect:['0px','11px','30px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            }]
         },
         {
            id:'Group3Copy',
            type:'group',
            rect:['734px','201','30','12','auto','auto'],
            c:[
            {
               id:'RectangleCopy',
               type:'rect',
               rect:['15px','-8px','1px','27px','auto','auto'],
               fill:["rgba(49,49,49,1.00)"],
               stroke:[0,"rgb(218, 35, 24)","solid"],
               transform:[]
            },
            {
               id:'Rectangle2Copy3',
               type:'rect',
               rect:['0px','-9px','30px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            },
            {
               id:'Rectangle2Copy2',
               type:'rect',
               rect:['0px','19px','30px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            }]
         },
         {
            id:'Group3Copy3',
            type:'group',
            rect:['558px','201','30','12','auto','auto'],
            transform:[],
            c:[
            {
               id:'RectangleCopy3',
               type:'rect',
               rect:['15px','0px','1px','12px','auto','auto'],
               fill:["rgba(49,49,49,1.00)"],
               stroke:[0,"rgb(218, 35, 24)","solid"],
               transform:[]
            },
            {
               id:'Rectangle2Copy7',
               type:'rect',
               rect:['8px','0px','15px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            },
            {
               id:'Rectangle2Copy6',
               type:'rect',
               rect:['8px','11px','15px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            }]
         },
         {
            id:'Group3Copy5',
            type:'group',
            rect:['558px','201','30','12','auto','auto'],
            transform:[],
            c:[
            {
               id:'RectangleCopy6',
               type:'rect',
               rect:['15px','0px','1px','12px','auto','auto'],
               fill:["rgba(49,49,49,1.00)"],
               stroke:[0,"rgb(218, 35, 24)","solid"],
               transform:[]
            },
            {
               id:'Rectangle2Copy13',
               type:'rect',
               rect:['8px','0px','15px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            },
            {
               id:'Rectangle2Copy12',
               type:'rect',
               rect:['8px','11px','15px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            }]
         },
         {
            id:'Group3Copy6',
            type:'group',
            rect:['558px','201','30','12','auto','auto'],
            transform:[],
            c:[
            {
               id:'RectangleCopy7',
               type:'rect',
               rect:['15px','0px','1px','12px','auto','auto'],
               fill:["rgba(49,49,49,1.00)"],
               stroke:[0,"rgb(218, 35, 24)","solid"],
               transform:[]
            },
            {
               id:'Rectangle2Copy15',
               type:'rect',
               rect:['8px','3px','15px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            },
            {
               id:'Rectangle2Copy14',
               type:'rect',
               rect:['8px','10px','15px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            }]
         },
         {
            id:'Group3Copy2',
            type:'group',
            rect:['588px','201','30','12','auto','auto'],
            transform:[],
            c:[
            {
               id:'RectangleCopy2',
               type:'rect',
               rect:['15px','-7px','1px','27px','auto','auto'],
               fill:["rgba(49,49,49,1.00)"],
               stroke:[0,"rgb(218, 35, 24)","solid"],
               transform:[[],[],[],['1','0.76']]
            },
            {
               id:'Rectangle2Copy5',
               type:'rect',
               rect:['8px','-4px','15px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            },
            {
               id:'Rectangle2Copy4',
               type:'rect',
               rect:['8px','17px','15px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            }]
         },
         {
            id:'Group3Copy8',
            type:'group',
            rect:['588px','201','30','12','auto','auto'],
            transform:[],
            c:[
            {
               id:'RectangleCopy9',
               type:'rect',
               rect:['15px','-7px','1px','27px','auto','auto'],
               fill:["rgba(49,49,49,1.00)"],
               stroke:[0,"rgb(218, 35, 24)","solid"],
               transform:[[],[],[],['1','0.76']]
            },
            {
               id:'Rectangle2Copy19',
               type:'rect',
               rect:['8px','-4px','15px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            },
            {
               id:'Rectangle2Copy18',
               type:'rect',
               rect:['8px','17px','15px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            }]
         },
         {
            id:'Group3Copy7',
            type:'group',
            rect:['588px','201','30','12','auto','auto'],
            transform:[],
            c:[
            {
               id:'RectangleCopy8',
               type:'rect',
               rect:['15px','-5px','1px','27px','auto','auto'],
               fill:["rgba(49,49,49,1.00)"],
               stroke:[0,"rgb(218, 35, 24)","solid"],
               transform:[[],[],[],['1','0.63']]
            },
            {
               id:'Rectangle2Copy17',
               type:'rect',
               rect:['8px','-1px','15px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            },
            {
               id:'Rectangle2Copy16',
               type:'rect',
               rect:['8px','16px','15px','1px','auto','auto'],
               fill:["rgba(49,49,49,1)"],
               stroke:[0,"rgb(218, 35, 24)","solid"]
            }]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_d7}": [
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["style", "top", '246px'],
            ["style", "height", '1px'],
            ["style", "opacity", '0'],
            ["style", "left", '518px'],
            ["style", "width", '20px']
         ],
         "${_TextCopy9}": [
            ["style", "top", '285px'],
            ["color", "color", 'rgba(49,49,49,1.00)'],
            ["style", "opacity", '0'],
            ["style", "left", '706px'],
            ["style", "font-size", '12px']
         ],
         "${_Group3Copy}": [
            ["style", "top", '129px'],
            ["style", "left", '734px'],
            ["transform", "scaleY", '0'],
            ["transform", "scaleX", '0']
         ],
         "${_time}": [
            ["style", "-webkit-transform-origin", [50,98], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [50,98],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [50,98],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [50,98],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [50,98],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "top", '-9px'],
            ["transform", "rotateZ", '0deg'],
            ["style", "left", '47px'],
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["style", "border-width", '0px'],
            ["style", "width", '5px']
         ],
         "${_Text2}": [
            ["style", "top", '303px'],
            ["style", "font-size", '14px'],
            ["style", "font-family", 'helveticaneue-condensedbold'],
            ["color", "color", 'rgba(244,142,108,1.00)'],
            ["style", "opacity", '0'],
            ["style", "left", '542px'],
            ["style", "width", '317px']
         ],
         "${_stolbik6}": [
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["style", "bottom", '174px'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '0px'],
            ["style", "width", '30px'],
            ["style", "top", 'auto'],
            ["style", "left", 'auto'],
            ["style", "height", '177px'],
            ["color", "border-color", 'rgba(218,35,24,1.00)'],
            ["style", "right", '8.32%'],
            ["style", "opacity", '0']
         ],
         "${_sigmentCopy}": [
            ["style", "-webkit-transform-origin", [0,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "rotateZ", '-90deg'],
            ["style", "height", '49px'],
            ["style", "top", '-15px'],
            ["style", "left", '50px'],
            ["style", "width", '49px']
         ],
         "${_line}": [
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["style", "height", '1px'],
            ["style", "top", '275px'],
            ["style", "left", '2px'],
            ["style", "width", '0px']
         ],
         "${_sigmentCopy2}": [
            ["style", "top", '-15px'],
            ["transform", "rotateZ", '-90deg'],
            ["style", "height", '49px'],
            ["style", "-webkit-transform-origin", [0,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "left", '50px'],
            ["style", "width", '49px']
         ],
         "${_stolbik1}": [
            ["color", "background-color", 'rgba(255,255,255,1.00)'],
            ["style", "bottom", '174px'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '0px'],
            ["style", "width", '58px'],
            ["style", "top", 'auto'],
            ["style", "height", '0px'],
            ["color", "border-color", 'rgba(218,35,24,1.00)'],
            ["style", "left", 'auto'],
            ["style", "right", '25.4%']
         ],
         "${_TextCopy4}": [
            ["style", "top", '178px'],
            ["color", "color", 'rgba(49,49,49,1.00)'],
            ["style", "opacity", '0'],
            ["style", "left", '489px'],
            ["style", "font-size", '12px']
         ],
         "${_stolbik8}": [
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["style", "bottom", '174px'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '0px'],
            ["style", "width", '30px'],
            ["style", "top", 'auto'],
            ["style", "right", '8.43%'],
            ["style", "height", '143px'],
            ["color", "border-color", 'rgba(218,35,24,1.00)'],
            ["style", "left", 'auto'],
            ["style", "opacity", '0']
         ],
         "${_TextCopy12}": [
            ["style", "top", '279px'],
            ["color", "color", 'rgba(49,49,49,1.00)'],
            ["style", "opacity", '0'],
            ["style", "left", '703px'],
            ["style", "font-size", '12px']
         ],
         "${_RectangleCopy7}": [
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["transform", "scaleY", '0.55'],
            ["style", "height", '12px'],
            ["style", "top", '1px'],
            ["style", "left", '15px'],
            ["style", "width", '1px']
         ],
         "${_TextCopy8}": [
            ["style", "top", '27px'],
            ["color", "color", 'rgba(49,49,49,1.00)'],
            ["style", "opacity", '0.000000'],
            ["style", "left", '489px'],
            ["style", "font-size", '12px']
         ],
         "${_Rectangle2Copy6}": [
            ["style", "top", '11px'],
            ["style", "left", '8px'],
            ["style", "width", '15px']
         ],
         "${_Rectangle2Copy12}": [
            ["style", "top", '11px'],
            ["style", "left", '8px'],
            ["style", "width", '15px']
         ],
         "${__12Copy}": [
            ["style", "top", '145px'],
            ["transform", "scaleX", '-1'],
            ["style", "height", '165px'],
            ["style", "opacity", '0.000000'],
            ["style", "left", '122px'],
            ["style", "width", '85px']
         ],
         "${_p2}": [
            ["style", "top", '305px'],
            ["style", "height", '11px'],
            ["style", "opacity", '0'],
            ["style", "left", '525px'],
            ["style", "width", '11px']
         ],
         "${_Rectangle2Copy4}": [
            ["style", "top", '17px'],
            ["style", "left", '8px'],
            ["style", "width", '15px']
         ],
         "${_TextCopy11}": [
            ["style", "top", '285px'],
            ["color", "color", 'rgba(49,49,49,1.00)'],
            ["style", "opacity", '0'],
            ["style", "left", '707px'],
            ["style", "font-size", '12px']
         ],
         "${_d1Copy}": [
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["style", "top", '36px'],
            ["style", "height", '1px'],
            ["style", "opacity", '0.000000'],
            ["style", "left", '518px'],
            ["style", "width", '20px']
         ],
         "${_RectangleCopy9}": [
            ["style", "top", '-7px'],
            ["transform", "scaleY", '0.76'],
            ["style", "height", '27px'],
            ["transform", "scaleX", '1'],
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["style", "left", '15px'],
            ["style", "width", '1px']
         ],
         "${_stolbik5}": [
            ["color", "background-color", 'rgba(255,255,255,1.00)'],
            ["style", "bottom", '174px'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '1px'],
            ["style", "width", '28px'],
            ["style", "top", 'auto'],
            ["style", "right", '11.53%'],
            ["style", "height", '32px'],
            ["color", "border-color", 'rgba(218,35,24,1.00)'],
            ["style", "left", 'auto'],
            ["style", "opacity", '0']
         ],
         "${_time_1}": [
            ["style", "top", '-16px'],
            ["style", "height", '100px'],
            ["style", "left", '0px'],
            ["style", "width", '100px']
         ],
         "${__22Copy}": [
            ["style", "top", '145px'],
            ["transform", "scaleX", '-1'],
            ["style", "height", '165px'],
            ["style", "opacity", '0.000000'],
            ["style", "left", '122px'],
            ["style", "width", '85px']
         ],
         "${_RectangleCopy6}": [
            ["style", "top", '0px'],
            ["transform", "scaleY", '1'],
            ["style", "height", '12px'],
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["style", "left", '15px'],
            ["style", "width", '1px']
         ],
         "${_RectangleCopy3}": [
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["transform", "scaleY", '1'],
            ["style", "height", '12px'],
            ["style", "top", '0px'],
            ["style", "left", '15px'],
            ["style", "width", '1px']
         ],
         "${_Rectangle2Copy}": [
            ["style", "top", '11px'],
            ["style", "left", '0px'],
            ["style", "width", '30px']
         ],
         "${_Rectangle2Copy14}": [
            ["style", "top", '10px'],
            ["style", "left", '8px'],
            ["style", "width", '15px']
         ],
         "${_RectangleCopy8}": [
            ["style", "top", '-5px'],
            ["transform", "scaleY", '0.63'],
            ["style", "height", '27px'],
            ["transform", "scaleX", '1'],
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["style", "left", '15px'],
            ["style", "width", '1px']
         ],
         "${_Text}": [
            ["style", "top", '57px'],
            ["color", "color", 'rgba(49,49,49,1.00)'],
            ["style", "opacity", '0'],
            ["style", "left", '489px'],
            ["style", "font-size", '12px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "overflow", 'visible'],
            ["style", "height", '450px'],
            ["style", "width", '937px']
         ],
         "${_TextCopy6}": [
            ["style", "top", '238px'],
            ["color", "color", 'rgba(49,49,49,1.00)'],
            ["style", "opacity", '0'],
            ["style", "left", '496px'],
            ["style", "font-size", '12px']
         ],
         "${__32Copy}": [
            ["style", "top", '145px'],
            ["transform", "scaleX", '-1'],
            ["style", "height", '165px'],
            ["style", "opacity", '0.000000'],
            ["style", "left", '122px'],
            ["style", "width", '85px']
         ],
         "${__32}": [
            ["style", "top", '145px'],
            ["style", "height", '165px'],
            ["style", "opacity", '0'],
            ["style", "left", '248px'],
            ["style", "width", '85px']
         ],
         "${_Rectangle2}": [
            ["style", "top", '0px'],
            ["style", "left", '0px'],
            ["style", "width", '30px']
         ],
         "${__22}": [
            ["style", "top", '145px'],
            ["style", "height", '165px'],
            ["style", "opacity", '0'],
            ["style", "left", '248px'],
            ["style", "width", '85px']
         ],
         "${_stolbik2}": [
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["style", "bottom", '174px'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '0px'],
            ["style", "width", '60px'],
            ["style", "top", 'auto'],
            ["style", "height", '0px'],
            ["color", "border-color", 'rgba(218,35,24,1.00)'],
            ["style", "left", 'auto'],
            ["style", "right", '16.76%']
         ],
         "${_slider}": [
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["style", "height", '1px'],
            ["style", "top", '396px'],
            ["style", "left", '478px'],
            ["style", "width", '380px']
         ],
         "${_stolbik4}": [
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["style", "bottom", '174px'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '0px'],
            ["style", "width", '30px'],
            ["style", "top", 'auto'],
            ["style", "right", '8.43%'],
            ["style", "height", '160px'],
            ["color", "border-color", 'rgba(218,35,24,1.00)'],
            ["style", "left", 'auto'],
            ["style", "opacity", '0']
         ],
         "${_Rectangle2Copy16}": [
            ["style", "top", '16px'],
            ["style", "left", '8px'],
            ["style", "width", '15px']
         ],
         "${_d3}": [
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["style", "top", '126px'],
            ["style", "height", '1px'],
            ["style", "opacity", '0'],
            ["style", "left", '518px'],
            ["style", "width", '20px']
         ],
         "${_Rectangle2Copy18}": [
            ["style", "top", '17px'],
            ["style", "left", '8px'],
            ["style", "width", '15px']
         ],
         "${_legkie}": [
            ["style", "top", '138px'],
            ["style", "height", '178px'],
            ["style", "left", '117px'],
            ["style", "width", '222px']
         ],
         "${_Group2}": [
            ["style", "top", '361px']
         ],
         "${_Group3Copy8}": [
            ["style", "top", '124px'],
            ["transform", "scaleY", '1'],
            ["transform", "scaleX", '1'],
            ["style", "opacity", '0'],
            ["style", "left", '829px']
         ],
         "${_Rectangle3}": [
            ["color", "background-color", 'rgba(218,35,24,0.00)'],
            ["style", "top", '345px']
         ],
         "${_timeCopy}": [
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["transform", "rotateZ", '0deg'],
            ["style", "right", '48px'],
            ["style", "left", 'auto'],
            ["style", "width", '5px'],
            ["style", "top", 'auto'],
            ["style", "height", '40px'],
            ["style", "bottom", '65px'],
            ["style", "-webkit-transform-origin", [50,97], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [50,97],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [50,97],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [50,97],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [50,97],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "border-width", '0px']
         ],
         "${__12}": [
            ["style", "top", '145px'],
            ["style", "height", '165px'],
            ["style", "opacity", '0'],
            ["style", "left", '248px'],
            ["style", "width", '85px']
         ],
         "${_sigmentCopy3}": [
            ["style", "-webkit-transform-origin", [0,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "rotateZ", '-90deg'],
            ["style", "height", '49px'],
            ["style", "top", '-15px'],
            ["style", "left", '50px'],
            ["style", "width", '49px']
         ],
         "${_d5}": [
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["style", "top", '186px'],
            ["style", "height", '1px'],
            ["style", "opacity", '0'],
            ["style", "left", '518px'],
            ["style", "width", '20px']
         ],
         "${_d2}": [
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["style", "top", '96px'],
            ["style", "height", '1px'],
            ["style", "opacity", '0'],
            ["style", "left", '518px'],
            ["style", "width", '20px']
         ],
         "${_Group3Copy3}": [
            ["style", "top", '179px'],
            ["transform", "scaleY", '1'],
            ["transform", "scaleX", '1'],
            ["style", "opacity", '0'],
            ["style", "left", '799px']
         ],
         "${_Rectangle2Copy15}": [
            ["style", "top", '3px'],
            ["style", "left", '8px'],
            ["style", "width", '15px']
         ],
         "${_Rectangle2Copy13}": [
            ["style", "top", '0px'],
            ["style", "left", '8px'],
            ["style", "width", '15px']
         ],
         "${_d1}": [
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["style", "top", '66px'],
            ["style", "height", '1px'],
            ["style", "opacity", '0'],
            ["style", "left", '518px'],
            ["style", "width", '20px']
         ],
         "${_sigment}": [
            ["style", "top", 'auto'],
            ["transform", "rotateZ", '-90deg'],
            ["style", "-webkit-transform-origin", [0,100], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [0,100],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "bottom", '66px'],
            ["style", "height", '49px'],
            ["style", "right", '1px'],
            ["style", "left", 'auto'],
            ["style", "width", '49px']
         ],
         "${_d4}": [
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["style", "top", '155px'],
            ["style", "height", '1px'],
            ["style", "opacity", '0'],
            ["style", "left", '518px'],
            ["style", "width", '20px']
         ],
         "${_Group3Copy6}": [
            ["style", "top", '235px'],
            ["transform", "scaleY", '1'],
            ["transform", "scaleX", '1'],
            ["style", "opacity", '0'],
            ["style", "left", '799px']
         ],
         "${_sigment_mask}": [
            ["style", "top", '-16px'],
            ["style", "height", '50px'],
            ["style", "opacity", '1'],
            ["style", "left", '0px'],
            ["style", "width", '50px']
         ],
         "${_Group3Copy5}": [
            ["style", "top", '214px'],
            ["transform", "scaleY", '1'],
            ["transform", "scaleX", '1'],
            ["style", "opacity", '0'],
            ["style", "left", '799px']
         ],
         "${__42Copy}": [
            ["style", "top", '145px'],
            ["transform", "scaleX", '-1'],
            ["style", "height", '165px'],
            ["style", "opacity", '0.000000'],
            ["style", "left", '122px'],
            ["style", "width", '85px']
         ],
         "${_Rectangle2Copy3}": [
            ["style", "top", '-9px'],
            ["style", "left", '0px'],
            ["style", "width", '30px']
         ],
         "${_chelovek}": [
            ["style", "top", '-50px'],
            ["style", "height", '543px'],
            ["style", "left", '8px'],
            ["style", "clip", [50,439,500,0], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ],
            ["style", "width", '439px']
         ],
         "${_Group3}": [
            ["transform", "scaleX", '0'],
            ["style", "top", '181px'],
            ["transform", "scaleY", '0'],
            ["style", "left", '653px']
         ],
         "${_Rectangle2Copy5}": [
            ["style", "top", '-4px'],
            ["style", "left", '8px'],
            ["style", "width", '15px']
         ],
         "${_RectangleCopy2}": [
            ["style", "top", '-7px'],
            ["transform", "scaleY", '0.76'],
            ["transform", "scaleX", '1'],
            ["style", "height", '27px'],
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["style", "left", '15px'],
            ["style", "width", '1px']
         ],
         "${_Rectangle2Copy2}": [
            ["style", "top", '19px'],
            ["style", "left", '0px'],
            ["style", "width", '30px']
         ],
         "${_Rectangle2Copy19}": [
            ["style", "top", '-4px'],
            ["style", "left", '8px'],
            ["style", "width", '15px']
         ],
         "${_TextCopy10}": [
            ["style", "top", '285px'],
            ["color", "color", 'rgba(49,49,49,1.00)'],
            ["style", "opacity", '0'],
            ["style", "left", '706px'],
            ["style", "font-size", '12px']
         ],
         "${_Rectangle}": [
            ["style", "top", '0px'],
            ["transform", "scaleY", '1'],
            ["style", "height", '12px'],
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["style", "left", '15px'],
            ["style", "width", '1px']
         ],
         "${_ingalaytor}": [
            ["style", "top", '103px'],
            ["transform", "scaleY", '1'],
            ["style", "height", '146px'],
            ["transform", "scaleX", '1'],
            ["style", "left", '620px'],
            ["style", "width", '100px']
         ],
         "${_RectangleCopy}": [
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["transform", "scaleY", '1'],
            ["style", "height", '27px'],
            ["style", "top", '-8px'],
            ["style", "left", '15px'],
            ["style", "width", '1px']
         ],
         "${_Text2Copy}": [
            ["style", "top", '323px'],
            ["style", "font-family", 'helveticaneue-condensedbold'],
            ["color", "color", 'rgba(218,35,24,1.00)'],
            ["style", "opacity", '0'],
            ["style", "left", '542px'],
            ["style", "font-size", '14px']
         ],
         "${_TextCopy3}": [
            ["style", "top", '148px'],
            ["color", "color", 'rgba(49,49,49,1.00)'],
            ["style", "opacity", '0'],
            ["style", "left", '489px'],
            ["style", "font-size", '12px']
         ],
         "${_p1}": [
            ["style", "top", '325px'],
            ["style", "height", '11px'],
            ["style", "opacity", '0'],
            ["style", "left", '525px'],
            ["style", "width", '11px']
         ],
         "${_Group3Copy2}": [
            ["style", "top", '114px'],
            ["transform", "scaleY", '1'],
            ["transform", "scaleX", '1'],
            ["style", "opacity", '0'],
            ["style", "left", '829px']
         ],
         "${_TextCopy2}": [
            ["style", "top", '118px'],
            ["color", "color", 'rgba(49,49,49,1.00)'],
            ["style", "opacity", '0'],
            ["style", "left", '489px'],
            ["style", "font-size", '12px']
         ],
         "${_d6}": [
            ["color", "background-color", 'rgba(49,49,49,1.00)'],
            ["style", "top", '216px'],
            ["style", "height", '1px'],
            ["style", "opacity", '0'],
            ["style", "left", '518px'],
            ["style", "width", '20px']
         ],
         "${__42}": [
            ["style", "top", '145px'],
            ["style", "height", '165px'],
            ["style", "opacity", '0'],
            ["style", "left", '248px'],
            ["style", "width", '85px']
         ],
         "${_axis}": [
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["style", "height", '1px'],
            ["style", "top", '275px'],
            ["style", "left", '518px'],
            ["style", "width", '0px']
         ],
         "${_stolbik3}": [
            ["color", "background-color", 'rgba(255,255,255,1.00)'],
            ["style", "bottom", '174px'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '1px'],
            ["style", "width", '28px'],
            ["style", "top", 'auto'],
            ["style", "left", 'auto'],
            ["style", "height", '55px'],
            ["color", "border-color", 'rgba(218,35,24,1.00)'],
            ["style", "right", '11.53%'],
            ["style", "opacity", '0']
         ],
         "${_stolbik7}": [
            ["color", "background-color", 'rgba(255,255,255,1.00)'],
            ["style", "bottom", '174px'],
            ["style", "border-style", 'solid'],
            ["style", "border-width", '1px'],
            ["style", "width", '28px'],
            ["style", "top", 'auto'],
            ["style", "left", 'auto'],
            ["style", "height", '87px'],
            ["color", "border-color", 'rgba(218,35,24,1.00)'],
            ["style", "right", '11.53%'],
            ["style", "opacity", '0']
         ],
         "${_Rectangle2Copy17}": [
            ["style", "top", '-1px'],
            ["style", "left", '8px'],
            ["style", "width", '15px']
         ],
         "${_TextCopy5}": [
            ["style", "top", '208px'],
            ["color", "color", 'rgba(49,49,49,1.00)'],
            ["style", "opacity", '0'],
            ["style", "left", '489px'],
            ["style", "font-size", '12px']
         ],
         "${_Rectangle2Copy7}": [
            ["style", "top", '0px'],
            ["style", "left", '8px'],
            ["style", "width", '15px']
         ],
         "${_TextCopy}": [
            ["style", "top", '88px'],
            ["color", "color", 'rgba(49,49,49,1.00)'],
            ["style", "opacity", '0'],
            ["style", "left", '489px'],
            ["style", "font-size", '12px']
         ],
         "${_TextCopy7}": [
            ["style", "top", '268px'],
            ["color", "color", 'rgba(49,49,49,1.00)'],
            ["style", "opacity", '0'],
            ["style", "left", '503px'],
            ["style", "font-size", '12px']
         ],
         "${_Group3Copy7}": [
            ["style", "top", '91px'],
            ["transform", "scaleY", '1'],
            ["transform", "scaleX", '1'],
            ["style", "opacity", '0'],
            ["style", "left", '829px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 3500,
         autoPlay: true,
         labels: {
            "1": 250,
            "2": 1666,
            "8": 2000,
            "3": 2017,
            "7": 2329,
            "4": 2345,
            "6": 2750,
            "5": 3500
         },
         timeline: [
            { id: "eid990", tween: [ "style", "${__32Copy}", "top", '145px', { fromValue: '145px'}], position: 3500, duration: 0 },
            { id: "eid711", tween: [ "style", "${_stolbik8}", "height", '143px', { fromValue: '143px'}], position: 3500, duration: 0 },
            { id: "eid518", tween: [ "style", "${_Rectangle2Copy3}", "width", '15px', { fromValue: '30px'}], position: 2750, duration: 325 },
            { id: "eid1004", tween: [ "style", "${_sigmentCopy3}", "top", '-15px', { fromValue: '-15px'}], position: 2088, duration: 0 },
            { id: "eid960", tween: [ "style", "${_Group3Copy7}", "top", '91px', { fromValue: '91px'}], position: 3500, duration: 0 },
            { id: "eid928", tween: [ "style", "${_d7}", "top", '246px', { fromValue: '246px'}], position: 3500, duration: 0 },
            { id: "eid262", tween: [ "style", "${__12}", "opacity", '1', { fromValue: '0.000000'}], position: 964, duration: 175 },
            { id: "eid267", tween: [ "style", "${__12}", "opacity", '0', { fromValue: '1'}], position: 2000, duration: 17 },
            { id: "eid141", tween: [ "style", "${_stolbik8}", "opacity", '1', { fromValue: '0'}], position: 3075, duration: 425 },
            { id: "eid49", tween: [ "style", "${_TextCopy2}", "opacity", '1', { fromValue: '0.000000'}], position: 1139, duration: 176 },
            { id: "eid95", tween: [ "style", "${_TextCopy12}", "opacity", '1', { fromValue: '0.000000'}], position: 2345, duration: 178 },
            { id: "eid931", tween: [ "style", "${_TextCopy6}", "top", '238px', { fromValue: '238px'}], position: 3500, duration: 0 },
            { id: "eid712", tween: [ "style", "${_stolbik7}", "height", '87px', { fromValue: '87px'}], position: 3500, duration: 0 },
            { id: "eid551", tween: [ "style", "${_Group3Copy2}", "left", '669px', { fromValue: '829px'}], position: 3075, duration: 425 },
            { id: "eid148", tween: [ "style", "${_TextCopy10}", "left", '666px', { fromValue: '706px'}], position: 3075, duration: 425 },
            { id: "eid1012", tween: [ "style", "${_TextCopy11}", "top", '285px', { fromValue: '285px'}], position: 2088, duration: 0 },
            { id: "eid1031", tween: [ "style", "${_TextCopy11}", "top", '285px', { fromValue: '285px'}], position: 3075, duration: 0 },
            { id: "eid1032", tween: [ "style", "${_TextCopy11}", "top", '285px', { fromValue: '285px'}], position: 3500, duration: 0 },
            { id: "eid338", tween: [ "style", "${_sigmentCopy2}", "left", '130px', { fromValue: '50px'}], position: 604, duration: 170 },
            { id: "eid339", tween: [ "style", "${_sigmentCopy2}", "left", '210px', { fromValue: '130px'}], position: 1666, duration: 351 },
            { id: "eid340", tween: [ "style", "${_sigmentCopy2}", "left", '290px', { fromValue: '210px'}], position: 2017, duration: 328 },
            { id: "eid341", tween: [ "style", "${_sigmentCopy2}", "left", '370px', { fromValue: '290px'}], position: 2345, duration: 324 },
            { id: "eid1019", tween: [ "style", "${_Group3}", "top", '214px', { fromValue: '181px'}], position: 1666, duration: 351 },
            { id: "eid1020", tween: [ "style", "${_Group3}", "top", '236px', { fromValue: '214px'}], position: 2017, duration: 312 },
            { id: "eid1021", tween: [ "style", "${_Group3}", "top", '256px', { fromValue: '236px'}], position: 2345, duration: 324 },
            { id: "eid1025", tween: [ "style", "${_Group3}", "top", '256px', { fromValue: '256px'}], position: 3500, duration: 0 },
            { id: "eid986", tween: [ "style", "${__12Copy}", "top", '145px', { fromValue: '145px'}], position: 3500, duration: 0 },
            { id: "eid1002", tween: [ "style", "${_sigmentCopy}", "top", '-15px', { fromValue: '-15px'}], position: 2088, duration: 0 },
            { id: "eid623", tween: [ "style", "${_Text2}", "left", '542px', { fromValue: '542px'}], position: 1250, duration: 0 },
            { id: "eid707", tween: [ "style", "${_stolbik4}", "height", '160px', { fromValue: '160px'}], position: 3500, duration: 0 },
            { id: "eid700", tween: [ "style", "${_stolbik6}", "height", '177px', { fromValue: '177px'}], position: 3500, duration: 0 },
            { id: "eid484", tween: [ "style", "${_Rectangle2Copy2}", "top", '16px', { fromValue: '19px'}], position: 1666, duration: 351 },
            { id: "eid487", tween: [ "style", "${_Rectangle2Copy2}", "top", '17px', { fromValue: '16px'}], position: 2017, duration: 328 },
            { id: "eid488", tween: [ "style", "${_Rectangle2Copy2}", "top", '31px', { fromValue: '17px'}], position: 2345, duration: 324 },
            { id: "eid21", tween: [ "style", "${_d1}", "opacity", '1', { fromValue: '0.000000'}], position: 964, duration: 176 },
            { id: "eid509", tween: [ "style", "${_Rectangle2Copy}", "left", '8px', { fromValue: '0px'}], position: 2750, duration: 325 },
            { id: "eid964", tween: [ "style", "${_stolbik7}", "bottom", '174px', { fromValue: '174px'}], position: 3500, duration: 0 },
            { id: "eid592", tween: [ "style", "${_Group3Copy6}", "opacity", '1', { fromValue: '0'}], position: 3075, duration: 425 },
            { id: "eid146", tween: [ "style", "${_TextCopy11}", "left", '747px', { fromValue: '707px'}], position: 3075, duration: 425 },
            { id: "eid85", tween: [ "style", "${_TextCopy10}", "opacity", '1', { fromValue: '0.000000'}], position: 1666, duration: 176 },
            { id: "eid92", tween: [ "style", "${_TextCopy10}", "opacity", '0', { fromValue: '1'}], position: 2017, duration: 178 },
            { id: "eid147", tween: [ "style", "${_TextCopy10}", "opacity", '1', { fromValue: '0.000000'}], position: 3075, duration: 425 },
            { id: "eid66", tween: [ "style", "${_TextCopy9}", "opacity", '1', { fromValue: '0.000000'}], position: 1315, duration: 176 },
            { id: "eid87", tween: [ "style", "${_TextCopy9}", "opacity", '0', { fromValue: '1'}], position: 1666, duration: 176 },
            { id: "eid149", tween: [ "style", "${_TextCopy9}", "opacity", '1', { fromValue: '0'}], position: 3075, duration: 425 },
            { id: "eid3", tween: [ "transform", "${_ingalaytor}", "scaleX", '0', { fromValue: '1'}], position: 250, duration: 354 },
            { id: "eid479", tween: [ "style", "${_Group3Copy}", "top", '113px', { fromValue: '129px'}], position: 1666, duration: 351 },
            { id: "eid480", tween: [ "style", "${_Group3Copy}", "top", '92px', { fromValue: '113px'}], position: 2017, duration: 328 },
            { id: "eid481", tween: [ "style", "${_Group3Copy}", "top", '77px', { fromValue: '92px'}], position: 2345, duration: 324 },
            { id: "eid1026", tween: [ "style", "${_Group3Copy}", "top", '77px', { fromValue: '77px'}], position: 3500, duration: 0 },
            { id: "eid51", tween: [ "style", "${_Text}", "opacity", '1', { fromValue: '0.000000'}], position: 1139, duration: 176 },
            { id: "eid116", tween: [ "style", "${_stolbik5}", "right", '20.06%', { fromValue: '11.53%'}], position: 3075, duration: 425 },
            { id: "eid506", tween: [ "style", "${_Rectangle2}", "width", '15px', { fromValue: '30px'}], position: 2750, duration: 325 },
            { id: "eid1015", tween: [ "style", "${_TextCopy9}", "top", '285px', { fromValue: '285px'}], position: 1750, duration: 0 },
            { id: "eid1016", tween: [ "style", "${_TextCopy9}", "top", '285px', { fromValue: '285px'}], position: 2088, duration: 0 },
            { id: "eid1027", tween: [ "style", "${_TextCopy9}", "top", '285px', { fromValue: '285px'}], position: 3075, duration: 0 },
            { id: "eid1028", tween: [ "style", "${_TextCopy9}", "top", '285px', { fromValue: '285px'}], position: 3500, duration: 0 },
            { id: "eid929", tween: [ "style", "${_Group3Copy2}", "top", '114px', { fromValue: '114px'}], position: 3500, duration: 0 },
            { id: "eid940", tween: [ "style", "${_d3}", "top", '126px', { fromValue: '126px'}], position: 3500, duration: 0 },
            { id: "eid598", tween: [ "transform", "${_RectangleCopy7}", "scaleY", '0.55', { fromValue: '0.55'}], position: 3500, duration: 0 },
            { id: "eid22", tween: [ "style", "${_d2}", "opacity", '1', { fromValue: '0.000000'}], position: 964, duration: 176 },
            { id: "eid819", tween: [ "style", "${_d2}", "opacity", '0.99', { fromValue: '1'}], position: 1140, duration: 2360 },
            { id: "eid444", tween: [ "style", "${_Rectangle2Copy}", "top", '11px', { fromValue: '11px'}], position: 1666, duration: 0 },
            { id: "eid460", tween: [ "style", "${_Rectangle2Copy}", "top", '7px', { fromValue: '11px'}], position: 2017, duration: 328 },
            { id: "eid127", tween: [ "style", "${_stolbik7}", "right", '37.14%', { fromValue: '11.53%'}], position: 3075, duration: 425 },
            { id: "eid1005", tween: [ "style", "${_sigment}", "bottom", '66px', { fromValue: '66px'}], position: 2088, duration: 0 },
            { id: "eid188", tween: [ "style", "${_Text2}", "opacity", '1', { fromValue: '0'}], position: 1139, duration: 176 },
            { id: "eid1029", tween: [ "style", "${_TextCopy10}", "top", '285px', { fromValue: '285px'}], position: 2088, duration: 0 },
            { id: "eid1030", tween: [ "style", "${_TextCopy10}", "top", '285px', { fromValue: '285px'}], position: 3500, duration: 0 },
            { id: "eid133", tween: [ "style", "${_stolbik5}", "opacity", '1', { fromValue: '0'}], position: 3075, duration: 425 },
            { id: "eid615", tween: [ "style", "${_p1}", "left", '525px', { fromValue: '525px'}], position: 1250, duration: 0 },
            { id: "eid709", tween: [ "style", "${_stolbik3}", "height", '55px', { fromValue: '55px'}], position: 3500, duration: 0 },
            { id: "eid992", tween: [ "style", "${__22Copy}", "top", '145px', { fromValue: '145px'}], position: 3500, duration: 0 },
            { id: "eid467", tween: [ "transform", "${_Group3Copy}", "scaleY", '1', { fromValue: '0'}], position: 1625, duration: 41 },
            { id: "eid961", tween: [ "style", "${_TextCopy5}", "top", '208px', { fromValue: '208px'}], position: 3500, duration: 0 },
            { id: "eid934", tween: [ "style", "${_d2}", "top", '96px', { fromValue: '96px'}], position: 3500, duration: 0 },
            { id: "eid278", tween: [ "style", "${__42Copy}", "opacity", '1', { fromValue: '0.000000'}], position: 2345, duration: 295 },
            { id: "eid593", tween: [ "style", "${_Group3Copy6}", "left", '718px', { fromValue: '799px'}], position: 3075, duration: 425 },
            { id: "eid505", tween: [ "style", "${_Rectangle2Copy}", "width", '15px', { fromValue: '30px'}], position: 2750, duration: 325 },
            { id: "eid402", tween: [ "style", "${_sigment_mask}", "left", '80px', { fromValue: '0px'}], position: 604, duration: 170 },
            { id: "eid945", tween: [ "style", "${_TextCopy7}", "top", '268px', { fromValue: '268px'}], position: 3500, duration: 0 },
            { id: "eid491", tween: [ "transform", "${_RectangleCopy}", "scaleY", '0.76', { fromValue: '1'}], position: 1666, duration: 351 },
            { id: "eid494", tween: [ "transform", "${_RectangleCopy}", "scaleY", '0.69', { fromValue: '0.76'}], position: 2017, duration: 328 },
            { id: "eid496", tween: [ "transform", "${_RectangleCopy}", "scaleY", '1.96', { fromValue: '0.69'}], position: 2345, duration: 324 },
            { id: "eid463", tween: [ "transform", "${_Rectangle}", "scaleY", '0.48', { fromValue: '1'}], position: 2017, duration: 328 },
            { id: "eid419", tween: [ "transform", "${_Group3}", "scaleX", '1', { fromValue: '0'}], position: 1625, duration: 41 },
            { id: "eid275", tween: [ "style", "${__42}", "opacity", '1', { fromValue: '0.000000'}], position: 2345, duration: 295 },
            { id: "eid818", tween: [ "style", "${__42}", "opacity", '0.99000000953674', { fromValue: '1'}], position: 2640, duration: 860 },
            { id: "eid144", tween: [ "style", "${_TextCopy12}", "left", '823px', { fromValue: '703px'}], position: 3075, duration: 425 },
            { id: "eid414", tween: [ "style", "${_sigment_mask}", "opacity", '0', { fromValue: '1'}], position: 774, duration: 23 },
            { id: "eid944", tween: [ "style", "${_TextCopy2}", "top", '118px', { fromValue: '118px'}], position: 3500, duration: 0 },
            { id: "eid948", tween: [ "style", "${_stolbik6}", "bottom", '174px', { fromValue: '174px'}], position: 3500, duration: 0 },
            { id: "eid550", tween: [ "style", "${_Group3Copy2}", "opacity", '1', { fromValue: '0'}], position: 3075, duration: 425 },
            { id: "eid981", tween: [ "style", "${_d4}", "top", '155px', { fromValue: '155px'}], position: 3500, duration: 0 },
            { id: "eid930", tween: [ "style", "${_stolbik4}", "bottom", '174px', { fromValue: '174px'}], position: 3500, duration: 0 },
            { id: "eid53", tween: [ "style", "${_TextCopy7}", "opacity", '1', { fromValue: '0.000000'}], position: 1139, duration: 176 },
            { id: "eid967", tween: [ "style", "${_stolbik2}", "bottom", '174px', { fromValue: '174px'}], position: 3500, duration: 0 },
            { id: "eid52", tween: [ "style", "${_TextCopy3}", "opacity", '1', { fromValue: '0.000000'}], position: 1139, duration: 176 },
            { id: "eid946", tween: [ "style", "${_d1Copy}", "top", '36px', { fromValue: '36px'}], position: 3500, duration: 0 },
            { id: "eid517", tween: [ "style", "${_Rectangle2Copy2}", "width", '15px', { fromValue: '30px'}], position: 2750, duration: 325 },
            { id: "eid628", tween: [ "style", "${_Text2Copy}", "left", '542px', { fromValue: '542px'}], position: 1666, duration: 0 },
            { id: "eid54", tween: [ "style", "${_TextCopy4}", "opacity", '1', { fromValue: '0.000000'}], position: 1139, duration: 176 },
            { id: "eid519", tween: [ "style", "${_Rectangle2Copy2}", "left", '8px', { fromValue: '0px'}], position: 2750, duration: 325 },
            { id: "eid943", tween: [ "style", "${_stolbik5}", "bottom", '174px', { fromValue: '174px'}], position: 3500, duration: 0 },
            { id: "eid1001", tween: [ "style", "${_time}", "top", '-9px', { fromValue: '-9px'}], position: 2088, duration: 0 },
            { id: "eid485", tween: [ "style", "${_Rectangle2Copy3}", "top", '-5px', { fromValue: '-9px'}], position: 1666, duration: 351 },
            { id: "eid486", tween: [ "style", "${_Rectangle2Copy3}", "top", '-2px', { fromValue: '-5px'}], position: 2017, duration: 328 },
            { id: "eid489", tween: [ "style", "${_Rectangle2Copy3}", "top", '-22px', { fromValue: '-2px'}], position: 2345, duration: 324 },
            { id: "eid927", tween: [ "style", "${_stolbik3}", "bottom", '174px', { fromValue: '174px'}], position: 3500, duration: 0 },
            { id: "eid8", tween: [ "style", "${_line}", "width", '492px', { fromValue: '0px'}], position: 774, duration: 190 },
            { id: "eid289", tween: [ "style", "${_time}", "left", '127px', { fromValue: '47px'}], position: 604, duration: 170 },
            { id: "eid291", tween: [ "style", "${_time}", "left", '207px', { fromValue: '127px'}], position: 1666, duration: 351 },
            { id: "eid292", tween: [ "style", "${_time}", "left", '287px', { fromValue: '207px'}], position: 2017, duration: 328 },
            { id: "eid293", tween: [ "style", "${_time}", "left", '367px', { fromValue: '287px'}], position: 2345, duration: 324 },
            { id: "eid445", tween: [ "style", "${_Rectangle2}", "top", '0px', { fromValue: '0px'}], position: 1666, duration: 0 },
            { id: "eid458", tween: [ "style", "${_Rectangle2}", "top", '1px', { fromValue: '0px'}], position: 2017, duration: 328 },
            { id: "eid111", tween: [ "style", "${_stolbik1}", "width", '28px', { fromValue: '58px'}], position: 2750, duration: 325 },
            { id: "eid335", tween: [ "transform", "${_sigmentCopy}", "rotateZ", '0deg', { fromValue: '-90deg'}], position: 604, duration: 170 },
            { id: "eid337", tween: [ "transform", "${_sigmentCopy}", "rotateZ", '90deg', { fromValue: '0deg'}], position: 1666, duration: 351 },
            { id: "eid600", tween: [ "style", "${_Group3Copy7}", "opacity", '1', { fromValue: '0'}], position: 3075, duration: 425 },
            { id: "eid584", tween: [ "transform", "${_RectangleCopy6}", "scaleY", '0.48', { fromValue: '1'}], position: 2017, duration: 328 },
            { id: "eid585", tween: [ "transform", "${_RectangleCopy6}", "scaleY", '1', { fromValue: '0.48'}], position: 2345, duration: 1155 },
            { id: "eid128", tween: [ "style", "${_stolbik8}", "right", '34.04%', { fromValue: '8.43%'}], position: 3075, duration: 425 },
            { id: "eid270", tween: [ "style", "${__32}", "opacity", '1', { fromValue: '0.000000'}], position: 2017, duration: 328 },
            { id: "eid277", tween: [ "style", "${__32}", "opacity", '0', { fromValue: '1'}], position: 2622, duration: 18 },
            { id: "eid20", tween: [ "style", "${_d6}", "opacity", '1', { fromValue: '0.000000'}], position: 964, duration: 176 },
            { id: "eid947", tween: [ "style", "${_Group3Copy6}", "top", '235px', { fromValue: '235px'}], position: 3500, duration: 0 },
            { id: "eid969", tween: [ "style", "${_stolbik1}", "bottom", '174px', { fromValue: '174px'}], position: 3500, duration: 0 },
            { id: "eid608", tween: [ "style", "${_Group3Copy8}", "left", '588px', { fromValue: '829px'}], position: 3075, duration: 425 },
            { id: "eid954", tween: [ "style", "${_TextCopy4}", "top", '178px', { fromValue: '178px'}], position: 3500, duration: 0 },
            { id: "eid966", tween: [ "style", "${_stolbik8}", "bottom", '174px', { fromValue: '174px'}], position: 3500, duration: 0 },
            { id: "eid970", tween: [ "style", "${_line}", "top", '275px', { fromValue: '275px'}], position: 3500, duration: 0 },
            { id: "eid281", tween: [ "style", "${__22Copy}", "opacity", '1', { fromValue: '0.000000'}], position: 1666, duration: 351 },
            { id: "eid282", tween: [ "style", "${__22Copy}", "opacity", '0', { fromValue: '1'}], position: 2329, duration: 16 },
            { id: "eid107", tween: [ "style", "${_stolbik2}", "width", '30px', { fromValue: '60px'}], position: 2750, duration: 325 },
            { id: "eid122", tween: [ "style", "${_stolbik3}", "right", '28.6%', { fromValue: '11.53%'}], position: 3075, duration: 425 },
            { id: "eid1007", tween: [ "style", "${_timeCopy}", "bottom", '65px', { fromValue: '65px'}], position: 2088, duration: 0 },
            { id: "eid63", tween: [ "style", "${_stolbik2}", "height", '142px', { fromValue: '0px'}], position: 1315, duration: 351 },
            { id: "eid69", tween: [ "style", "${_stolbik2}", "height", '159px', { fromValue: '142px'}], position: 1666, duration: 351 },
            { id: "eid70", tween: [ "style", "${_stolbik2}", "height", '177px', { fromValue: '159px'}], position: 2017, duration: 328 },
            { id: "eid73", tween: [ "style", "${_stolbik2}", "height", '194px', { fromValue: '177px'}], position: 2345, duration: 325 },
            { id: "eid124", tween: [ "style", "${_stolbik4}", "right", '25.4%', { fromValue: '8.43%'}], position: 3075, duration: 425 },
            { id: "eid704", tween: [ "style", "${_stolbik5}", "height", '32px', { fromValue: '32px'}], position: 3500, duration: 0 },
            { id: "eid405", tween: [ "style", "${_sigment}", "right", '-79px', { fromValue: '1px'}], position: 604, duration: 170 },
            { id: "eid406", tween: [ "style", "${_sigment}", "right", '-159px', { fromValue: '-79px'}], position: 1666, duration: 351 },
            { id: "eid407", tween: [ "style", "${_sigment}", "right", '-239px', { fromValue: '-159px'}], position: 2017, duration: 328 },
            { id: "eid408", tween: [ "style", "${_sigment}", "right", '-319px', { fromValue: '-239px'}], position: 2345, duration: 324 },
            { id: "eid186", tween: [ "style", "${_p1}", "opacity", '1', { fromValue: '0'}], position: 1139, duration: 176 },
            { id: "eid987", tween: [ "style", "${__32}", "top", '145px', { fromValue: '145px'}], position: 3500, duration: 0 },
            { id: "eid671", tween: [ "style", "${_d1Copy}", "opacity", '1', { fromValue: '0.000000'}], position: 964, duration: 176 },
            { id: "eid1000", tween: [ "style", "${_sigment_mask}", "top", '-16px', { fromValue: '-16px'}], position: 2088, duration: 0 },
            { id: "eid965", tween: [ "style", "${_Group3Copy3}", "top", '179px', { fromValue: '179px'}], position: 3500, duration: 0 },
            { id: "eid120", tween: [ "style", "${_stolbik6}", "right", '16.97%', { fromValue: '8.32%'}], position: 3075, duration: 425 },
            { id: "eid4", tween: [ "transform", "${_ingalaytor}", "scaleY", '0', { fromValue: '1'}], position: 250, duration: 354 },
            { id: "eid265", tween: [ "style", "${__22}", "opacity", '1', { fromValue: '0.000000'}], position: 1666, duration: 351 },
            { id: "eid272", tween: [ "style", "${__22}", "opacity", '0', { fromValue: '1'}], position: 2329, duration: 16 },
            { id: "eid938", tween: [ "style", "${_d5}", "top", '186px', { fromValue: '186px'}], position: 3500, duration: 0 },
            { id: "eid493", tween: [ "style", "${_RectangleCopy}", "top", '-6px', { fromValue: '-8px'}], position: 1666, duration: 679 },
            { id: "eid497", tween: [ "style", "${_RectangleCopy}", "top", '-9px', { fromValue: '-6px'}], position: 2345, duration: 324 },
            { id: "eid502", tween: [ "style", "${_Group3}", "left", '799px', { fromValue: '653px'}], position: 2750, duration: 325 },
            { id: "eid195", tween: [ "style", "${_time_1}", "left", '80px', { fromValue: '0px'}], position: 604, duration: 170 },
            { id: "eid197", tween: [ "style", "${_time_1}", "left", '160px', { fromValue: '80px'}], position: 1666, duration: 351 },
            { id: "eid198", tween: [ "style", "${_time_1}", "left", '240px', { fromValue: '160px'}], position: 2017, duration: 328 },
            { id: "eid199", tween: [ "style", "${_time_1}", "left", '320px', { fromValue: '240px'}], position: 2345, duration: 324 },
            { id: "eid90", tween: [ "style", "${_TextCopy11}", "opacity", '1', { fromValue: '0.000000'}], position: 2017, duration: 178 },
            { id: "eid99", tween: [ "style", "${_TextCopy11}", "opacity", '0', { fromValue: '1'}], position: 2345, duration: 178 },
            { id: "eid145", tween: [ "style", "${_TextCopy11}", "opacity", '1', { fromValue: '0.000000'}], position: 3075, duration: 425 },
            { id: "eid631", tween: [ "color", "${_Text2Copy}", "color", 'rgba(218,35,24,1.00)', { animationColorSpace: 'RGB', valueTemplate: undefined, fromValue: 'rgba(218,35,24,1.00)'}], position: 1666, duration: 0 },
            { id: "eid925", tween: [ "style", "${_Group3Copy8}", "top", '124px', { fromValue: '124px'}], position: 3500, duration: 0 },
            { id: "eid1035", tween: [ "style", "${_TextCopy12}", "top", '285px', { fromValue: '279px'}], position: 0, duration: 3075 },
            { id: "eid1034", tween: [ "style", "${_TextCopy12}", "top", '285px', { fromValue: '285px'}], position: 3500, duration: 0 },
            { id: "eid991", tween: [ "style", "${__42}", "top", '145px', { fromValue: '145px'}], position: 3500, duration: 0 },
            { id: "eid308", tween: [ "transform", "${_timeCopy}", "rotateZ", '90deg', { fromValue: '0deg'}], position: 604, duration: 170 },
            { id: "eid310", tween: [ "transform", "${_timeCopy}", "rotateZ", '180deg', { fromValue: '90deg'}], position: 1666, duration: 351 },
            { id: "eid311", tween: [ "transform", "${_timeCopy}", "rotateZ", '270deg', { fromValue: '180deg'}], position: 2017, duration: 328 },
            { id: "eid312", tween: [ "transform", "${_timeCopy}", "rotateZ", '360deg', { fromValue: '270deg'}], position: 2345, duration: 324 },
            { id: "eid988", tween: [ "style", "${__12}", "top", '145px', { fromValue: '145px'}], position: 3500, duration: 0 },
            { id: "eid135", tween: [ "style", "${_stolbik6}", "opacity", '1', { fromValue: '0'}], position: 3075, duration: 425 },
            { id: "eid601", tween: [ "style", "${_Group3Copy7}", "left", '748px', { fromValue: '829px'}], position: 3075, duration: 425 },
            { id: "eid325", tween: [ "transform", "${_sigment}", "rotateZ", '0deg', { fromValue: '-90deg'}], position: 604, duration: 170 },
            { id: "eid327", tween: [ "transform", "${_sigment}", "rotateZ", '0deg', { fromValue: '0deg'}], position: 1666, duration: 0 },
            { id: "eid985", tween: [ "style", "${__22}", "top", '145px', { fromValue: '145px'}], position: 3500, duration: 0 },
            { id: "eid622", tween: [ "color", "${_Text2}", "color", 'rgba(244,142,108,1.00)', { animationColorSpace: 'RGB', valueTemplate: undefined, fromValue: 'rgba(244,142,108,1.00)'}], position: 1250, duration: 0 },
            { id: "eid349", tween: [ "transform", "${_sigmentCopy3}", "rotateZ", '0deg', { fromValue: '-90deg'}], position: 604, duration: 170 },
            { id: "eid350", tween: [ "transform", "${_sigmentCopy3}", "rotateZ", '90deg', { fromValue: '0deg'}], position: 1666, duration: 351 },
            { id: "eid351", tween: [ "transform", "${_sigmentCopy3}", "rotateZ", '180deg', { fromValue: '90deg'}], position: 2017, duration: 328 },
            { id: "eid352", tween: [ "transform", "${_sigmentCopy3}", "rotateZ", '270deg', { fromValue: '180deg'}], position: 2345, duration: 324 },
            { id: "eid61", tween: [ "style", "${_stolbik1}", "height", '88px', { fromValue: '0px'}], position: 1315, duration: 351 },
            { id: "eid68", tween: [ "style", "${_stolbik1}", "height", '54px', { fromValue: '88px'}], position: 1666, duration: 351 },
            { id: "eid71", tween: [ "style", "${_stolbik1}", "height", '34px', { fromValue: '54px'}], position: 2017, duration: 328 },
            { id: "eid72", tween: [ "style", "${_stolbik1}", "height", '14px', { fromValue: '34px'}], position: 2345, duration: 325 },
            { id: "eid574", tween: [ "style", "${_Group3Copy3}", "left", '558px', { fromValue: '799px'}], position: 3075, duration: 425 },
            { id: "eid582", tween: [ "style", "${_Group3Copy5}", "left", '639px', { fromValue: '799px'}], position: 3075, duration: 425 },
            { id: "eid520", tween: [ "style", "${_Rectangle2Copy3}", "left", '8px', { fromValue: '0px'}], position: 2750, duration: 325 },
            { id: "eid566", tween: [ "transform", "${_RectangleCopy3}", "scaleY", '0.48', { fromValue: '1'}], position: 2017, duration: 328 },
            { id: "eid569", tween: [ "transform", "${_RectangleCopy3}", "scaleY", '1', { fromValue: '0.48'}], position: 2345, duration: 1155 },
            { id: "eid342", tween: [ "transform", "${_sigmentCopy2}", "rotateZ", '0deg', { fromValue: '-90deg'}], position: 604, duration: 170 },
            { id: "eid343", tween: [ "transform", "${_sigmentCopy2}", "rotateZ", '90deg', { fromValue: '0deg'}], position: 1666, duration: 351 },
            { id: "eid344", tween: [ "transform", "${_sigmentCopy2}", "rotateZ", '180deg', { fromValue: '90deg'}], position: 2017, duration: 328 },
            { id: "eid607", tween: [ "style", "${_Group3Copy8}", "opacity", '1', { fromValue: '0'}], position: 3075, duration: 425 },
            { id: "eid583", tween: [ "style", "${_Group3Copy5}", "opacity", '1', { fromValue: '0'}], position: 3075, duration: 425 },
            { id: "eid510", tween: [ "style", "${_Rectangle2}", "left", '8px', { fromValue: '0px'}], position: 2750, duration: 325 },
            { id: "eid192", tween: [ "style", "${_Text2Copy}", "opacity", '1', { fromValue: '0'}], position: 1139, duration: 176 },
            { id: "eid283", tween: [ "style", "${__12Copy}", "opacity", '1', { fromValue: '0.000000'}], position: 964, duration: 175 },
            { id: "eid284", tween: [ "style", "${__12Copy}", "opacity", '0', { fromValue: '1'}], position: 2000, duration: 17 },
            { id: "eid1006", tween: [ "style", "${_time_1}", "top", '-16px', { fromValue: '-16px'}], position: 2088, duration: 0 },
            { id: "eid301", tween: [ "style", "${_timeCopy}", "right", '-32px', { fromValue: '48px'}], position: 604, duration: 170 },
            { id: "eid302", tween: [ "style", "${_timeCopy}", "right", '-112px', { fromValue: '-32px'}], position: 1666, duration: 351 },
            { id: "eid303", tween: [ "style", "${_timeCopy}", "right", '-192px', { fromValue: '-112px'}], position: 2017, duration: 328 },
            { id: "eid304", tween: [ "style", "${_timeCopy}", "right", '-272px', { fromValue: '-192px'}], position: 2345, duration: 324 },
            { id: "eid466", tween: [ "transform", "${_Group3Copy}", "scaleX", '1', { fromValue: '0'}], position: 1625, duration: 41 },
            { id: "eid963", tween: [ "style", "${_TextCopy8}", "top", '27px', { fromValue: '27px'}], position: 3500, duration: 0 },
            { id: "eid279", tween: [ "style", "${__32Copy}", "opacity", '1', { fromValue: '0.000000'}], position: 2017, duration: 328 },
            { id: "eid280", tween: [ "style", "${__32Copy}", "opacity", '0', { fromValue: '1'}], position: 2622, duration: 18 },
            { id: "eid56", tween: [ "style", "${_TextCopy}", "opacity", '1', { fromValue: '0.000000'}], position: 1139, duration: 176 },
            { id: "eid25", tween: [ "style", "${_d3}", "opacity", '1', { fromValue: '0.000000'}], position: 964, duration: 176 },
            { id: "eid614", tween: [ "style", "${_p2}", "left", '525px', { fromValue: '525px'}], position: 1250, duration: 0 },
            { id: "eid105", tween: [ "style", "${_stolbik2}", "right", '8.32%', { fromValue: '16.76%'}], position: 2750, duration: 325 },
            { id: "eid152", tween: [ "style", "${_stolbik1}", "border-width", '1px', { fromValue: '0px'}], position: 1315, duration: 29 },
            { id: "eid937", tween: [ "style", "${_d6}", "top", '216px', { fromValue: '216px'}], position: 3500, duration: 0 },
            { id: "eid498", tween: [ "style", "${_Group3Copy}", "left", '734px', { fromValue: '734px'}], position: 2669, duration: 0 },
            { id: "eid512", tween: [ "style", "${_Group3Copy}", "left", '829px', { fromValue: '734px'}], position: 2750, duration: 325 },
            { id: "eid575", tween: [ "style", "${_Group3Copy3}", "opacity", '1', { fromValue: '0'}], position: 3075, duration: 425 },
            { id: "eid345", tween: [ "style", "${_sigmentCopy3}", "left", '130px', { fromValue: '50px'}], position: 604, duration: 170 },
            { id: "eid346", tween: [ "style", "${_sigmentCopy3}", "left", '210px', { fromValue: '130px'}], position: 1666, duration: 351 },
            { id: "eid347", tween: [ "style", "${_sigmentCopy3}", "left", '290px', { fromValue: '210px'}], position: 2017, duration: 328 },
            { id: "eid348", tween: [ "style", "${_sigmentCopy3}", "left", '370px', { fromValue: '290px'}], position: 2345, duration: 324 },
            { id: "eid50", tween: [ "style", "${_TextCopy6}", "opacity", '1', { fromValue: '0.000000'}], position: 1139, duration: 176 },
            { id: "eid1008", tween: [ "style", "${_Text2}", "top", '303px', { fromValue: '303px'}], position: 3500, duration: 0 },
            { id: "eid112", tween: [ "style", "${_stolbik1}", "right", '11.42%', { fromValue: '25.4%'}], position: 2750, duration: 325 },
            { id: "eid420", tween: [ "transform", "${_Group3}", "scaleY", '1', { fromValue: '0'}], position: 1625, duration: 41 },
            { id: "eid968", tween: [ "style", "${_TextCopy}", "top", '88px', { fromValue: '88px'}], position: 3500, duration: 0 },
            { id: "eid23", tween: [ "style", "${_d5}", "opacity", '1', { fromValue: '0.000000'}], position: 964, duration: 176 },
            { id: "eid27", tween: [ "style", "${_axis}", "width", '419px', { fromValue: '0px'}], position: 964, duration: 195 },
            { id: "eid625", tween: [ "style", "${_Text2}", "width", '317px', { fromValue: '317px'}], position: 1666, duration: 0 },
            { id: "eid936", tween: [ "style", "${_axis}", "top", '275px', { fromValue: '275px'}], position: 3500, duration: 0 },
            { id: "eid331", tween: [ "style", "${_sigmentCopy}", "left", '130px', { fromValue: '50px'}], position: 604, duration: 170 },
            { id: "eid332", tween: [ "style", "${_sigmentCopy}", "left", '210px', { fromValue: '130px'}], position: 1666, duration: 351 },
            { id: "eid333", tween: [ "style", "${_sigmentCopy}", "left", '290px', { fromValue: '210px'}], position: 2017, duration: 328 },
            { id: "eid334", tween: [ "style", "${_sigmentCopy}", "left", '370px', { fromValue: '290px'}], position: 2345, duration: 324 },
            { id: "eid464", tween: [ "style", "${_Rectangle}", "top", '0px', { fromValue: '0px'}], position: 1666, duration: 351 },
            { id: "eid465", tween: [ "style", "${_Rectangle}", "top", '-1px', { fromValue: '0px'}], position: 2017, duration: 328 },
            { id: "eid139", tween: [ "style", "${_stolbik3}", "opacity", '1', { fromValue: '0'}], position: 3075, duration: 425 },
            { id: "eid656", tween: [ "style", "${_TextCopy8}", "opacity", '1', { fromValue: '0.000000'}], position: 1139, duration: 176 },
            { id: "eid933", tween: [ "style", "${_d1}", "top", '66px', { fromValue: '66px'}], position: 3500, duration: 0 },
            { id: "eid958", tween: [ "style", "${_Group3Copy5}", "top", '214px', { fromValue: '214px'}], position: 3500, duration: 0 },
            { id: "eid150", tween: [ "style", "${_TextCopy9}", "left", '585px', { fromValue: '706px'}], position: 3075, duration: 425 },
            { id: "eid57", tween: [ "style", "${_TextCopy5}", "opacity", '1', { fromValue: '0.000000'}], position: 1139, duration: 176 },
            { id: "eid989", tween: [ "style", "${__42Copy}", "top", '145px', { fromValue: '145px'}], position: 3500, duration: 0 },
            { id: "eid137", tween: [ "style", "${_stolbik4}", "opacity", '1', { fromValue: '0'}], position: 3075, duration: 425 },
            { id: "eid143", tween: [ "style", "${_stolbik7}", "opacity", '1', { fromValue: '0'}], position: 3075, duration: 425 },
            { id: "eid962", tween: [ "style", "${_TextCopy3}", "top", '148px', { fromValue: '148px'}], position: 3500, duration: 0 },
            { id: "eid1003", tween: [ "style", "${_sigmentCopy2}", "top", '-15px', { fromValue: '-15px'}], position: 2088, duration: 0 },
            { id: "eid1009", tween: [ "style", "${_p2}", "top", '305px', { fromValue: '305px'}], position: 3500, duration: 0 },
            { id: "eid190", tween: [ "style", "${_p2}", "opacity", '1', { fromValue: '0'}], position: 1139, duration: 176 },
            { id: "eid24", tween: [ "style", "${_d7}", "opacity", '1', { fromValue: '0.000000'}], position: 964, duration: 176 },
            { id: "eid955", tween: [ "style", "${_Text}", "top", '57px', { fromValue: '57px'}], position: 3500, duration: 0 },
            { id: "eid19", tween: [ "style", "${_d4}", "opacity", '1', { fromValue: '0.000000'}], position: 964, duration: 176 }         ]
      }
   }
},
"Symbol_1": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'time_1Copy',
      type: 'image',
      rect: ['0px','0px','100px','100px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/time_1.png','0px','0px']
   },
   {
      id: 'time_3Copy3',
      type: 'image',
      rect: ['127px','14px','5px','38px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/time_3.png','0px','0px']
   },
   {
      id: 'time_3Copy2',
      type: 'image',
      rect: ['127px','14px','5px','38px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/time_3.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_time_3Copy3}": [
            ["style", "-webkit-transform-origin", [56,94], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [56,94],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [56,94],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [56,94],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [56,94],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "rotateZ", '0deg'],
            ["style", "height", '38px'],
            ["style", "top", '14px'],
            ["style", "left", '47px'],
            ["style", "width", '5px']
         ],
         "${_time_1Copy}": [
            ["style", "top", '0px'],
            ["style", "height", '100px'],
            ["style", "left", '0px'],
            ["style", "width", '100px']
         ],
         "${_time_3Copy2}": [
            ["style", "-webkit-transform-origin", [56,94], {valueTemplate:'@@0@@% @@1@@%'} ],
            ["style", "-moz-transform-origin", [56,94],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-ms-transform-origin", [56,94],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "msTransformOrigin", [56,94],{valueTemplate:'@@0@@% @@1@@%'}],
            ["style", "-o-transform-origin", [56,94],{valueTemplate:'@@0@@% @@1@@%'}],
            ["transform", "scaleY", '1.2'],
            ["transform", "rotateZ", '0deg'],
            ["style", "height", '38px'],
            ["style", "top", '14px'],
            ["style", "left", '47px'],
            ["style", "width", '5px']
         ],
         "${symbolSelector}": [
            ["style", "height", '100px'],
            ["style", "width", '100px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2669.0237673069,
         autoPlay: true,
         timeline: [
            { id: "eid241", tween: [ "transform", "${_time_3Copy2}", "rotateZ", '1080deg', { fromValue: '0deg'}], position: 604, duration: 170 },
            { id: "eid242", tween: [ "transform", "${_time_3Copy2}", "rotateZ", '2160deg', { fromValue: '1080deg'}], position: 1666, duration: 351 },
            { id: "eid243", tween: [ "transform", "${_time_3Copy2}", "rotateZ", '3240deg', { fromValue: '2160deg'}], position: 2017, duration: 328 },
            { id: "eid244", tween: [ "transform", "${_time_3Copy2}", "rotateZ", '4320deg', { fromValue: '3240deg'}], position: 2345, duration: 324 },
            { id: "eid249", tween: [ "transform", "${_time_3Copy3}", "rotateZ", '90deg', { fromValue: '0deg'}], position: 604, duration: 170 },
            { id: "eid250", tween: [ "transform", "${_time_3Copy3}", "rotateZ", '180deg', { fromValue: '90deg'}], position: 1666, duration: 351 },
            { id: "eid251", tween: [ "transform", "${_time_3Copy3}", "rotateZ", '270deg', { fromValue: '180deg'}], position: 2017, duration: 328 },
            { id: "eid252", tween: [ "transform", "${_time_3Copy3}", "rotateZ", '360deg', { fromValue: '270deg'}], position: 2345, duration: 324 },
            { id: "eid245", tween: [ "style", "${_time_3Copy3}", "left", '127px', { fromValue: '47px'}], position: 604, duration: 170 },
            { id: "eid246", tween: [ "style", "${_time_3Copy3}", "left", '207px', { fromValue: '127px'}], position: 1666, duration: 351 },
            { id: "eid247", tween: [ "style", "${_time_3Copy3}", "left", '287px', { fromValue: '207px'}], position: 2017, duration: 328 },
            { id: "eid248", tween: [ "style", "${_time_3Copy3}", "left", '367px', { fromValue: '287px'}], position: 2345, duration: 324 },
            { id: "eid237", tween: [ "style", "${_time_3Copy2}", "left", '127px', { fromValue: '47px'}], position: 604, duration: 170 },
            { id: "eid238", tween: [ "style", "${_time_3Copy2}", "left", '207px', { fromValue: '127px'}], position: 1666, duration: 351 },
            { id: "eid239", tween: [ "style", "${_time_3Copy2}", "left", '287px', { fromValue: '207px'}], position: 2017, duration: 328 },
            { id: "eid240", tween: [ "style", "${_time_3Copy2}", "left", '367px', { fromValue: '287px'}], position: 2345, duration: 324 },
            { id: "eid253", tween: [ "style", "${_time_1Copy}", "left", '80px', { fromValue: '0px'}], position: 604, duration: 170 },
            { id: "eid254", tween: [ "style", "${_time_1Copy}", "left", '160px', { fromValue: '80px'}], position: 1666, duration: 351 },
            { id: "eid255", tween: [ "style", "${_time_1Copy}", "left", '240px', { fromValue: '160px'}], position: 2017, duration: 328 },
            { id: "eid256", tween: [ "style", "${_time_1Copy}", "left", '320px', { fromValue: '240px'}], position: 2345, duration: 324 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-12207234");
