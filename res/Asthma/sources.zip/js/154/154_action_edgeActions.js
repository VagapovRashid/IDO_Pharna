/***********************
* Adobe Edge Animate Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge Animate
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 0, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1666, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2017, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 2345, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_time_1}", "click", function(sym, e) {
         sym.play();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_Group2}", "click", function(sym, e) {
         sym.play();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_Rectangle3}", "click", function(sym, e) {
         sym.play();
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_stolbik2}", "click", function(sym, e) {
         sym.playReverse("5")
         sym.stop("6");
         
         
         
         
         
         
         
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_stolbik6}", "click", function(sym, e) {
         sym.playReverse("6");
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_stolbik4}", "click", function(sym, e) {
         sym.playReverse("7");
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_stolbik8}", "click", function(sym, e) {
         sym.playReverse("8");
         

      });
      //Edge binding end

      Symbol.bindSymbolAction(compId, symbolName, "creationComplete", function(sym, e) {
         var inhaler = sym.$( "ingalaytor" );
         var dropped = sym.$( "legkie" );
         
         inhaler.addClass("ui-widget-content");
         
         yepnope({
         	load: "js/script.js",
         	callback: function() {
         		inhaler.draggable({
         			containment: $("#Stage"),
         			revert: "invalid", 
         			scroll: false 
         		});
         		dropped.droppable({
                     drop: function( event, ui ) {
                         inhaler.animate({
         							left: "177px",
         							top: "145px"
                         }, 200, 
                         function() {
         							sym.stop();
         							inhaler.animate({
         								left: "177px",
         								top: "145px"
         								}, 500
         							);
         							inhaler.animate({
         								left: "620px",
         								top: "103px"
         								}, 500,
         								function() { sym.play("1");}
         							);
                         });
         				}
         		});
         	}
         });
         
         

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

   //=========================================================
   
   //Edge symbol: 'Symbol_1'
   (function(symbolName) {   
   
   })("Symbol_1");
   //Edge symbol end:'Symbol_1'

})(jQuery, AdobeEdge, "EDGE-12207234");