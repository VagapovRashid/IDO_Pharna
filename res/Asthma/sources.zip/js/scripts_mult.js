//$(function() {
	
	function SliderStorage (slideName) {
		var arrSliders = [0,0,0];
		var infoSliders = '';
					//document.getElementById('patients1').value = 0;		//alert(document.getElementById('patients1').value);
					//document.getElementById('patients2').value = 0;		//alert(document.getElementById('patients2').value);
					//document.getElementById('patients3').value = 0;		//alert(document.getElementById('patients3').value);
					
					document.getElementById('common').value = 0;		//alert(document.getElementById('common').value);
		
		$( ".slider" ).each(function(iClass){  
		
			var tooltip = $('<div class="tooltip" id="tooltip' + iClass+ '" />').addClass('txt_border');
			
			$(this).slider({
				animate: false,
				range: "min",
				value: 0,
				min: 1,
				max: 50,
				step: 1,
				create: function (event, ui){
					var value = $(this).slider("option", "value");
					$(this).find(".ui-slider-handle").addClass('shadow').text(value);
					$(this).find(".ui-slider-handle").prepend(tooltip);
					$('#tooltip'+iClass).text(value);
				},
				slide: function( event, ui ) {
					$(this).find(".ui-slider-handle").text(ui.value);
					$(this).find(".ui-slider-handle").prepend(tooltip);
					$('#tooltip'+iClass).text(ui.value);
					arrSliders[iClass] = ui.value;
				},
				start: function( event, ui ) {
					$('#tooltip'+iClass).css({'display': 'block'});
				},
				stop: function( event, ui ) {
					$('#tooltip'+iClass).css({'display': 'none'});
					
					//document.getElementById('patients1').value = arrSliders[0];		
					//document.getElementById('patients2').value = arrSliders[1];		
					//document.getElementById('patients3').value = arrSliders[2];		
					
					document.getElementById('common').value = arrSliders[0] + arrSliders[1] + arrSliders[2];		//alert(document.getElementById('common').value);
				}
			});
		
		});

	};
//});

				
