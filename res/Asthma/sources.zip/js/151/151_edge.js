/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/151/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'_2',
            type:'rect',
            rect:['166','30','auto','auto','auto','auto']
         },
         {
            id:'membrana',
            type:'image',
            rect:['90px','0','176px','141px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"membrana.png",'0px','0px']
         },
         {
            id:'_1',
            type:'rect',
            rect:['0','30','auto','auto','auto','auto']
         },
         {
            id:'membrana_2',
            type:'image',
            rect:['120px','0','144px','141px','auto','auto'],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"membrana_2.png",'0px','0px']
         },
         {
            id:'_4',
            type:'rect',
            rect:['162','200','auto','auto','auto','auto']
         },
         {
            id:'membranaCopy',
            type:'image',
            rect:['90px','170px','176px','141px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"membrana.png",'0px','0px']
         },
         {
            id:'_3',
            type:'rect',
            rect:['0','200','auto','auto','auto','auto']
         },
         {
            id:'membrana_2Copy',
            type:'image',
            rect:['120px','170px','144px','141px','auto','auto'],
            opacity:1,
            fill:["rgba(0,0,0,0)",im+"membrana_2.png",'0px','0px']
         },
         {
            id:'Rectangle',
            type:'rect',
            rect:['290px','0px','37px','120px','auto','auto'],
            fill:["rgba(192,192,192,0.00)",[180,[['rgba(255,255,255,1.00)',0],['rgba(255,255,255,0.00)',100]]]],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy',
            type:'rect',
            rect:['445px','191px','37px','120px','auto','auto'],
            fill:["rgba(192,192,192,0.00)",[180,[['rgba(255,255,255,1.00)',0],['rgba(255,255,255,0.00)',100]]]],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy2',
            type:'rect',
            rect:['0px','0px','37px','311px','auto','auto'],
            fill:["rgba(192,192,192,0.00)",[180,[['rgba(255,255,255,1.00)',0],['rgba(255,255,255,0.00)',100]]]],
            stroke:[0,"rgba(0,0,0,1)","none"],
            transform:[[],['180']]
         }],
         symbolInstances: [
         {
            id:'_1',
            symbolName:'_1'
         },
         {
            id:'_3',
            symbolName:'_3'
         },
         {
            id:'_4',
            symbolName:'_4'
         },
         {
            id:'_2',
            symbolName:'_2'
         }
         ]
      },
   states: {
      "Base State": {
         "${_membrana}": [
            ["style", "height", '141px'],
            ["style", "left", '90px'],
            ["style", "width", '176px']
         ],
         "${__4}": [
            ["style", "left", '162px'],
            ["style", "top", '200px']
         ],
         "${__3}": [
            ["style", "left", '2px']
         ],
         "${_membrana_2Copy}": [
            ["style", "top", '170px'],
            ["style", "height", '141px'],
            ["style", "opacity", '1'],
            ["style", "left", '120px'],
            ["style", "width", '144px']
         ],
         "${_membranaCopy}": [
            ["style", "height", '141px'],
            ["style", "top", '170px'],
            ["style", "left", '90px'],
            ["style", "width", '176px']
         ],
         "${_membrana_2}": [
            ["style", "height", '141px'],
            ["style", "opacity", '1'],
            ["style", "left", '120px'],
            ["style", "width", '144px']
         ],
         "${__1}": [
            ["style", "left", '2px']
         ],
         "${_RectangleCopy}": [
            ["color", "background-color", 'rgba(192,192,192,0.00)'],
            ["gradient", "background-image", [180,[['rgba(255,255,255,1.00)',0],['rgba(255,255,255,0.00)',100]]]],
            ["style", "left", '445px'],
            ["style", "top", '191px']
         ],
         "${_RectangleCopy2}": [
            ["style", "top", '0px'],
            ["transform", "rotateZ", '180deg'],
            ["style", "height", '311px'],
            ["gradient", "background-image", [180,[['rgba(255,255,255,1.00)',0],['rgba(255,255,255,0.00)',100]]]],
            ["style", "left", '0px'],
            ["color", "background-color", 'rgba(192,192,192,0.00)']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,0.00)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '311px'],
            ["style", "width", '482px']
         ],
         "${_Rectangle}": [
            ["color", "background-color", 'rgba(192,192,192,0.00)'],
            ["gradient", "background-image", [180,[['rgba(255,255,255,1.00)',0],['rgba(255,255,255,0.00)',100]]]],
            ["style", "left", '290px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 10500,
         autoPlay: true,
         timeline: [
            { id: "eid46", tween: [ "style", "${__1}", "left", '2px', { fromValue: '2px'}], position: 9750, duration: 0 },
            { id: "eid48", tween: [ "style", "${__3}", "left", '2px', { fromValue: '2px'}], position: 10500, duration: 0 }         ]
      }
   }
},
"_1": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'grey1',
      type: 'image',
      rect: ['0px','0px','160px','80px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/151/grey1.png','-160px','0px']
   },
   {
      id: 'grey1Copy',
      type: 'image',
      rect: ['0px','0px','160px','80px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/151/grey1.png','-160px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_grey1Copy}": [
            ["style", "top", '0px'],
            ["style", "height", '80px'],
            ["style", "background-position", [-160,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '0px'],
            ["style", "width", '160px']
         ],
         "${_grey1}": [
            ["style", "top", '0px'],
            ["style", "height", '80px'],
            ["style", "left", '0px'],
            ["style", "background-position", [0.000000,0.000000], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '160px']
         ],
         "${symbolSelector}": [
            ["style", "height", '80px'],
            ["style", "width", '160px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 7000,
         autoPlay: true,
         labels: {
            "loop": 0
         },
         timeline: [
            { id: "eid49", tween: [ "style", "${_grey1}", "background-position", [160,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [0.000000,0.000000]}], position: 0, duration: 7000 },
            { id: "eid4", tween: [ "style", "${_grey1Copy}", "background-position", [0.000000,0.000000], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-160,0]}], position: 0, duration: 7000 }         ]
      }
   }
},
"_2": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'grey2',
      type: 'image',
      rect: ['0px','0px','160px','80px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/151/grey2.png','0px','0px']
   },
   {
      id: 'grey2Copy',
      type: 'image',
      rect: ['0px','0px','160px','80px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/151/grey2.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_grey2Copy}": [
            ["style", "top", '0px'],
            ["style", "height", '80px'],
            ["style", "left", '0px'],
            ["style", "background-position", [-160,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '160px']
         ],
         "${_grey2}": [
            ["style", "top", '0px'],
            ["style", "height", '80px'],
            ["style", "background-position", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '0px'],
            ["style", "width", '160px']
         ],
         "${symbolSelector}": [
            ["style", "height", '80px'],
            ["style", "width", '160px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 7000,
         autoPlay: true,
         labels: {
            "loop": 0
         },
         timeline: [
            { id: "eid13", tween: [ "style", "${_grey2Copy}", "background-position", [0.000000,0.000000], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-160,0]}], position: 0, duration: 7000 },
            { id: "eid51", tween: [ "style", "${_grey2}", "background-position", [160,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [0,0]}], position: 0, duration: 7000 }         ]
      }
   }
},
"_3": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'red_new',
      type: 'image',
      rect: ['0','0px','160px','80px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/151/red_new.png','0px','0px']
   },
   {
      id: 'red_newCopy',
      type: 'image',
      rect: ['0','0px','160px','80px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/151/red_new.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_red_new}": [
            ["style", "height", '80px'],
            ["style", "top", '0px'],
            ["style", "background-position", [-160,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '160px']
         ],
         "${symbolSelector}": [
            ["style", "height", '81px'],
            ["style", "width", '161px']
         ],
         "${_red_newCopy}": [
            ["style", "top", '0px'],
            ["style", "height", '80px'],
            ["style", "background-position", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '160px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 7000,
         autoPlay: true,
         labels: {
            "loop": 0
         },
         timeline: [
            { id: "eid59", tween: [ "style", "${_red_new}", "background-position", [0,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-160.000000,0.000000]}], position: 0, duration: 7000 },
            { id: "eid63", tween: [ "style", "${_red_newCopy}", "background-position", [160,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [0.000000,0.000000]}], position: 0, duration: 7000 }         ]
      }
   }
},
"_4": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      id: 'red3',
      type: 'image',
      rect: ['0px','0px','320px','80px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/151/red3.png','0px','0px']
   },
   {
      id: 'red3Copy',
      type: 'image',
      rect: ['0px','0px','320px','80px','auto','auto'],
      fill: ['rgba(0,0,0,0)','images/151/red3.png','0px','0px']
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_red3}": [
            ["style", "top", '0px'],
            ["style", "height", '80px'],
            ["style", "left", '0px'],
            ["style", "background-position", [0,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "width", '320px']
         ],
         "${_red3Copy}": [
            ["style", "top", '0px'],
            ["style", "height", '80px'],
            ["style", "background-position", [-320,0], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '0px'],
            ["style", "width", '320px']
         ],
         "${symbolSelector}": [
            ["style", "height", '80px'],
            ["style", "width", '320px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 14000,
         autoPlay: true,
         labels: {
            "loop": 0
         },
         timeline: [
            { id: "eid55", tween: [ "style", "${_red3}", "background-position", [320,0], { valueTemplate: '@@0@@px @@1@@px', fromValue: [0,0]}], position: 0, duration: 14000 },
            { id: "eid21", tween: [ "style", "${_red3Copy}", "background-position", [0.000000,0.000000], { valueTemplate: '@@0@@px @@1@@px', fromValue: [-320,0]}], position: 0, duration: 14000 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-15890558");
