/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/311/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'Rectangle',
            type:'rect',
            rect:['0px','auto','60px','253px','auto','0px'],
            fill:["rgba(218,35,24,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'RectangleCopy',
            type:'rect',
            rect:['80px','auto','60px','82px','auto','0px'],
            fill:["rgba(50,85,118,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         },
         {
            id:'ill',
            type:'image',
            rect:['0','0','460px','317px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"ill.png",'0px','0px']
         },
         {
            id:'Text',
            type:'text',
            rect:['182px','20px','auto','auto','auto','auto'],
            text:"21,2",
            font:['Arial, Helvetica, sans-serif',18,"rgba(0,0,0,1)","normal","none",""]
         },
         {
            id:'TextCopy',
            type:'text',
            rect:['267px','191px','auto','auto','auto','auto'],
            text:"6,8",
            font:['Arial, Helvetica, sans-serif',18,"rgba(0,0,0,1)","normal","none",""]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_RectangleCopy}": [
            ["style", "top", 'auto'],
            ["style", "bottom", '12px'],
            ["style", "height", '0px'],
            ["color", "background-color", 'rgba(50,85,118,1.00)'],
            ["style", "left", '250px'],
            ["style", "width", '60px']
         ],
         "${_ill}": [
            ["style", "height", '317px'],
            ["style", "width", '460px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,0.00)'],
            ["style", "width", '460px'],
            ["style", "height", '317px'],
            ["style", "overflow", 'hidden']
         ],
         "${_Rectangle}": [
            ["style", "top", 'auto'],
            ["style", "bottom", '12px'],
            ["style", "height", '0px'],
            ["color", "background-color", 'rgba(218,35,24,1.00)'],
            ["style", "left", '170px'],
            ["style", "width", '60px']
         ],
         "${_TextCopy}": [
            ["style", "top", '191px'],
            ["style", "opacity", '0'],
            ["style", "left", '267px'],
            ["style", "font-size", '18px']
         ],
         "${_Text}": [
            ["style", "top", '20px'],
            ["style", "opacity", '0'],
            ["style", "left", '182px'],
            ["style", "font-size", '18px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 665,
         autoPlay: true,
         timeline: [
            { id: "eid14", tween: [ "style", "${_TextCopy}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165, easing: "easeOutQuad" },
            { id: "eid16", tween: [ "style", "${_Text}", "opacity", '1', { fromValue: '0'}], position: 500, duration: 165, easing: "easeOutQuad" },
            { id: "eid2", tween: [ "style", "${_RectangleCopy}", "height", '82px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" },
            { id: "eid4", tween: [ "style", "${_Rectangle}", "height", '253px', { fromValue: '0px'}], position: 0, duration: 500, easing: "easeOutQuad" }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-17813196");
