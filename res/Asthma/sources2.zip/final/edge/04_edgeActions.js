/***********************
* Adobe Edge Animate Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge Animate
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      

   })("stage");
   //Edge symbol end:'stage'

   //=========================================================
   
   //Edge symbol: '_1'
   (function(symbolName) {   
   
   })("_1");
   //Edge symbol end:'_1'

   //=========================================================
   
   //Edge symbol: '_2'
   (function(symbolName) {   
   
   })("_2");
   //Edge symbol end:'_2'

   //=========================================================
   
   //Edge symbol: '_3'
   (function(symbolName) {   
   
   })("_3");
   //Edge symbol end:'_3'

   //=========================================================
   
   //Edge symbol: '_4'
   (function(symbolName) {   
   
   })("_4");
   //Edge symbol end:'_4'

   //=========================================================
   
   //Edge symbol: '_5'
   (function(symbolName) {   
   
   })("_5");
   //Edge symbol end:'_5'

   //=========================================================
   
   //Edge symbol: '_6'
   (function(symbolName) {   
   
   })("_6");
   //Edge symbol end:'_6'

})(jQuery, AdobeEdge, "EDGE-826875");