/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
    var im='final/edge/images/';

    var fonts = {};
    fonts['Helvetica']='';


    var resources = [
    ];
    var symbols = {
        "stage": {
            version: "2.0.1",
            minimumCompatibleVersion: "2.0.0",
            build: "2.0.1.268",
            baseState: "Base State",
            initialState: "Base State",
            gpuAccelerate: false,
            resizeInstances: false,
            content: {
                dom: [
                    {
                        id:'grey_backs',
                        type:'image',
                        rect:['0','0','954px','564px','auto','auto'],
                        fill:["rgba(0,0,0,0)",im+"grey_backs.png",'0px','0px']
                    },
                    {
                        id:'_1',
                        type:'rect',
                        rect:['7','50','auto','auto','auto','auto']
                    },
                    {
                        id:'_2',
                        type:'rect',
                        rect:['348','32','auto','auto','auto','auto']
                    },
                    {
                        id:'_3',
                        type:'rect',
                        rect:['667','75','auto','auto','auto','auto']
                    },
                    {
                        id:'_4',
                        type:'rect',
                        rect:['7','377','auto','auto','auto','auto']
                    },
                    {
                        id:'_5',
                        type:'rect',
                        rect:['375','425','auto','auto','auto','auto']
                    },
                    {
                        id:'_6',
                        type:'rect',
                        rect:['696','401','auto','auto','auto','auto']
                    }],
                symbolInstances: [
                    {
                        id:'_1',
                        symbolName:'_1'
                    },
                    {
                        id:'_3',
                        symbolName:'_3'
                    },
                    {
                        id:'_2',
                        symbolName:'_2'
                    },
                    {
                        id:'_6',
                        symbolName:'_6'
                    },
                    {
                        id:'_5',
                        symbolName:'_5'
                    },
                    {
                        id:'_4',
                        symbolName:'_4'
                    }
                ]
            },
            states: {
                "Base State": {
                    "${_Stage}": [
                        ["color", "background-color", 'rgba(255,255,255,1)'],
                        ["style", "width", '954px'],
                        ["style", "height", '564px'],
                        ["style", "overflow", 'hidden']
                    ],
                    "${_grey_backs}": [
                        ["style", "height", '564px'],
                        ["style", "width", '954px']
                    ]
                }
            },
            timelines: {
                "Default Timeline": {
                    fromState: "Base State",
                    toState: "",
                    duration: 167,
                    autoPlay: true,
                    timeline: [
                        { id: "eid136", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['stop', '${__6}', [] ], ""], position: 0 },
                        { id: "eid137", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['stop', '${__2}', [] ], ""], position: 0 },
                        { id: "eid138", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['stop', '${__3}', [] ], ""], position: 0 },
                        { id: "eid139", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['stop', '${__1}', [] ], ""], position: 0 },
                        { id: "eid140", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['stop', '${__5}', [] ], ""], position: 0 },
                        { id: "eid141", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['stop', '${__4}', [] ], ""], position: 0 },
                        { id: "eid142", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['play', '${__4}', [] ], ""], position: 167 },
                        { id: "eid143", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['play', '${__3}', [] ], ""], position: 167 },
                        { id: "eid144", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['play', '${__5}', [] ], ""], position: 167 },
                        { id: "eid145", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['play', '${__2}', [] ], ""], position: 167 },
                        { id: "eid146", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['play', '${__6}', [] ], ""], position: 167 },
                        { id: "eid147", trigger: [ function executeSymbolFunction(e, data) { this._executeSymbolAction(e, data); }, ['play', '${__1}', [] ], ""], position: 167 }         ]
                }
            }
        },
        "_1": {
            version: "2.0.1",
            minimumCompatibleVersion: "2.0.0",
            build: "2.0.1.268",
            baseState: "Base State",
            initialState: "Base State",
            gpuAccelerate: false,
            resizeInstances: false,
            content: {
                dom: [
                    {
                        id: 'like_dislike',
                        type: 'image',
                        rect: ['24px','0px','253px','159px','auto','auto'],
                        fill: ['rgba(0,0,0,0)',im+'like_dislike.png','0px','0px']
                    },
                    {
                        type: 'text',
                        id: 'Text',
                        text: 'Slides',
                        rect: ['137px','163px','auto','auto','auto','auto'],
                        font: ['Helvetica',9,'rgba(0,0,0,1)','700','none','']
                    },
                    {
                        type: 'text',
                        rect: ['-23px','51px','auto','auto','auto','auto'],
                        id: 'TextCopy',
                        text: 'Likes/Dislikes',
                        font: ['Helvetica',9,'rgba(0,0,0,1)','700','none',''],
                        transform: [[0,0],['-90']]
                    },
                    {
                        rect: ['55px','auto','7px','52px','auto','53px'],
                        id: 'Rectangle',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(120,201,83,1.00)']
                    },
                    {
                        rect: ['62px','auto','7px','13px','auto','53px'],
                        id: 'RectangleCopy',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(226,112,1,1.00)']
                    },
                    {
                        rect: ['75px','auto','7px','63px','auto','53px'],
                        id: 'RectangleCopy3',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(120,201,83,1.00)']
                    },
                    {
                        rect: ['82px','auto','7px','14px','auto','53px'],
                        id: 'RectangleCopy2',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(226,112,1,1.00)']
                    },
                    {
                        rect: ['95px','auto','7px','55px','auto','53px'],
                        id: 'RectangleCopy5',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(120,201,83,1.00)']
                    },
                    {
                        rect: ['102px','auto','7px','11px','auto','53px'],
                        id: 'RectangleCopy4',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(226,112,1,1.00)']
                    },
                    {
                        rect: ['115px','auto','7px','46px','auto','53px'],
                        id: 'RectangleCopy7',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(120,201,83,1.00)']
                    },
                    {
                        rect: ['122px','auto','7px','15px','auto','53px'],
                        id: 'RectangleCopy6',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(226,112,1,1.00)']
                    },
                    {
                        rect: ['136px','auto','7px','116px','auto','53px'],
                        id: 'RectangleCopy9',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(120,201,83,1.00)']
                    },
                    {
                        rect: ['143px','auto','7px','12px','auto','53px'],
                        id: 'RectangleCopy8',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(226,112,1,1.00)']
                    },
                    {
                        rect: ['157px','auto','7px','16px','auto','53px'],
                        id: 'RectangleCopy11',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(120,201,83,1.00)']
                    },
                    {
                        rect: ['164px','auto','7px','56px','auto','53px'],
                        id: 'RectangleCopy10',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(226,112,1,1.00)']
                    },
                    {
                        rect: ['176px','auto','7px','71px','auto','53px'],
                        id: 'RectangleCopy13',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(120,201,83,1.00)']
                    },
                    {
                        rect: ['183px','auto','7px','16px','auto','53px'],
                        id: 'RectangleCopy12',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(226,112,1,1.00)']
                    },
                    {
                        rect: ['197px','auto','7px','60px','auto','53px'],
                        id: 'RectangleCopy15',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(120,201,83,1.00)']
                    },
                    {
                        rect: ['204px','auto','7px','22px','auto','53px'],
                        id: 'RectangleCopy14',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(226,112,1,1.00)']
                    },
                    {
                        rect: ['218px','auto','7px','82px','auto','53px'],
                        id: 'RectangleCopy17',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(120,201,83,1.00)']
                    },
                    {
                        rect: ['225px','auto','7px','12px','auto','53px'],
                        id: 'RectangleCopy16',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(226,112,1,1.00)']
                    },
                    {
                        rect: ['237px','auto','7px','33px','auto','53px'],
                        id: 'RectangleCopy19',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(120,201,83,1.00)']
                    },
                    {
                        rect: ['244px','auto','7px','46px','auto','53px'],
                        id: 'RectangleCopy18',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(226,112,1,1.00)']
                    },
                    {
                        rect: ['258px','auto','7px','73px','auto','53px'],
                        id: 'RectangleCopy21',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(120,201,83,1.00)']
                    },
                    {
                        rect: ['265px','auto','7px','33px','auto','53px'],
                        id: 'RectangleCopy20',
                        stroke: [0,'rgba(0,0,0,1)','none'],
                        type: 'rect',
                        fill: ['rgba(226,112,1,1.00)']
                    }],
                symbolInstances: [
                ]
            },
            states: {
                "Base State": {
                    "${_RectangleCopy17}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '82px'],
                        ["style", "left", '218px'],
                        ["color", "background-color", 'rgba(120,201,83,1.00)']
                    ],
                    "${_RectangleCopy9}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '116px'],
                        ["style", "left", '136px'],
                        ["color", "background-color", 'rgba(120,201,83,1.00)']
                    ],
                    "${_RectangleCopy5}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '55px'],
                        ["style", "left", '95px'],
                        ["color", "background-color", 'rgba(120,201,83,1.00)']
                    ],
                    "${symbolSelector}": [
                        ["style", "height", '175px'],
                        ["style", "width", '277px']
                    ],
                    "${_RectangleCopy}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '13px'],
                        ["style", "left", '62px'],
                        ["color", "background-color", 'rgba(226,112,1,1.00)']
                    ],
                    "${_RectangleCopy2}": [
                        ["color", "background-color", 'rgba(226,112,1,1.00)'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '14px'],
                        ["style", "left", '82px'],
                        ["style", "top", 'auto']
                    ],
                    "${_RectangleCopy13}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '71px'],
                        ["style", "left", '176px'],
                        ["color", "background-color", 'rgba(120,201,83,1.00)']
                    ],
                    "${_Rectangle}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '52px'],
                        ["style", "left", '55px'],
                        ["color", "background-color", 'rgba(120,201,83,1.00)']
                    ],
                    "${_RectangleCopy10}": [
                        ["color", "background-color", 'rgba(226,112,1,1.00)'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '56px'],
                        ["style", "left", '164px'],
                        ["style", "top", 'auto']
                    ],
                    "${_RectangleCopy21}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '73px'],
                        ["style", "left", '258px'],
                        ["color", "background-color", 'rgba(120,201,83,1.00)']
                    ],
                    "${_RectangleCopy20}": [
                        ["color", "background-color", 'rgba(226,112,1,1.00)'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '33px'],
                        ["style", "left", '265px'],
                        ["style", "top", 'auto']
                    ],
                    "${_RectangleCopy4}": [
                        ["color", "background-color", 'rgba(226,112,1,1.00)'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '11px'],
                        ["style", "left", '102px'],
                        ["style", "top", 'auto']
                    ],
                    "${_RectangleCopy7}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '46px'],
                        ["style", "left", '115px'],
                        ["color", "background-color", 'rgba(120,201,83,1.00)']
                    ],
                    "${_RectangleCopy6}": [
                        ["color", "background-color", 'rgba(226,112,1,1.00)'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '15px'],
                        ["style", "left", '122px'],
                        ["style", "top", 'auto']
                    ],
                    "${_RectangleCopy18}": [
                        ["color", "background-color", 'rgba(226,112,1,1.00)'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '46px'],
                        ["style", "left", '244px'],
                        ["style", "top", 'auto']
                    ],
                    "${_RectangleCopy3}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '63px'],
                        ["style", "left", '75px'],
                        ["color", "background-color", 'rgba(120,201,83,1.00)']
                    ],
                    "${_RectangleCopy14}": [
                        ["color", "background-color", 'rgba(226,112,1,1.00)'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '22px'],
                        ["style", "left", '204px'],
                        ["style", "top", 'auto']
                    ],
                    "${_RectangleCopy16}": [
                        ["color", "background-color", 'rgba(226,112,1,1.00)'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '12px'],
                        ["style", "left", '225px'],
                        ["style", "top", 'auto']
                    ],
                    "${_RectangleCopy15}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '60px'],
                        ["style", "left", '197px'],
                        ["color", "background-color", 'rgba(120,201,83,1.00)']
                    ],
                    "${_RectangleCopy8}": [
                        ["color", "background-color", 'rgba(226,112,1,1.00)'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '12px'],
                        ["style", "left", '143px'],
                        ["style", "top", 'auto']
                    ],
                    "${_Text}": [
                        ["style", "top", '163px'],
                        ["style", "font-weight", '700'],
                        ["style", "font-family", 'Helvetica'],
                        ["style", "left", '137px'],
                        ["style", "font-size", '9px']
                    ],
                    "${_RectangleCopy19}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '33px'],
                        ["style", "left", '237px'],
                        ["color", "background-color", 'rgba(120,201,83,1.00)']
                    ],
                    "${_RectangleCopy12}": [
                        ["color", "background-color", 'rgba(226,112,1,1.00)'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '16px'],
                        ["style", "left", '183px'],
                        ["style", "top", 'auto']
                    ],
                    "${_like_dislike}": [
                        ["style", "top", '0px'],
                        ["style", "height", '159px'],
                        ["style", "left", '24px'],
                        ["style", "width", '253px']
                    ],
                    "${_TextCopy}": [
                        ["style", "top", '51px'],
                        ["transform", "rotateZ", '-90deg'],
                        ["style", "font-weight", '700'],
                        ["style", "font-family", 'Helvetica'],
                        ["style", "left", '-23px'],
                        ["style", "font-size", '9px']
                    ],
                    "${_RectangleCopy11}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '53px'],
                        ["style", "height", '16px'],
                        ["style", "left", '157px'],
                        ["color", "background-color", 'rgba(120,201,83,1.00)']
                    ]
                }
            },
            timelines: {
                "Default Timeline": {
                    fromState: "Base State",
                    toState: "",
                    duration: 500,
                    autoPlay: true,
                    timeline: [
                        { id: "eid27", tween: [ "style", "${_RectangleCopy16}", "height", '34px', { fromValue: '12px'}], position: 0, duration: 500 },
                        { id: "eid42", tween: [ "style", "${_RectangleCopy}", "height", '26px', { fromValue: '13px'}], position: 0, duration: 500 },
                        { id: "eid29", tween: [ "style", "${_RectangleCopy14}", "height", '32px', { fromValue: '22px'}], position: 0, duration: 500 },
                        { id: "eid33", tween: [ "style", "${_RectangleCopy10}", "height", '40px', { fromValue: '56px'}], position: 0, duration: 500 },
                        { id: "eid34", tween: [ "style", "${_RectangleCopy11}", "height", '57px', { fromValue: '16px'}], position: 0, duration: 500 },
                        { id: "eid28", tween: [ "style", "${_RectangleCopy17}", "height", '68px', { fromValue: '82px'}], position: 0, duration: 500 },
                        { id: "eid30", tween: [ "style", "${_RectangleCopy15}", "height", '52px', { fromValue: '60px'}], position: 0, duration: 500 },
                        { id: "eid26", tween: [ "style", "${_RectangleCopy19}", "height", '22px', { fromValue: '33px'}], position: 0, duration: 500 },
                        { id: "eid24", tween: [ "style", "${_RectangleCopy21}", "height", '58px', { fromValue: '73px'}], position: 0, duration: 500 },
                        { id: "eid39", tween: [ "style", "${_RectangleCopy4}", "height", '36px', { fromValue: '11px'}], position: 0, duration: 500 },
                        { id: "eid36", tween: [ "style", "${_RectangleCopy9}", "height", '78px', { fromValue: '116px'}], position: 0, duration: 500 },
                        { id: "eid31", tween: [ "style", "${_RectangleCopy12}", "height", '46px', { fromValue: '16px'}], position: 0, duration: 500 },
                        { id: "eid35", tween: [ "style", "${_RectangleCopy8}", "height", '68px', { fromValue: '12px'}], position: 0, duration: 500 },
                        { id: "eid43", tween: [ "style", "${_Rectangle}", "height", '19px', { fromValue: '52px'}], position: 0, duration: 500 },
                        { id: "eid37", tween: [ "style", "${_RectangleCopy6}", "height", '31px', { fromValue: '15px'}], position: 0, duration: 500 },
                        { id: "eid41", tween: [ "style", "${_RectangleCopy3}", "height", '52px', { fromValue: '63px'}], position: 0, duration: 500 },
                        { id: "eid38", tween: [ "style", "${_RectangleCopy7}", "height", '56px', { fromValue: '46px'}], position: 0, duration: 500 },
                        { id: "eid25", tween: [ "style", "${_RectangleCopy18}", "height", '55px', { fromValue: '46px'}], position: 0, duration: 500 },
                        { id: "eid40", tween: [ "style", "${_RectangleCopy5}", "height", '86px', { fromValue: '55px'}], position: 0, duration: 500 },
                        { id: "eid20", tween: [ "style", "${_RectangleCopy2}", "height", '14px', { fromValue: '14px'}], position: 0, duration: 0 },
                        { id: "eid23", tween: [ "style", "${_RectangleCopy20}", "height", '40px', { fromValue: '33px'}], position: 0, duration: 500 },
                        { id: "eid32", tween: [ "style", "${_RectangleCopy13}", "height", '99px', { fromValue: '71px'}], position: 0, duration: 500 }         ]
                }
            }
        },
        "_2": {
            version: "2.0.1",
            minimumCompatibleVersion: "2.0.0",
            build: "2.0.1.268",
            baseState: "Base State",
            initialState: "Base State",
            gpuAccelerate: false,
            resizeInstances: false,
            content: {
                dom: [
                    {
                        rect: ['51px','30px','164px','164px','auto','auto'],
                        borderRadius: ['50%','50%','50%','50%'],
                        id: 'Ellipse',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'ellipse',
                        fill: ['rgba(120,201,83,1)']
                    },
                    {
                        transform: [[0,0],['-30']],
                        rect: ['51px','30px','164px','164px','auto','auto'],
                        borderRadius: ['50%','50%','50%','50%'],
                        type: 'ellipse',
                        id: 'EllipseCopy2',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        clip: ['rect(0px 82px 82px 0px)'],
                        fill: ['rgba(22,137,219,1.00)']
                    },
                    {
                        transform: [],
                        rect: ['51px','30px','164px','164px','auto','auto'],
                        borderRadius: ['50%','50%','50%','50%'],
                        type: 'ellipse',
                        id: 'EllipseCopy3',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        clip: ['rect(0px 82px 82px 0px)'],
                        fill: ['rgba(227,116,1,1.00)']
                    },
                    {
                        id: 'Products_view_time_legend',
                        type: 'image',
                        rect: ['0px','240px','204px','12px','auto','auto'],
                        fill: ['rgba(0,0,0,0)',im+'Products_view_time_legend.png','0px','0px']
                    },
                    {
                        type: 'text',
                        rect: ['14px','239px','auto','auto','auto','auto'],
                        id: 'Text2',
                        text: 'Product1',
                        align: 'left',
                        font: ['Helvetica',12,'rgba(0,0,0,1)','normal','none','normal']
                    },
                    {
                        type: 'text',
                        rect: ['1px','106px','auto','auto','auto','auto'],
                        id: 'Text2Copy4',
                        text: '15%',
                        align: 'left',
                        font: ['Helvetica',12,'rgba(0,0,0,1)','normal','none','normal']
                    },
                    {
                        type: 'text',
                        rect: ['1px','106px','auto','auto','auto','auto'],
                        align: 'left',
                        id: 'Text2Copy7',
                        text: '20%',
                        opacity: 1,
                        font: ['Helvetica',12,'rgba(0,0,0,1)','normal','none','normal']
                    },
                    {
                        type: 'text',
                        rect: ['61px','6px','auto','auto','auto','auto'],
                        id: 'Text2Copy6',
                        text: '17%',
                        align: 'left',
                        font: ['Helvetica',12,'rgba(0,0,0,1)','normal','none','normal']
                    },
                    {
                        type: 'text',
                        rect: ['216px','181px','auto','auto','auto','auto'],
                        id: 'Text2Copy5',
                        text: '69%',
                        align: 'left',
                        font: ['Helvetica',12,'rgba(0,0,0,1)','normal','none','normal']
                    },
                    {
                        type: 'text',
                        rect: ['216px','181px','auto','auto','auto','auto'],
                        id: 'Text2Copy8',
                        text: '63%',
                        align: 'left',
                        font: ['Helvetica',12,'rgba(0,0,0,1)','normal','none','normal']
                    },
                    {
                        type: 'text',
                        rect: ['33px','209px','auto','auto','auto','auto'],
                        id: 'Text2Copy3',
                        text: 'Application: Application Name',
                        align: 'left',
                        font: ['Helvetica',12,'rgba(0,0,0,1)','700','none','normal']
                    },
                    {
                        type: 'text',
                        rect: ['112px','239px','auto','auto','auto','auto'],
                        id: 'Text2Copy',
                        text: 'Product2',
                        align: 'left',
                        font: ['Helvetica',12,'rgba(0,0,0,1)','normal','none','normal']
                    },
                    {
                        type: 'text',
                        rect: ['207px','239px','auto','auto','auto','auto'],
                        id: 'Text2Copy2',
                        text: 'Product3',
                        align: 'left',
                        font: ['Helvetica',12,'rgba(0,0,0,1)','normal','none','normal']
                    },
                    {
                        rect: ['79px','29px','15px','1px','auto','auto'],
                        transform: [[0,0],['59']],
                        id: 'Rectangle2',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(180,180,180,1.00)']
                    },
                    {
                        rect: ['30px','113px','15px','1px','auto','auto'],
                        transform: [],
                        id: 'Rectangle2Copy',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(180,180,180,1.00)']
                    },
                    {
                        rect: ['199px','179px','15px','1px','auto','auto'],
                        transform: [[0,0],['44']],
                        id: 'Rectangle2Copy2',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(180,180,180,1.00)']
                    }],
                symbolInstances: [
                ]
            },
            states: {
                "Base State": {
                    "${_Rectangle2}": [
                        ["style", "top", '29px'],
                        ["transform", "rotateZ", '59deg'],
                        ["style", "height", '1px'],
                        ["color", "background-color", 'rgba(180,180,180,1.00)'],
                        ["style", "left", '79px'],
                        ["style", "width", '15px']
                    ],
                    "${_Text2Copy}": [
                        ["style", "top", '239px'],
                        ["style", "left", '112px'],
                        ["style", "font-size", '12px']
                    ],
                    "${_Text2}": [
                        ["style", "top", '239px'],
                        ["style", "left", '14px'],
                        ["style", "font-size", '12px']
                    ],
                    "${_Text2Copy2}": [
                        ["style", "top", '239px'],
                        ["style", "left", '207px'],
                        ["style", "font-size", '12px']
                    ],
                    "${_Rectangle2Copy2}": [
                        ["style", "top", '179px'],
                        ["transform", "rotateZ", '44deg'],
                        ["style", "height", '1px'],
                        ["color", "background-color", 'rgba(180,180,180,1.00)'],
                        ["style", "left", '199px'],
                        ["style", "width", '15px']
                    ],
                    "${symbolSelector}": [
                        ["style", "height", '254px'],
                        ["style", "width", '256px']
                    ],
                    "${_Text2Copy6}": [
                        ["style", "top", '6px'],
                        ["style", "left", '61px'],
                        ["style", "font-size", '12px']
                    ],
                    "${_Products_view_time_legend}": [
                        ["style", "height", '12px'],
                        ["style", "top", '240px'],
                        ["style", "left", '0px'],
                        ["style", "width", '204px']
                    ],
                    "${_EllipseCopy3}": [
                        ["color", "background-color", 'rgba(227,116,1,1.00)'],
                        ["style", "top", '30px'],
                        ["transform", "rotateZ", '0deg'],
                        ["style", "height", '164px'],
                        ["style", "left", '51px'],
                        ["style", "clip", [0,82,82,0], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ],
                        ["style", "width", '164px']
                    ],
                    "${_Text2Copy7}": [
                        ["style", "top", '106px'],
                        ["style", "opacity", '0'],
                        ["style", "left", '1px'],
                        ["style", "font-size", '12px']
                    ],
                    "${_Text2Copy5}": [
                        ["style", "top", '181px'],
                        ["style", "opacity", '1'],
                        ["style", "left", '216px'],
                        ["style", "font-size", '12px']
                    ],
                    "${_Text2Copy4}": [
                        ["style", "top", '106px'],
                        ["style", "opacity", '1'],
                        ["style", "left", '1px'],
                        ["style", "font-size", '12px']
                    ],
                    "${_Text2Copy3}": [
                        ["style", "top", '209px'],
                        ["style", "font-weight", '700'],
                        ["style", "left", '33px'],
                        ["style", "font-size", '12px']
                    ],
                    "${_Rectangle2Copy}": [
                        ["color", "background-color", 'rgba(180,180,180,1.00)'],
                        ["transform", "rotateZ", '0deg'],
                        ["style", "height", '1px'],
                        ["style", "top", '113px'],
                        ["style", "left", '30px'],
                        ["style", "width", '15px']
                    ],
                    "${_Text2Copy8}": [
                        ["style", "top", '181px'],
                        ["style", "opacity", '0'],
                        ["style", "left", '216px'],
                        ["style", "font-size", '12px']
                    ],
                    "${_EllipseCopy2}": [
                        ["color", "background-color", 'rgba(22,137,219,1.00)'],
                        ["style", "top", '30px'],
                        ["transform", "rotateZ", '-30deg'],
                        ["style", "height", '164px'],
                        ["style", "clip", [0,82,82,0], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ],
                        ["style", "left", '51px'],
                        ["style", "width", '164px']
                    ],
                    "${_Ellipse}": [
                        ["style", "top", '30px'],
                        ["style", "height", '164px'],
                        ["style", "left", '51px'],
                        ["style", "width", '164px']
                    ]
                }
            },
            timelines: {
                "Default Timeline": {
                    fromState: "Base State",
                    toState: "",
                    duration: 583,
                    autoPlay: true,
                    timeline: [
                        { id: "eid46", tween: [ "transform", "${_EllipseCopy2}", "rotateZ", '-67deg', { fromValue: '-30deg'}], position: 0, duration: 500 },
                        { id: "eid57", tween: [ "style", "${_Text2Copy5}", "opacity", '0', { fromValue: '1'}], position: 500, duration: 83 },
                        { id: "eid55", tween: [ "style", "${_Text2Copy7}", "opacity", '1', { fromValue: '0.000000'}], position: 499, duration: 84 },
                        { id: "eid50", tween: [ "transform", "${_EllipseCopy3}", "rotateZ", '-7deg', { fromValue: '0deg'}], position: 0, duration: 500 },
                        { id: "eid59", tween: [ "style", "${_Text2Copy8}", "opacity", '1', { fromValue: '0.000000'}], position: 499, duration: 84 },
                        { id: "eid52", tween: [ "style", "${_Text2Copy4}", "opacity", '0', { fromValue: '1'}], position: 500, duration: 83 }         ]
                }
            }
        },
        "_3": {
            version: "2.0.1",
            minimumCompatibleVersion: "2.0.0",
            build: "2.0.1.268",
            baseState: "Base State",
            initialState: "Base State",
            gpuAccelerate: false,
            resizeInstances: false,
            content: {
                dom: [
                    {
                        id: 'view_time',
                        type: 'image',
                        rect: ['28px','0px','250px','159px','auto','auto'],
                        fill: ['rgba(0,0,0,0)',im+'view_time.png','0px','0px']
                    },
                    {
                        type: 'text',
                        rect: ['132px','163px','auto','auto','auto','auto'],
                        id: 'Text3',
                        text: 'Slide Name',
                        align: 'left',
                        font: ['Helvetica',9,'rgba(0,0,0,1)','700','none','normal']
                    },
                    {
                        type: 'text',
                        font: ['Helvetica',9,'rgba(0,0,0,1)','700','none','normal'],
                        rect: ['-29px','52px','auto','auto','auto','auto'],
                        id: 'Text3Copy',
                        text: 'Average View time<br>(in seconds)',
                        align: 'center',
                        transform: [[0,0],['-90']]
                    },
                    {
                        rect: ['56px','auto','14px','20px','auto','52px'],
                        id: 'Rectangle3',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['76px','auto','14px','24px','auto','52px'],
                        id: 'Rectangle3Copy',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['96px','auto','14px','27px','auto','52px'],
                        id: 'Rectangle3Copy2',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['116px','auto','14px','43px','auto','52px'],
                        id: 'Rectangle3Copy3',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['137px','auto','14px','73px','auto','52px'],
                        id: 'Rectangle3Copy4',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['158px','auto','14px','19px','auto','52px'],
                        id: 'Rectangle3Copy5',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['178px','auto','14px','76px','auto','52px'],
                        id: 'Rectangle3Copy6',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['198px','auto','14px','22px','auto','52px'],
                        id: 'Rectangle3Copy7',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['219px','auto','14px','106px','auto','52px'],
                        id: 'Rectangle3Copy8',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['239px','auto','14px','19px','auto','52px'],
                        id: 'Rectangle3Copy9',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['259px','auto','14px','88px','auto','52px'],
                        id: 'Rectangle3Copy10',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    }],
                symbolInstances: [
                ]
            },
            states: {
                "Base State": {
                    "${_Rectangle3Copy8}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '52px'],
                        ["style", "height", '63px'],
                        ["style", "left", '219px'],
                        ["style", "width", '14px']
                    ],
                    "${_Rectangle3Copy10}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '52px'],
                        ["style", "height", '19px'],
                        ["style", "left", '259px'],
                        ["style", "width", '14px']
                    ],
                    "${_Text3Copy}": [
                        ["style", "top", '52px'],
                        ["style", "text-align", 'center'],
                        ["transform", "rotateZ", '-90deg'],
                        ["style", "font-weight", '700'],
                        ["style", "left", '-29px'],
                        ["style", "font-size", '9px']
                    ],
                    "${_Rectangle3Copy3}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '52px'],
                        ["style", "height", '56px'],
                        ["style", "left", '116px'],
                        ["style", "width", '14px']
                    ],
                    "${_Rectangle3Copy9}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '52px'],
                        ["style", "height", '39px'],
                        ["style", "left", '239px'],
                        ["style", "width", '14px']
                    ],
                    "${_Text3}": [
                        ["style", "top", '163px'],
                        ["style", "font-weight", '700'],
                        ["style", "left", '132px'],
                        ["style", "font-size", '9px']
                    ],
                    "${_Rectangle3}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '52px'],
                        ["style", "height", '29px'],
                        ["style", "left", '56px'],
                        ["style", "width", '14px']
                    ],
                    "${_Rectangle3Copy4}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '52px'],
                        ["style", "height", '84px'],
                        ["style", "left", '137px'],
                        ["style", "width", '14px']
                    ],
                    "${_Rectangle3Copy7}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '52px'],
                        ["style", "height", '53px'],
                        ["style", "left", '198px'],
                        ["style", "width", '14px']
                    ],
                    "${_Rectangle3Copy}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '52px'],
                        ["style", "height", '42px'],
                        ["style", "left", '76px'],
                        ["style", "width", '14px']
                    ],
                    "${symbolSelector}": [
                        ["style", "height", '174px'],
                        ["style", "width", '278px']
                    ],
                    "${_Rectangle3Copy5}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '52px'],
                        ["style", "height", '49px'],
                        ["style", "left", '158px'],
                        ["style", "width", '14px']
                    ],
                    "${_view_time}": [
                        ["style", "top", '0px'],
                        ["style", "height", '159px'],
                        ["style", "left", '28px'],
                        ["style", "width", '250px']
                    ],
                    "${_Rectangle3Copy2}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '52px'],
                        ["style", "height", '33px'],
                        ["style", "left", '96px'],
                        ["style", "width", '14px']
                    ],
                    "${_Rectangle3Copy6}": [
                        ["style", "top", 'auto'],
                        ["style", "bottom", '52px'],
                        ["style", "height", '58px'],
                        ["style", "left", '178px'],
                        ["style", "width", '14px']
                    ]
                }
            },
            timelines: {
                "Default Timeline": {
                    fromState: "Base State",
                    toState: "",
                    duration: 500,
                    autoPlay: true,
                    timeline: [
                        { id: "eid77", tween: [ "style", "${_Rectangle3Copy6}", "height", '76px', { fromValue: '58px'}], position: 0, duration: 500 },
                        { id: "eid72", tween: [ "style", "${_Rectangle3Copy}", "height", '24px', { fromValue: '42px'}], position: 0, duration: 500 },
                        { id: "eid78", tween: [ "style", "${_Rectangle3Copy7}", "height", '22px', { fromValue: '53px'}], position: 0, duration: 500 },
                        { id: "eid80", tween: [ "style", "${_Rectangle3Copy9}", "height", '19px', { fromValue: '39px'}], position: 0, duration: 500 },
                        { id: "eid74", tween: [ "style", "${_Rectangle3Copy3}", "height", '43px', { fromValue: '56px'}], position: 0, duration: 500 },
                        { id: "eid71", tween: [ "style", "${_Rectangle3}", "height", '20px', { fromValue: '29px'}], position: 0, duration: 500 },
                        { id: "eid81", tween: [ "style", "${_Rectangle3Copy10}", "height", '88px', { fromValue: '19px'}], position: 0, duration: 500 },
                        { id: "eid79", tween: [ "style", "${_Rectangle3Copy8}", "height", '106px', { fromValue: '63px'}], position: 0, duration: 500 },
                        { id: "eid73", tween: [ "style", "${_Rectangle3Copy2}", "height", '27px', { fromValue: '33px'}], position: 0, duration: 500 },
                        { id: "eid75", tween: [ "style", "${_Rectangle3Copy4}", "height", '73px', { fromValue: '84px'}], position: 0, duration: 500 },
                        { id: "eid76", tween: [ "style", "${_Rectangle3Copy5}", "height", '19px', { fromValue: '49px'}], position: 0, duration: 500 }         ]
                }
            }
        },
        "_4": {
            version: "2.0.1",
            minimumCompatibleVersion: "2.0.0",
            build: "2.0.1.268",
            baseState: "Base State",
            initialState: "Base State",
            gpuAccelerate: false,
            resizeInstances: false,
            content: {
                dom: [
                    {
                        id: 'like_dislike2',
                        type: 'image',
                        rect: ['24px','0px','253px','159px','auto','auto'],
                        fill: ['rgba(0,0,0,0)',im+'like_dislike2.png','0px','0px']
                    },
                    {
                        type: 'text',
                        rect: ['125px','163px','auto','auto','auto','auto'],
                        id: 'Text4',
                        text: 'Slide Name',
                        align: 'left',
                        font: ['Helvetica',9,'rgba(0,0,0,1)','bold','none','normal']
                    },
                    {
                        type: 'text',
                        font: ['Helvetica',9,'rgba(0,0,0,1)','bold','none','normal'],
                        rect: ['-25px','59px','auto','auto','auto','auto'],
                        id: 'Text4Copy',
                        text: 'Sum of clicks',
                        align: 'left',
                        transform: [[0,0],['-90']]
                    },
                    {
                        rect: ['55px','auto','16px','49px','auto','52px'],
                        id: 'Rectangle4',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['74px','auto','16px','60px','auto','52px'],
                        id: 'Rectangle4Copy',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['94px','auto','16px','54px','auto','52px'],
                        id: 'Rectangle4Copy2',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['115px','auto','16px','46px','auto','52px'],
                        id: 'Rectangle4Copy3',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['136px','auto','16px','109px','auto','52px'],
                        id: 'Rectangle4Copy4',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['156px','auto','16px','34px','auto','52px'],
                        id: 'Rectangle4Copy5',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['176px','auto','16px','69px','auto','52px'],
                        id: 'Rectangle4Copy6',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['196px','auto','16px','56px','auto','52px'],
                        id: 'Rectangle4Copy7',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['217px','auto','16px','77px','auto','52px'],
                        id: 'Rectangle4Copy8',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['237px','auto','16px','33px','auto','52px'],
                        id: 'Rectangle4Copy9',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    },
                    {
                        rect: ['257px','auto','16px','69px','auto','52px'],
                        id: 'Rectangle4Copy10',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    }],
                symbolInstances: [
                ]
            },
            states: {
                "Base State": {
                    "${_Text4Copy}": [
                        ["style", "top", '59px'],
                        ["style", "left", '-25px'],
                        ["transform", "rotateZ", '-90deg']
                    ],
                    "${_Rectangle4Copy2}": [
                        ["style", "top", 'auto'],
                        ["style", "height", '1px'],
                        ["style", "left", '94px'],
                        ["style", "bottom", '52px']
                    ],
                    "${_Rectangle4Copy5}": [
                        ["style", "height", '16px'],
                        ["style", "top", 'auto'],
                        ["style", "left", '156px'],
                        ["style", "bottom", '52px']
                    ],
                    "${_Rectangle4Copy8}": [
                        ["style", "top", 'auto'],
                        ["style", "height", '54px'],
                        ["style", "left", '217px'],
                        ["style", "bottom", '52px']
                    ],
                    "${_Rectangle4Copy7}": [
                        ["style", "height", '31px'],
                        ["style", "top", 'auto'],
                        ["style", "left", '196px'],
                        ["style", "bottom", '52px']
                    ],
                    "${_like_dislike2}": [
                        ["style", "height", '159px'],
                        ["style", "top", '0px'],
                        ["style", "left", '24px'],
                        ["style", "width", '253px']
                    ],
                    "${_Rectangle4Copy4}": [
                        ["style", "top", 'auto'],
                        ["style", "height", '51px'],
                        ["style", "left", '136px'],
                        ["style", "bottom", '52px']
                    ],
                    "${_Rectangle4Copy10}": [
                        ["style", "top", 'auto'],
                        ["style", "height", '39px'],
                        ["style", "left", '257px'],
                        ["style", "bottom", '52px']
                    ],
                    "${_Rectangle4Copy}": [
                        ["style", "height", '38px'],
                        ["style", "top", 'auto'],
                        ["style", "left", '74px'],
                        ["style", "bottom", '52px']
                    ],
                    "${_Rectangle4Copy9}": [
                        ["style", "height", '15px'],
                        ["style", "top", 'auto'],
                        ["style", "left", '237px'],
                        ["style", "bottom", '52px']
                    ],
                    "${symbolSelector}": [
                        ["style", "height", '174px'],
                        ["style", "width", '277px']
                    ],
                    "${_Rectangle4Copy6}": [
                        ["style", "top", 'auto'],
                        ["style", "height", '59px'],
                        ["style", "left", '176px'],
                        ["style", "bottom", '52px']
                    ],
                    "${_Rectangle4Copy3}": [
                        ["style", "height", '10px'],
                        ["style", "top", 'auto'],
                        ["style", "left", '115px'],
                        ["style", "bottom", '52px']
                    ],
                    "${_Rectangle4}": [
                        ["style", "top", 'auto'],
                        ["style", "height", '12px'],
                        ["style", "left", '55px'],
                        ["style", "bottom", '52px']
                    ],
                    "${_Text4}": [
                        ["style", "left", '125px'],
                        ["style", "top", '163px']
                    ]
                }
            },
            timelines: {
                "Default Timeline": {
                    fromState: "Base State",
                    toState: "",
                    duration: 1000,
                    autoPlay: true,
                    timeline: [
                        { id: "eid97", tween: [ "style", "${_Rectangle4Copy6}", "height", '69px', { fromValue: '59px'}], position: 0, duration: 500 },
                        { id: "eid100", tween: [ "style", "${_Rectangle4Copy3}", "height", '46px', { fromValue: '10px'}], position: 0, duration: 500 },
                        { id: "eid99", tween: [ "style", "${_Rectangle4Copy4}", "height", '109px', { fromValue: '51px'}], position: 0, duration: 500 },
                        { id: "eid103", tween: [ "style", "${_Rectangle4}", "height", '49px', { fromValue: '12px'}], position: 0, duration: 500 },
                        { id: "eid98", tween: [ "style", "${_Rectangle4Copy5}", "height", '34px', { fromValue: '16px'}], position: 0, duration: 500 },
                        { id: "eid93", tween: [ "style", "${_Rectangle4Copy10}", "height", '69px', { fromValue: '39px'}], position: 0, duration: 500 },
                        { id: "eid95", tween: [ "style", "${_Rectangle4Copy8}", "height", '77px', { fromValue: '54px'}], position: 0, duration: 500 },
                        { id: "eid102", tween: [ "style", "${_Rectangle4Copy}", "height", '60px', { fromValue: '38px'}], position: 0, duration: 500 },
                        { id: "eid101", tween: [ "style", "${_Rectangle4Copy2}", "height", '54px', { fromValue: '1px'}], position: 0, duration: 500 },
                        { id: "eid94", tween: [ "style", "${_Rectangle4Copy9}", "height", '33px', { fromValue: '15px'}], position: 0, duration: 500 },
                        { id: "eid96", tween: [ "style", "${_Rectangle4Copy7}", "height", '56px', { fromValue: '31px'}], position: 0, duration: 500 }         ]
                }
            }
        },
        "_5": {
            version: "2.0.1",
            minimumCompatibleVersion: "2.0.0",
            build: "2.0.1.268",
            baseState: "Base State",
            initialState: "Base State",
            gpuAccelerate: false,
            resizeInstances: false,
            content: {
                dom: [
                    {
                        id: 'speedometer',
                        type: 'image',
                        rect: ['12px','0px','180px','89px','auto','auto'],
                        fill: ['rgba(0,0,0,0)',im+'speedometer.png','0px','0px']
                    },
                    {
                        type: 'image',
                        id: 'pointer',
                        rect: ['33px','84px','74px','10px','auto','auto'],
                        transform: [[0,0],['25']],
                        fill: ['rgba(0,0,0,0)',im+'pointer.png','0px','0px']
                    },
                    {
                        type: 'text',
                        rect: ['0px','87px','auto','auto','auto','auto'],
                        id: 'Text5',
                        text: '0',
                        align: 'left',
                        font: ['Helvetica',9,'rgba(0,0,0,1)','bold','none','normal']
                    },
                    {
                        type: 'text',
                        rect: ['76px','44px','auto','auto','auto','auto'],
                        id: 'Text5Copy2',
                        text: '1',
                        align: 'left',
                        font: ['Helvetica',9,'rgba(0,0,0,1)','bold','none','normal']
                    },
                    {
                        type: 'text',
                        rect: ['126px','44px','auto','auto','auto','auto'],
                        id: 'Text5Copy3',
                        text: '2',
                        align: 'left',
                        font: ['Helvetica',9,'rgba(0,0,0,1)','bold','none','normal']
                    },
                    {
                        type: 'text',
                        rect: ['95px','106px','auto','auto','auto','auto'],
                        id: 'Text6',
                        text: '10%',
                        align: 'left',
                        font: ['Helvetica',12,'rgba(0,0,0,1)','400','none','normal']
                    },
                    {
                        type: 'text',
                        rect: ['95px','106px','auto','auto','auto','auto'],
                        id: 'Text6Copy',
                        text: '90%',
                        align: 'left',
                        font: ['Helvetica',12,'rgba(0,0,0,1)','400','none','normal']
                    },
                    {
                        type: 'text',
                        rect: ['200px','87px','auto','auto','auto','auto'],
                        id: 'Text5Copy',
                        text: '3',
                        align: 'left',
                        font: ['Helvetica',9,'rgba(0,0,0,1)','bold','none','normal']
                    }],
                symbolInstances: [
                ]
            },
            states: {
                "Base State": {
                    "${_Text6Copy}": [
                        ["style", "top", '106px'],
                        ["style", "opacity", '0'],
                        ["style", "font-weight", '400'],
                        ["style", "left", '95px'],
                        ["style", "font-size", '12px']
                    ],
                    "${_Text5Copy}": [
                        ["style", "left", '200px'],
                        ["style", "top", '87px']
                    ],
                    "${_Text5Copy3}": [
                        ["style", "left", '126px'],
                        ["style", "top", '44px']
                    ],
                    "${_Text6}": [
                        ["style", "top", '106px'],
                        ["style", "opacity", '1'],
                        ["style", "font-weight", '400'],
                        ["style", "left", '95px'],
                        ["style", "font-size", '12px']
                    ],
                    "${symbolSelector}": [
                        ["style", "height", '121px'],
                        ["style", "width", '205px']
                    ],
                    "${_Text5Copy2}": [
                        ["style", "left", '76px'],
                        ["style", "top", '44px']
                    ],
                    "${_pointer}": [
                        ["style", "top", '84px'],
                        ["transform", "rotateZ", '25deg'],
                        ["style", "height", '10px'],
                        ["style", "-webkit-transform-origin", [93,50], {valueTemplate:'@@0@@% @@1@@%'} ],
                        ["style", "-moz-transform-origin", [93,50],{valueTemplate:'@@0@@% @@1@@%'}],
                        ["style", "-ms-transform-origin", [93,50],{valueTemplate:'@@0@@% @@1@@%'}],
                        ["style", "msTransformOrigin", [93,50],{valueTemplate:'@@0@@% @@1@@%'}],
                        ["style", "-o-transform-origin", [93,50],{valueTemplate:'@@0@@% @@1@@%'}],
                        ["style", "left", '33px'],
                        ["style", "width", '74px']
                    ],
                    "${_speedometer}": [
                        ["style", "top", '0px'],
                        ["style", "height", '89px'],
                        ["style", "left", '12px'],
                        ["style", "width", '180px']
                    ],
                    "${_Text5}": [
                        ["style", "left", '0px'],
                        ["style", "top", '87px']
                    ]
                }
            },
            timelines: {
                "Default Timeline": {
                    fromState: "Base State",
                    toState: "",
                    duration: 583,
                    autoPlay: true,
                    timeline: [
                        { id: "eid111", tween: [ "style", "${_Text6Copy}", "opacity", '1', { fromValue: '0.000000'}], position: 500, duration: 83 },
                        { id: "eid105", tween: [ "transform", "${_pointer}", "rotateZ", '139deg', { fromValue: '25deg'}], position: 0, duration: 500 },
                        { id: "eid107", tween: [ "style", "${_Text6}", "opacity", '0', { fromValue: '1'}], position: 500, duration: 83 }         ]
                }
            }
        },
        "_6": {
            version: "2.0.1",
            minimumCompatibleVersion: "2.0.0",
            build: "2.0.1.268",
            baseState: "Base State",
            initialState: "Base State",
            gpuAccelerate: false,
            resizeInstances: false,
            content: {
                dom: [
                    {
                        id: 'call_results',
                        type: 'image',
                        rect: ['0px','0px','215px','120px','auto','auto'],
                        fill: ['rgba(0,0,0,0)',im+'call_results.png','0px','0px']
                    },
                    {
                        type: 'text',
                        rect: ['97px','131px','auto','auto','auto','auto'],
                        id: 'Text7',
                        text: 'Loyalty',
                        align: 'left',
                        font: ['Helvetica',9,'rgba(0,0,0,1)','700','none','normal']
                    },
                    {
                        rect: ['37px','6px','155px','23px','auto','auto'],
                        id: 'Rectangle5',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(168,69,220,1.00)']
                    },
                    {
                        rect: ['37px','6px','75px','23px','auto','auto'],
                        id: 'Rectangle5Copy3',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(120,201,83,1.00)']
                    },
                    {
                        rect: ['37px','42px','151px','23px','auto','auto'],
                        id: 'Rectangle5Copy5',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(102,233,189,1.00)']
                    },
                    {
                        rect: ['37px','42px','62px','23px','auto','auto'],
                        id: 'Rectangle5Copy4',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(226,112,1,1.00)']
                    },
                    {
                        rect: ['37px','79px','82px','23px','auto','auto'],
                        id: 'Rectangle5Copy2',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(165,55,17,1.00)']
                    },
                    {
                        rect: ['37px','79px','34px','23px','auto','auto'],
                        id: 'Rectangle5Copy',
                        stroke: [0,'rgb(0, 0, 0)','none'],
                        type: 'rect',
                        fill: ['rgba(22,137,219,1)']
                    }],
                symbolInstances: [
                ]
            },
            states: {
                "Base State": {
                    "${_call_results}": [
                        ["style", "height", '120px'],
                        ["style", "top", '0px'],
                        ["style", "left", '0px'],
                        ["style", "width", '215px']
                    ],
                    "${_Rectangle5Copy3}": [
                        ["color", "background-color", 'rgba(120,201,83,1.00)'],
                        ["style", "top", '6px'],
                        ["style", "left", '37px'],
                        ["style", "width", '52px']
                    ],
                    "${_Rectangle5Copy4}": [
                        ["style", "top", '42px'],
                        ["color", "background-color", 'rgba(226,112,1,1.00)'],
                        ["style", "left", '37px'],
                        ["style", "width", '107px']
                    ],
                    "${_Rectangle5Copy2}": [
                        ["style", "top", '79px'],
                        ["color", "background-color", 'rgba(165,55,17,1.00)'],
                        ["style", "left", '37px'],
                        ["style", "width", '33px']
                    ],
                    "${symbolSelector}": [
                        ["style", "height", '142px'],
                        ["style", "width", '215px']
                    ],
                    "${_Rectangle5}": [
                        ["color", "background-color", 'rgba(168,69,220,1.00)'],
                        ["style", "top", '6px'],
                        ["style", "left", '37px'],
                        ["style", "width", '97px']
                    ],
                    "${_Rectangle5Copy}": [
                        ["style", "top", '79px'],
                        ["style", "left", '37px'],
                        ["style", "width", '12px']
                    ],
                    "${_Text7}": [
                        ["style", "top", '131px'],
                        ["style", "font-weight", '700'],
                        ["style", "left", '97px'],
                        ["style", "font-size", '9px']
                    ],
                    "${_Rectangle5Copy5}": [
                        ["color", "background-color", 'rgba(102,233,189,1.00)'],
                        ["style", "top", '42px'],
                        ["style", "left", '37px'],
                        ["style", "width", '154px']
                    ]
                }
            },
            timelines: {
                "Default Timeline": {
                    fromState: "Base State",
                    toState: "",
                    duration: 500,
                    autoPlay: true,
                    timeline: [
                        { id: "eid122", tween: [ "style", "${_Rectangle5Copy3}", "width", '75px', { fromValue: '52px'}], position: 0, duration: 500 },
                        { id: "eid120", tween: [ "style", "${_Rectangle5Copy4}", "width", '62px', { fromValue: '107px'}], position: 0, duration: 500 },
                        { id: "eid118", tween: [ "style", "${_Rectangle5Copy}", "width", '34px', { fromValue: '12px'}], position: 0, duration: 500 },
                        { id: "eid123", tween: [ "style", "${_Rectangle5}", "width", '155px', { fromValue: '97px'}], position: 0, duration: 500 },
                        { id: "eid119", tween: [ "style", "${_Rectangle5Copy2}", "width", '82px', { fromValue: '33px'}], position: 0, duration: 500 },
                        { id: "eid121", tween: [ "style", "${_Rectangle5Copy5}", "width", '151px', { fromValue: '154px'}], position: 0, duration: 500 }         ]
                }
            }
        }
    };


    Edge.registerCompositionDefn(compId, symbols, fonts, resources);

    /**
     * Adobe Edge DOM Ready Event Handler
     */
    $(window).ready(function() {
        Edge.launchComposition(compId);
    });
})(jQuery, AdobeEdge, "EDGE-826875");
