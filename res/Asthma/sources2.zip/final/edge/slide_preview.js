
function slidePreview() {   //alert('');

	 
	//if (document.getElementById('preview')){ alert('');
		
			var srcPreview = $("#preview").attr("data-overlay-theme");
			$("<img/>").appendTo("#preview").attr('src', srcPreview);
			$("#preview").css({'display': 'block'});
			
    } else if ( document.getElementById('Stage') ) { 
		
		var classStage = "";
		var isStage = document.getElementById('Stage');
		
		function loadedAdobe() {
			if ( typeof AdobeEdge.getComposition == "function" && typeof AdobeEdge.getComposition(classStage) !== "undefined" ) {
				yepnope({
					load: "js/script.js",
					callback: function() { //alert(classStage);
						AdobeEdge.getComposition(classStage).getStage().play(1000);
					}
				});
			} else { setTimeout(function(){ loadedAdobe(); }, 100); }; 
		};
		
		if ( document.contains(isStage) ) {
			classStage = $("#Stage").attr("class"); 
			loadedAdobe();
		};
    };
		
};



